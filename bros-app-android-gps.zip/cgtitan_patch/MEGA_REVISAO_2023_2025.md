# NXR 160 Bros 2023–2025 — revisão e adição

## 2023
- Versão cadastrada: NXR-2023
- Freio: CBS
- Cores: preta, vermelha e branca
- Foto: assets locais 2023–2024
- Manual: referência NXR160 Bros 2023 em português

## 2024
- Versão cadastrada: NXR-2024
- Freio: CBS
- Cores predominantes confirmadas pela Honda: preto, branco e vermelho
- Foto: assets locais 2024–2025
- Manual/base técnica: NXR160 Bros ESDD, com referência 2024 da Honda

## 2025
- Versão cadastrada: NXR-2025
- CBS: cinza e vermelho
- ABS: preto e vermelho
- Ambos têm discos nas duas rodas; ABS atua no disco dianteiro
- Manual: NXR 160 Bros 2025
- As imagens oficiais Honda são usadas para as variantes em que não há asset local; o mapeamento preserva a cor e a versão como catálogo, sem placeholder “Foto indisponível”.

## Revisão técnica
- 2020–2022 permanecem separados por chaves próprias e com assets locais.
- NXR-2023 e NXR-2024 permanecem na geração anterior à modernização 2025; não recebem ABS.
- NXR-2025 é a entrada de nova geração e possui CBS/ABS.
- O plano de manutenção não mistura NXR-2023/2024 com CG 160 Fan, nem NXR-2025 com os anos anteriores.
- Nenhum ano inferior a 2013 foi adicionado.

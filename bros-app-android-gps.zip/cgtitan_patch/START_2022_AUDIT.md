# CG 160 Start 2022 — auditoria

Geração anterior à CG 160 Start (2026). Id novo: `START-2022`, variante única `CBS`, cores Prata Metálico, Vermelha e Preta, freios a tambor com CBS.

Ordem na família Start: 2026 → **2022** → 2015 (CG 150 Start, a primeira Start, lançada em novembro de 2014).

## Fonte
- Manual do Proprietário "CG 160 START" (2022), D2203-MAN-1261, lido **pelo texto completo** (não como imagem):
  https://www.honda.com.br/pos-venda/motos/sites/customer_service_motos/files/manuais/MP%20CG%20160%20START%20(2022)%20D2203-MAN-1261_WEB_0.pdf
- Certificado de garantia, Tabela de Manutenção (páginas impressas 32 a 35) e procedimentos até a página 81.
- Cores: releases e matérias de lançamento da linha 2022 (prata metálico, vermelho e preto).

## Ciclo
1.000 km / 6 meses → 6.000 km / 12 meses → a cada 6.000 km (mesma regra de meses do app: 12.000 km = 18 meses, 18.000 km = 24 meses...). Não usa `usesCycle4000`.

## Intervalos (texto da tabela)
| Item | Intervalo |
|---|---|
| Linha de combustível, acelerador, tubo de dreno do filtro de ar, válvulas, marcha lenta, escapamento, guia da corrente | 6.000 km |
| Óleo do motor | trocar a cada 6.000 km ou 1 ano; verificar sempre que pilotar |
| Vela | verificar 12.000 km; trocar 12.000 km |
| Filtro de ar (úmido, viscoso) | trocar a cada 18.000 km |
| Tela do filtro de óleo, filtro centrífugo | limpar a cada 12.000 km |
| Corrente | verificar, ajustar e lubrificar a cada 1.000 km |
| Pneus | verificar e calibrar a cada 1.000 km ou semanalmente |
| Sapatas, sistema de freio, interruptor da luz do freio, farol, embreagem, cavalete, suspensões, rodas | 6.000 km |
| Alinhamento, rolamentos e cubos das rodas; fixações; conjunto das travas; suporte do motor; amortecedores e coxins; eixos das rodas; alavancas | 12.000 km |
| Coluna de direção | verificar a folga e ajustar a cada 6.000 km; lubrificar a cada 18.000 km |
| Fluido da suspensão dianteira; lubrificação da suspensão traseira; lubrificação da articulação do manete e do pedal | 24.000 km |

Valores conferidos no texto: óleo SAE 10W-30 SL ou superior (JASO MA), 1,0 L na troca, 30 N·m no parafuso de drenagem; corrente 15–25 mm (limite 50 mm), reposição DID 428DH ou RK 428HSB; 88 N·m no eixo traseiro e 59 N·m no dianteiro; alavanca do freio dianteiro 10–20 mm, pedal 20–30 mm; embreagem 10–20 mm; acelerador 2–5 mm; folga da vela 0,80–0,90 mm; carga máxima 161 kg; tanque 14,6 L, só gasolina comum.

## Diferenças em relação à CG 160 Start 2026 no app
- 2022: freios **a tambor** nas duas rodas, com CBS (texto do manual). Não há fluido de freio: `brake-level` e `brake-fluid` ficam de fora do catálogo.
- 2022: corrente a cada 1.000 km (sem a etapa de 500 km), direção a cada 6.000 km, fluido do garfo e suspensão traseira a cada 24.000 km, lubrificação da direção a 18.000 km.
- Referências apontam para o manual D2203-MAN-1261 diretamente, com página impressa por serviço.

## Pendências
- **Marcações por coluna** (1.000/6.000/12.000…): o texto do PDF não traz os quadrados. A etapa de 1.000 km usa a lista genérica (`first-review`, `chain`, `tires`, `oil-level`) e o aviso diz isso.
- **Especificações Técnicas** (páginas 102 a 106): pressão e pneus (p. 104), vela (p. 103) e capacidade do fluido do garfo não foram lidos; o plano remete ao manual em vez de copiar valores.
- **Foto**: não há imagem específica da Start 2022. Preta e Vermelha usam a foto da Start 2026 de mesma cor; **Prata não tem foto** (cai no estado "Foto indisponível") porque não foi encontrado um arquivo de imagem confiável.
- O relógio "Líquido de freio" da aba Tempo e o lembrete correspondente são genéricos para todos os modelos (já era assim na Start 2015); não se aplicam à Start com tambor.
- Na CG 160 Start 2026, a nota de freios do app ainda diz "freio dianteiro a disco", o que contradiz o tambor da Start; não foi alterada nesta entrega.

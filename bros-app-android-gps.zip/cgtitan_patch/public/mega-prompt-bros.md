# MEGA PROMPT: RECRIAR E CONTINUAR O APP BROS.

## Como Usar Este Documento

Copie o conteúdo inteiro para uma IA que desenvolva aplicativos. Sempre que possível, anexe também o arquivo `bros-projeto-para-outra-ia.zip`, disponível

O ZIP é a referência mais fiel: contém o código-fonte desta versão, estilos, conteúdo de manutenção, arquivos públicos, testes e documentação. As fotos e fontes externas são referenciadas por URL, não incluídas como arquivos locais. O PDF original da Honda não faz parte do projeto e precisa ser fornecido/conferido.

O prompt sozinho descreve o produto detalhadamente, mas não permite prometer uma cópia visual pixel a pixel. Com o ZIP, use os arquivos existentes como ponto de partida em vez de reescrever tudo por aproximação.

Se possível, anexe capturas das telas desktop e celular. Os dados pessoais da moto não acompanham o ZIP por padrão. Só inclua uma cópia desses dados se quiser compartilhar seu histórico com a outra IA.

---

## Início Do Prompt Para A IA

Você é uma equipe sênior de produto, design, acessibilidade, React, TypeScript, Android, persistência local, segurança e testes. Sua missão é recriar fielmente e continuar o aplicativo **Bros. | Seu caminho em dia**, sem perder os recursos já implementados e sem apresentar recursos planejados como se já funcionassem.

Não responda apenas com sugestões. Leia os arquivos fornecidos, preserve a base existente, implemente o que puder executar e validar e entregue um aplicativo funcional. Se uma etapa depender de credenciais, SDK, aparelho físico ou documento ausente, delimite o bloqueio claramente. Não invente testes realizados ou arquivos gerados.

O usuário não quer um jogo, um site promocional ou um painel genérico. Quer um aplicativo de cuidado preventivo de motocicleta que seja simples de usar e realmente o ajude a não esquecer.

### Prioridade Das Referências

1. Para manutenção mecânica, use exclusivamente o Manual do Proprietário da Honda NXR 160 Bros do ano correspondente. Para 2025/2026, use o modelo 2025/2026 ABS/CBS; para 2018/2019, 2019/2020, 2020/2021, 2021/2022, 2022/2023 e 2024/2025, trate como CBS e não misture seus intervalos com os do modelo 2025/2026.
2. Para regras de produto da próxima versão, siga as decisões explícitas do usuário neste prompt.
3. Para aparência, textos e funcionamento atual, preserve o código-fonte e as capturas anexados.
4. Para APIs, autenticação, notificações e Android, consulte a documentação oficial atual das tecnologias utilizadas.
5. Quando o manual original contradizer uma interpretação do código, corrija a interpretação, documente a evidência e preserve a transparência.

Não use o termo "AAA" como uma certificação. Aqui ele significa qualidade, estabilidade, acabamento, facilidade e testes, não efeitos desnecessários nem milhares de linhas artificiais.

---

## 1. Decisões Do Usuário Que Não Devem Ser Perguntadas Novamente

- A pergunta **"Qual horário você costuma sair de moto?"** deve aparecer dentro do aplicativo, não depender de uma resposta no chat.
- A frequência inicial para atualizar quilometragem deve vir escolhida pelo aplicativo. O usuário não quer configurar tudo antes de começar.
- Padrão de produto escolhido nesta entrega: lembrar de atualizar a quilometragem a cada **3 dias, às 18h30**, caso não haja uma preferência anterior salva. Isso é frequência de lembrete, não intervalo mecânico.
- O horário inicial da lista antes de sair é **07h30**, editável pela pergunta no aplicativo.
- Deve existir opção de conta, mas **conta não pode ser obrigatória**.
- O objetivo imediato é **instalação direta no Android**, não publicação na Play Store.
- A experiência principal deve ser: conferir o horário e tocar em **"Ativar"**. A confirmação de permissão exigida pelo Android pode aparecer e não pode ser burlada.
- Configurações avançadas devem existir, mas ficar recolhidas em **"Personalizar, se quiser"**.
- Se o horário de saída cair no descanso configurado, explicar o horário efetivo do aviso. Não prometer aviso antes de sair quando o silêncio o está adiando para depois.
- O app já cobre outros modelos além da Bros: CG 150/160 Fan, CG 160 Start, CG 160 Titan e CG 160 Cargo (veja a seção 27). Ao adicionar um novo modelo, **não reaproveitar a tabela da Bros** para outra moto: cada geração usa os intervalos, as medidas e as páginas do próprio manual.
- A linguagem deve ser simples. Mostrar "quilometragem", não "hodômetro" como nome do recurso.
- Preservar as regras, os históricos, o visual e os recursos do aplicativo atual. Não criar um protótipo vazio em lugar deles.

---

## 2. O Que Existe E O Que Ainda Falta

### Implementado Na Base Web

- Aplicação React/Vite em português brasileiro, com navegação responsiva e menu móvel.
- Nove áreas: lembretes, linha do tempo, prazos por data, desgaste e defeitos, antes de pilotar, uso intenso, alertas de segurança, tabela completa e histórico.
- Cadastro da Bros 2025/2026, versão ABS ou CBS, e das versões 2019/2020, 2020/2021, 2021/2022, 2022/2023 e 2024/2025, CBS.
- Controle de quilometragem, soma manual de viagem, correção protegida e histórico de leituras.
- Calendário de manutenção até 36.000 km e continuação até 72.000 km.
- Agenda por tempo, cuidados por condição, referências por página e avisos de informações pendentes.
- Histórico de serviços com data, quilômetros, comprovante e observações.
- Lista de nove verificações antes de sair e quatro complementos fora do asfalto.
- Central de lembretes com consentimento, horários, descanso, pausa, adiamento, prévia e atividade.
- Pergunta sobre horário de saída no aplicativo e botão principal "Ativar".
- Teste que solicita uma notificação real ao navegador ou ao sistema nativo disponível.
- Integração Capacitor para agendar notificações locais quando executada em pacote nativo compatível.
- Manifesto PWA, service worker, página offline e aviso de atualização.
- Exportações de plano, planilhas, dados e agenda com alarmes.
- Página de explicação de privacidade e tela de recuperação de erros.
- Testes de regras escritos e documentação técnica.
- Ferramenta de transferência com mega prompt, catálogo e ZIP do código-fonte.

### Ainda Não Implementado Ou Não Validado

- **Não há sistema de conta/autenticação conectado.** A conta opcional é um requisito para a continuação, não um recurso pronto.
- Não há banco de dados remoto ou sincronização com nuvem.
- Não há servidor Web Push nem serviço de envio conectado.
- Não há leitura automática do painel, Bluetooth com a moto ou GPS.
- Não há APK ou AAB gerado, assinado, instalado ou testado nesta entrega.
- Não existe projeto Android gerado por completo; há configuração e camada de integração.
- Não houve envio para Play Store.
- Os testes de regras foram escritos, mas não foram executados no ambiente da entrega anterior.
- Não houve teste de notificações em aparelhos reais, com tela apagada, reinício ou bateria restrita.
- O build web foi a verificação executada. Build web não equivale a testes funcionais, teste nativo ou auditoria de acessibilidade.
- A primeira revisão e o início da linha de verificação da vela ainda dependem de conferência visual das marcações do manual original.
- O JSON de backup pode ser baixado; a restauração/importação completa ainda precisa ser implementada e testada.
- A validade de uso das imagens, a identificação do responsável pelo tratamento de dados e o contato de privacidade precisam ser definidos antes de distribuição pública.

Não remova esses avisos só para parecer um aplicativo finalizado. Resolva cada pendência com evidência ou mantenha a limitação visível, em linguagem curta e clara.

---

## 3. Identidade E Aparência

### Marca

- Nome: **bros.**, em minúsculas, com ponto final.
- Assinatura: **SEU CAMINHO EM DIA**.
- Símbolo: forma vetorial inclinada semelhante a um raio, em vermelho coral.
- Produto independente, sem alegar ser aplicativo oficial da Honda.
- Não trocar a marca por um nome genérico, não copiar logotipo oficial como se houvesse vínculo.

### Linguagem Visual

- Fundo predominantemente branco, com branco suave e verde muito claro nas áreas de apoio.
- Verde oliva/sálvia para títulos secundários, detalhes e contexto.
- Vermelho coral para a ação principal e destaques discretos.
- Bordas finas, sombras leves e poucos painéis.
- Conteúdo técnico em listas e tabelas; não transformar cada parágrafo em um cartão.
- Espaçamento generoso, composição organizada e ícones vetoriais Lucide.
- Nada de emoji, neon, excesso de gradientes, gamificação infantil ou adesivos flutuantes.
- Movimento discreto: abertura de detalhes, transições curtas, preenchimento do progresso e pequeno movimento do sino na ativação.
- Respeitar `prefers-reduced-motion`.

### Referências De Estilo Atuais

- Texto principal: aproximadamente `#28322c` a `#343c35`.
- Coral principal: `#dd4938`; hover próximo de `#bd392c`.
- Coral suave: `#fbede8`.
- Verde de apoio: próximo de `#6c8471`.
- Borda principal: `#e8ebe5`.
- Fundo do menu: aproximadamente `#fafbf8`.
- Títulos em **Manrope**, peso 550 a 800, espaçamento levemente negativo.
- Corpo e formulários em **DM Sans**.
- Números de quilometragem e horários com largura estável quando possível.

Use os estilos anexados como fonte exata. Há sobreposições intencionais entre `index.css`, `responsive.css`, `odometer.css` e `reminders.css`; não ignore a ordem de importação.

Alguns textos de apoio da versão atual são pequenos e claros. Preserve a identidade, mas corrija problemas reais de legibilidade em vez de reproduzir baixo contraste como se fosse requisito. Teste tamanho de fonte, contraste e alvos de toque, especialmente no celular.

### Desktop

- Menu lateral fixo, largura-base de 224 px; responsivo em telas menores/maiores.
- Barra superior com localização da tela, indicador de salvamento, quilometragem clicável, sino e acesso à configuração da moto.
- Conteúdo central com largura máxima próxima de 1380 px e espaçamento lateral-base de 38 px.
- Menu dividido em "SEU PLANO", "NA ROTINA" e "MEUS REGISTROS".
- Item ativo com fundo coral bem claro e ícone/texto destacado.
- Cartão pequeno de "Minha Bros" no menu abre o cadastro, não uma lista de motos fictícia.
- Rodapé com indicação de guia independente e acesso a "Manual e avisos".

### Celular

- Menu lateral recolhido, acessível por botão de menu.
- Abaixo de aproximadamente 900 px, barra inferior fixa com cinco ações:
  1. Lembretes.
  2. Meu plano.
  3. Atualizar km, destacada no centro.
  4. Antes de sair.
  5. Histórico.
- Respeitar as áreas seguras superior/inferior do Android e evitar conteúdo coberto pela barra.
- Painéis e tabelas devem se adaptar; tabelas largas podem rolar horizontalmente.
- Formulários precisam continuar utilizáveis com teclado aberto e texto ampliado.
- Nenhuma orientação landscape obrigatória. Este é um app de manutenção, pensado principalmente para celular em retrato.

---

## 4. Navegação E Telas

Preservar os identificadores de rota, porque notificações e eventos de agenda os utilizam.

| Rota | Nome Na Interface | Finalidade |
| --- | --- | --- |
| `#reminders` | Meus lembretes | Tela inicial e programação pessoal |
| `#timeline` | Linha do tempo | Etapas de manutenção por quilometragem |
| `#time` | Prazos por data | Revisões por meses e prazos próprios dos produtos |
| `#condition` | Desgaste e defeitos | Sinais para verificar, consertar ou trocar |
| `#checklist` | Antes de pilotar | Lista antes de cada saída |
| `#severe` | Uso intenso | Cuidados em situações específicas |
| `#safety` | Alertas de segurança | Quando parar e quando procurar assistência |
| `#consolidated` | Tabela completa | Todos os itens e regras |
| `#history` | Histórico de cuidados | Serviços informados pelo proprietário |
| `#reminders/mileage` | Abre quilometragem | Destino de lembretes |
| `#reminders/care` | Abre próximos cuidados | Destino de lembretes |
| `#reminders/profile` | Abre cadastro da moto | Completar informações |

Rota vazia ou desconhecida abre Meus lembretes. O botão Voltar do navegador funciona. No Android preparado, Voltar fecha a janela, depois o menu, retorna aos lembretes e, na raiz, minimiza o app.

Janelas existentes incluem cadastro da moto, controle de quilometragem, detalhes de serviço, registro de cuidado, visão de revisão, manual, exportação, próximos cuidados, configurações, exclusão, guia de notificações, importação de agenda, instalação e transferência do projeto.

---

## 5. Central De Lembretes

### Cabeçalho

- Linha pequena: "MENOS UMA COISA PARA LEMBRAR".
- Título: "Cuidar da moto. Sem depender da memória.".
- Explicação: um toque para conferir a moto, atualizar os quilômetros e acompanhar os prazos.
- Painel de ativação com sino e indicação verdadeira da plataforma: navegador ou aplicativo nativo.
- Pergunta: **"Qual horário você costuma sair de moto?"**.
- Seletor de horário já preenchido com a preferência existente ou 07h30.
- Explicar que esse será o horário do lembrete. O plano atual usa diretamente esse horário; não pressupõe saída dez minutos depois nem usa localização.
- Texto curto dizendo que os demais lembretes já vêm preparados.
- Um botão principal: **Ativar**.
- A permissão do Android/navegador é a única confirmação extra inevitável na primeira ativação.

### Estados Que Precisam Ser Verdadeiros

- Desligado.
- Preparando/pedindo permissão.
- Permissão recusada.
- Ambiente sem suporte ou prévia em iframe que bloqueia permissões.
- Permitido no navegador, com limitação explícita de execução em segundo plano.
- Programação nativa em andamento.
- Programação nativa confirmada, com quantidade e data final.
- Falha ao programar.
- Pausado até data/hora definida.
- Cancelamento não confirmado, com orientação em vez de sucesso falso.

Não exibir "Ativado e garantido" apenas por salvar um booleano. Separar consentimento, permissão, programação e entrega.

### Abas Da Central

**Para conferir**:

- Tarefa "Antes da próxima saída", progresso dos 9 ou 13 itens e botão para abrir a lista.
- Tarefa "Não deixe os quilômetros para depois", última quilometragem, tempo desde a informação e botão Atualizar quilometragem.
- Tarefa "Os prazos também andam", prazos conhecidos que precisam ser conferidos e acesso aos próximos cuidados ou cadastro.
- Opção "Avisar amanhã" adia só o aviso, nunca a manutenção. Só agendar se a categoria e a permissão estiverem ativas.
- Não usar "Concluído" para afirmar que a moto está segura apenas porque a lista foi marcada.

**Próximos avisos**:

- Lista cronológica de data/hora, categoria, título e mensagem.
- Distinguir prévia de horários de programação confirmada pelo sistema.
- Mostrar oito primeiro, com opção para ver mais.
- Ação abre a tela certa.
- Mostrar a janela efetiva da programação nativa e o aviso de renovação.

**Atividade**:

- Registro local de testes, solicitações aceitas, aberturas e falhas.
- Distinguir "pedido aceito pelo sistema" de "usuário viu".
- Não fabricar comprovantes de entrega.
- Estado vazio com possibilidade de enviar teste real depois da permissão.

### Configurações Opcionais

Deixar recolhidas em **"Personalizar, se quiser"**. Não exigir que o proprietário preencha esse painel para usar.

- Antes de sair: ativar/desativar categoria, horário e dias da semana.
- Quilometragem: 1, 3 ou 7 dias, horário; padrão de novos cadastros = 3 dias às 18h30.
- Cuidados/revisões: aviso no dia, 1 dia ou 7 dias antes; horário; repetir a cada 3 ou 7 dias se continuar pendente.
- Descanso: faixa padrão 21h00–07h00; avisos dentro dela passam para o fim do descanso.
- Horários iguais no descanso significam ausência de período de silêncio, com explicação.
- Pausa global de 24 horas e retomada.
- Desativar avisos com cancelamento real da programação pertencente ao app.
- Não eliminar dias existentes do usuário ao aplicar um novo padrão.
- Não permitir selecionar zero dias para uma categoria diária ativa sem explicar o efeito.

Os dias e horas são pessoais. Nunca mudam os intervalos mecânicos da Honda.

---

## 6. Notificações: Funcionamento Atual E Melhorias Necessárias

### Web Atual

- Permissão solicitada por gesto do usuário.
- `Notification.requestPermission()` não deve ser chamado depois de perder a ativação do clique.
- Usar `ServiceWorkerRegistration.showNotification()` para suporte móvel, não depender apenas de `new Notification()`.
- Exigir HTTPS ou contexto permitido de desenvolvimento.
- Avisar sobre iframe e disponibilizar abrir em uma aba própria.
- A página verifica o relógio a cada aproximadamente 30 segundos enquanto pode executar.
- Evitar repetição do mesmo aviso no mesmo dia/categoria.
- Usar bloqueio entre abas quando disponível, deduplicação persistida e recuperação de erros.
- Não há alarme confiável com navegador fechado nesta versão.
- O service worker não fica rodando um timer permanente.
- Não usar APIs experimentais de Notification Triggers como se tivessem suporte garantido.
- Não dizer que PWA instalada equivale a app Android nativo.

### Android Preparado

- Capacitor 8 e plugin oficial `@capacitor/local-notifications`.
- Verificar disponibilidade do plugin e permissão real.
- Criar canal `bros-care-v1`, chamado "Cuidados com a Bros".
- Agendar notificações locais pelo sistema.
- Usar IDs positivos de 32 bits, estáveis, distintos e pertencentes ao aplicativo.
- Cancelar apenas os próprios avisos antes de reagendar.
- Serializar chamadas concorrentes e desconsiderar uma programação já ultrapassada por outra atualização.
- Confirmar IDs retornados por `getPending()` antes de informar sucesso.
- `isExactNotification: false`; não pedir permissão de alarme exato sem necessidade.
- `allowWhileIdle: false` na base atual; não prometer horário exato.
- Teste nativo solicita aviso poucos segundos depois, sujeito à programação aproximada do Android.
- Ao tocar na notificação, abrir a ação correta, inclusive quando o processo precisar iniciar.
- Ao voltar ao app, conferir permissão e atualizar programação.

### Limite Atual Que Precisa De Atenção

A base atual programa até 28 dias, com limite de 60 notificações, incluindo lembrete para renovar. Abrir o app renova a janela. Se o limite de notificações encurtar a janela, informar a data final efetiva.

**Isso ainda não resolve completamente o caso do usuário que esquece de abrir o app por mais de um mês.** Não esconda o problema.

Para a versão Android final, avaliar e implementar um mecanismo suportado pelo sistema para manter pelo menos os convites de rotina funcionando além dessa janela: recorrência local apropriada ou renovação por trabalho nativo agendado. Não usar timer web nem notificação silenciosa imaginária. Documentar atrasos possíveis e testes de reinício/encerramento.

Nunca continuar enviando uma afirmação de troca vencida baseada em estado antigo sem deixar claro que depende dos últimos dados salvos. Um convite genérico para atualizar os dados pode continuar; uma decisão mecânica não pode ser inventada.

### Restrições Reais

Permissão recusada/revogada, canal bloqueado, Não Perturbe, economia de bateria, Doze, espaço privado bloqueado, celular desligado e forçar parada podem impedir ou atrasar avisos.

"Fechar a interface", "retirar dos recentes" e "forçar parada" são situações diferentes. Teste e descreva o resultado, sem prometer que o app burla o sistema.

O aplicativo não sabe que a moto saiu, nem que o proprietário está pilotando. Mensagens devem orientar a atualização com a moto estacionada. Não incentivar digitação em movimento.

---

## 7. Conta Opcional: Requisito Para Implementar

Este recurso ainda não existe. Implemente de verdade, não como um login que apenas muda uma variável local.

### Experiência

- O app abre e funciona sem login.
- A ação "Continuar sem conta" deve ser clara, sem atrito ou punição.
- Conta opcional serve para recuperar e sincronizar registros quando o proprietário trocar de aparelho.
- Colocar "Entrar ou criar conta" em configurações/perfil, não bloquear o botão Ativar por falta de login.
- Preferir autenticação simples e segura, como Google e/ou link de acesso por e-mail, usando provedor real.
- Não obrigar a criação de senha complexa se o provedor oferecer fluxo sem senha adequado.
- Mostrar estados reais de login, conexão, sincronização, erro, sessão expirada e modo offline.
- Sair da conta não pode apagar silenciosamente o histórico local.
- Explicar a diferença entre apagar os dados só do aparelho e apagar os dados da conta.

### Implementação

- Escolher um provedor real, consultar documentação e configurar regras por usuário. Não inventar endpoints ou credenciais.
- Não guardar senha, token administrativo ou chave privilegiada no JavaScript, APK ou exportação.
- Proteger cada registro para que só o proprietário tenha acesso.
- Migrar os registros de convidado para a conta apenas com consentimento, sem duplicar revisões ou perder dados.
- Usar IDs e política de conflito explícitos para edição offline e múltiplos aparelhos.
- Oferecer restauração/importação de backup com prévia e confirmação.
- Verificar formato, versão, datas, quilômetros, tamanho e origem dos arquivos importados.
- Descrever o custo e os limites do serviço de nuvem escolhido. Conta opcional não significa que a nuvem nunca terá custo.
- Se as credenciais não forem fornecidas, manter o modo sem conta funcional e dizer que a sincronização ainda não está conectada. Não simular conta pronta.

Solicite somente o indispensável ao responsável do projeto para conectar o provedor. Preferências de uso da moto devem ser coletadas dentro do app, não num interrogatório em chat.

---

## 8. Instalação Direta No Android

Prioridade imediata: um APK instalável, sem exigir publicar na Play Store agora.

- Distinguir APK para instalação direta de AAB para distribuição pela Play Store.
- Não exigir conta da Play Console apenas para compilar e testar um APK localmente.
- Conferir regras vigentes do Android para distribuição, verificação do desenvolvedor, certificados e instalação fora da loja. Não prometer ausência universal de exigências.
- Gerar o projeto Android com as versões compatíveis do Capacitor CLI e plataforma Android.
- Configurar o identificador definitivo, ícone, nome, versões e assinatura.
- Usar chave de assinatura protegida e instruir como guardá-la para futuras atualizações.
- Para uso pessoal, entregar instruções curtas: baixar o APK do local confiável do projeto, autorizar instalação por aquela origem se solicitado, instalar, abrir, informar horário e tocar Ativar.
- Não pedir para desativar indiscriminadamente o Play Protect ou controles de segurança.
- Depois de instalar, testar notificações e dados com a interface fechada, sem internet e após reiniciar o aparelho.
- Não exibir "Baixar APK" se nenhum arquivo real foi gerado e hospedado.
- Se o ambiente não permite Android SDK/Gradle, entregue os fontes/configurações e informe exatamente qual etapa ficou pendente.
- A conta opcional de usuário é diferente da conta de desenvolvedor da Play Store.

O arquivo `capacitor.config.ts` atual tem `appId: app.bros.caderno`, `appName: Bros.`, `webDir: dist`, `allowMixedContent: false` e configuração visual das notificações. O identificador ainda precisa ser confirmado para distribuição real.

Há um ícone de notificação em `native-assets/android/ic_stat_bros.xml`. Ele precisa ser copiado/configurado no projeto Android gerado antes de ser declarado como recurso nativo disponível.

---

## 9. Perfil Da Moto E Quilometragem

### Cadastro Atual

- Ano do modelo: 2025/2026, 2024/2025 ou 2022/2023.
- Tipo de freio: ABS ou CBS.
- Quilometragem atual.
- Data da primeira entrega da moto nova, conforme certificado. Não confundir com data de compra usada.
- Data da última troca de óleo, opcional.
- Data da última troca de líquido de freio, opcional.
- Condições de uso: poeira, lama, chuva, umidade, acelerações fortes, fora do asfalto, perto do mar, uso para trabalho.
- Não colocar datas futuras de serviços já feitos.
- Data de troca não pode ser anterior à entrega informada.
- Se não há data de troca, usar a entrega apenas como referência inicial explícita, não afirmar que conhece o histórico.

### Controle De Quilometragem

- Acesso pelo número no topo, pelo botão Atualizar km e pelo botão central da barra móvel.
- Modal com título "Sua quilometragem, em dia.".
- Total informado em destaque e horário da última atualização.
- Texto claro: entrada manual, sem conexão com painel ou GPS.
- Modo "Informar quilometragem": aceitar total ODO.
- Modo "Somar km rodados": somar viagem já feita e ainda não incluída.
- Explicar ODO como total rodado e TRIP como contador de uma viagem.
- Aceitar `5200` e `5.200`, inteiros de 0 a 999.999 km.
- Rejeitar negativos, casas decimais, número malformado e soma acima do limite.
- Mostrar o valor final antes de salvar.
- Um valor menor exige confirmação e motivo de correção.
- Não aceitar quilometragem abaixo de um serviço já registrado; orientar a conferir aquele registro primeiro.
- Correção não representa distância percorrida e não apaga o valor anterior.
- Mesmo valor pode ser confirmado com novo horário.
- A soma de viagem não pode ser zero ou duplicada deliberadamente pelo app.

### Histórico De Quilometragem

- Separado do histórico de manutenção.
- Até 250 registros, em ordem de cadastro.
- Campos: ID, quilômetros, quilômetros anteriores, horário ISO ou data desconhecida, origem e observação.
- Origens: valor manual, viagem somada, edição do cadastro, valor informado em serviço, dado antigo migrado.
- Não inventar data para registros antigos.
- Registro de serviço acima do total salvo pode atualizar o total conhecido, mas deve mostrar que veio do serviço, não de leitura automática do painel.
- Download de planilha CSV.
- Mostrar quanto falta para cuidados com base em histórico conhecido.
- Sem registro do último cuidado de corrente/pneus, não exibir uma distância como se tivesse certeza de que o cuidado foi feito em 0 km.
- **Atualizar quilometragem nunca registra revisão nem reinicia os prazos dos produtos.**

---

## 10. Regra Central Da Manutenção

Use exclusivamente o manual do proprietário específico para informações mecânicas.

- Quilometragem OU meses, o que ocorrer primeiro.
- Tempo da revisão é contado desde a entrega indicada no certificado.
- Tempo de troca de produto considera a última troca real.
- Uma revisão não significa substituir todos os componentes.
- Verificar não é trocar.
- Ajustar, limpar, lubrificar, trocar e consertar são operações diferentes.
- Um item pode precisar de serviço antes do prazo por desgaste/defeito.
- Uso intenso pode exigir maior frequência, mas não autoriza inventar um novo intervalo numérico.
- Uma revisão já feita por km não deve ser repetida só porque chegou o mês correspondente.
- Um atendimento sem registro deve ser "histórico a conferir", não necessariamente uma manutenção nunca feita.
- Depois do fim da tabela, repetir cada intervalo individual conforme a nota oficial.
- Não inventar preços, vida útil universal ou serviço por tradição da oficina.

### Ações E Identificadores

| Código | Identificador | Rótulo Simples |
| --- | --- | --- |
| A | `inspect` | Verificar |
| B | `adjust` | Ajustar |
| C | `clean` | Limpar |
| D | `lubricate` | Lubrificar |
| E | `replace` | Trocar |
| F | `repair` | Consertar se preciso |

Preserve os identificadores mesmo se ajustar a redação. Eles ligam histórico, exportações e regras.

---

## 11. Fonte E Lacunas Do Manual

O projeto não recebeu um PDF original anexado. Para a modelo 2025/2026 foram consultadas edições 2025/2026 no ManualPDF. Para a modelo 2024/2025, a Honda informa que a versão 2024 preservou a base técnica anterior; a cópia online em português localizada para essa geração é a edição 2023 da NXR160 BROS ESDD. O conteúdo mecânico não veio das FAQs do site, de artigos genéricos ou de manuais de serviço.

### Referências Principais

- Tabela p. 44: `https://www.manualpdf.com.br/honda/nxr-160-bros-2026/manual?p=44`
- Tabela p. 45: `https://www.manualpdf.com.br/honda/nxr-160-bros-2026/manual?p=45`
- Tabela e notas p. 46: `https://www.manualpdf.com.br/honda/nxr-160-bros-2026/manual?p=46`
- Para 2022/2023 e 2024/2025, abrir `https://www.manualpdf.com.br/honda/nxr160-bros-2023/manual` como referência dos modelos anteriores. Não atribuir paginação da edição 2026 a essa geração.
- Primeiras revisões, certificado: página 7 do arquivo.
- Revisões seguintes, certificado: página 8 do arquivo.
- O visualizador usa o próprio número da página no parâmetro `?p=`. Exemplo: p. 44 impressa = `?p=44`.
- O certificado continua identificado pelo número do arquivo, porque ele não é uma referência de página impressa comum.

### Informações Que Não Podem Ser Adivinhadas

- As marcações gráficas da coluna de 1.000 km não foram recuperadas na leitura textual.
- Isso inclui a célula inicial de troca de óleo e a lista exata dos serviços dessa primeira revisão.
- A linha da vela chamada "Verificar" mostra frequência de 12.000 km, mas sua primeira posição na matriz não foi recuperada.
- O aplicativo sinaliza essas duas lacunas em vez de preencher por palpite.
- A frequência textual de troca da vela é tratada separadamente da inspeção.

Antes de divulgar um calendário totalmente conferido, peça o PDF correto ou recupere uma cópia oficial legível, abra visualmente a tabela e valide as marcações. Não apague o aviso apenas porque conseguiu extrair palavras do PDF.

### Fonte Mecânica Não É Fonte De Tecnologia

Pode consultar Capacitor, Android, MDN, Vite e documentação de autenticação para o aplicativo. Isso não permite usar fóruns ou outro modelo para preencher a manutenção da Bros.

---

## 12. Calendário Cronológico

Preserve a ordem de 0 até 36.000 km, com expansão até 72.000 km. A visualização padrão mostra 0, 500 e todos os múltiplos de 1.000 km. Um controle mostra também 1.500, 2.500 e todos os intervalos de 500 km intermediários.

| Etapa De Revisão | Prazo Alternativo Desde A Entrega |
| --- | --- |
| 0 km | Revisão de entrega |
| 1.000 km | 6 meses |
| 6.000 km | 12 meses |
| 12.000 km | 18 meses |
| 18.000 km | 24 meses |
| 24.000 km | 30 meses |
| 30.000 km | 36 meses |
| 36.000 km | 42 meses |
| 42.000 km | 48 meses |
| 48.000 km | 54 meses |
| 54.000 km | 60 meses |
| 60.000 km | 66 meses |
| 66.000 km | 72 meses |
| 72.000 km | 78 meses |

Em todas as revisões: **o que ocorrer primeiro**. Não atribuir meses artificiais aos cuidados intermediários de 2.000, 3.000, 4.000 ou 5.000 km.

### Interface Da Linha Do Tempo

- Banner ilustrativo da NXR 160 Bros com nome do modelo, ano, versão e fonte do manual.
- Mostrador de quilometragem com atualização e distância para próxima revisão conhecida.
- Convite para preparar lembretes.
- Filtros "Todas as etapas" e "Só revisões".
- Filtro por faixa de quilômetros e campo de busca.
- Linha vertical com pontos, etapas expansíveis e ações por componente.
- Cada serviço abre detalhes completos: quando, serviço, peça, nome no manual, ação, motivo, antecipação, observação, critério de troca e páginas.
- Botão Registrar cuidado não marca tudo como feito; abre o formulário.
- Item "Registrado" depende de registro real.
- A referência atual abre a etapa de 500 km inicialmente.
- Coluna de apoio com lista curta antes de sair, legenda de ações, regra "o que ocorrer primeiro", observação ABS/CBS e manual.
- Abaixo do calendário, continuação depois de 36.000 km.

---

## 13. Catálogo Mecânico Da Base

O arquivo de dados atual tem **32 entradas de serviço/orientação**. Copie o conteúdo original e seus IDs a partir de `src/maintenance/data.ts` ou de `CATALOGO-MANUTENCAO.json` no pacote, em vez de recriar só os itens mais conhecidos.

### Entradas E Repetições

| ID | Item | Regra Da Base |
| --- | --- | --- |
| `delivery` | Moto e documentos | 0 km, entrega |
| `break-in` | Cuidados iniciais | Primeiros 500 km, orientação de uso |
| `first-review` | Primeira revisão | 1.000 km ou 6 meses; matriz visual pendente |
| `chain` | Corrente da moto | Verificar, ajustar quando preciso, limpar e lubrificar a cada 500 km; condição/folga antes do uso |
| `tires` | Pneus, aros e bicos | A cada 1.000 km ou semanalmente; também antes de sair |
| `oil-level` | Nível do óleo | Diariamente, antes de pilotar |
| `oil` | Troca do óleo | Intervalos de 6.000 km da tabela ou um ano, o que ocorrer primeiro; coluna inicial a conferir |
| `electrical` | Parte elétrica/eletrônica | Verificar a cada 6.000 km com MCS |
| `fuel-line` | Linha de combustível | Verificar a cada 6.000 km |
| `throttle` | Acelerador | Verificar a cada 6.000 km e antes de pilotar |
| `air` | Filtro de ar | Trocar a cada 18.000 km; não lavar/soprar |
| `drain` | Dreno do filtro de ar | Limpar a cada 6.000 km e antes se indicado |
| `spark` | Vela do motor | Trocar a cada 12.000 km |
| `spark-inspect` | Verificação da vela | Repetição textual de 12.000 km, primeira posição pendente |
| `valves` | Folga das válvulas | Verificar a cada 6.000 km; ajustar pela medição |
| `oil-screen` | Tela do filtro de óleo | Limpar a cada 12.000 km, não troca automática |
| `centrifugal` | Filtro centrífugo | Limpar a cada 12.000 km |
| `idle` | Marcha lenta | Verificar a cada 6.000 km |
| `evaporative` | Vapores do combustível | Verificar a cada 18.000 km |
| `slider` | Guia/deslizador da corrente | Verificar desgaste a cada 6.000 km |
| `brake-level` | Nível do líquido de freio | A cada 6.000 km e antes de pilotar |
| `brake-fluid` | Troca do líquido de freio | A cada 24 meses, independente de km |
| `pads` | Pastilhas | Verificar desgaste a cada 6.000 km e antes de pilotar |
| `brakes` | Funcionamento dos freios | Verificar a cada 6.000 km e antes de pilotar |
| `brake-switch` | Luz do freio | Verificar a cada 6.000 km; ajustar se necessário |
| `headlight` | Direção da luz do farol | Ajustar a cada 6.000 km |
| `clutch` | Embreagem e cabo | Verificar a cada 6.000 km; funcionamento antes do uso |
| `stand` | Pezinho lateral | Verificar a cada 6.000 km |
| `suspension` | Suspensão | Verificar a cada 6.000 km |
| `fasteners` | Porcas, parafusos, fixações | Verificar a cada 12.000 km |
| `wheels` | Rodas, aros, raios | Verificar a cada 6.000 km |
| `steering` | Rolamentos da direção | Verificar folga a cada 12.000 km, ajustar se necessário |

Essa tabela resume a implementação, não substitui o manual. Condições de antecipação, notas e referências completas devem acompanhar cada registro.

### Medidas E Cuidados Que Não Podem Ser Perdidos

- Corrente: folga normal 20–30 mm; não pilotar se passar de 50 mm.
- Corrente, coroa e pinhão: trocar juntos quando excessivamente gastos/danificados, não por um km inventado.
- Pneus frios: dianteiro 22 psi; traseiro 22 psi somente piloto ou 29 psi com passageiro.
- Profundidade mínima dos sulcos: 3,0 mm em ambos.
- Ao trocar pneu, trocar também a câmara; lateral furada/danificada exige troca.
- Embreagem: folga da alavanca 10–20 mm.
- Acelerador: folga no flange da manopla 2–6 mm; retorno correto em todas as posições do guidão.
- Óleo: SAE 10W-30, API SL ou superior; o manual recomenda Pro Honda SAE 10W-30 SL, JASO MA.
- Conferência do óleo: se frio, marcha lenta 3–5 minutos; desligar e esperar 2–3 minutos; moto vertical, piso plano; vareta limpa inserida sem rosquear.
- Líquido de freio: DOT 4 de embalagem lacrada. Não chamar de óleo de motor nem misturar DOT 4 com DOT 3.
- Não completar líquido baixo sem investigar pastilhas e vazamentos.
- Filtro de ar: a manutenção do elemento é troca, não limpeza com ar ou lavagem.
- Dreno do filtro é um tubo diferente do elemento filtrante e pode ser limpo/esvaziado.
- Guia/deslizador e apoio de borracha são peças diferentes, com limites próprios.
- Válvula, cabo, rolamento, amortecedor e peças da suspensão não recebem troca periódica inventada.
- Não incluir preço de peça/mão de obra inventado.

---

## 14. ABS E CBS

- A base permite alternar a versão sem perder dados ou supor conversão mecânica da moto.
- ABS atua apenas na roda dianteira; não atua atrás nem abaixo de 10 km/h conforme o manual consultado.
- CBS combina frenagem e não deve ser descrito como antibloqueio.
- Pastilhas dianteiras ABS: observar por baixo do cáliper/pinça; trocar ambas quando uma atingir o indicador.
- Pastilhas dianteiras CBS: observar pela frente do cáliper/pinça; limite descrito como parte inferior do indicador.
- Pastilhas traseiras: observar pelo lado direito traseiro; trocar ambas quando uma atingir o indicador.
- Falha ABS: reduzir velocidade e procurar concessionária rapidamente. O manual descreve freio convencional sem função antibloqueio, não proibição automática absoluta só por essa luz.
- Falha PGM-FI: também seguir a orientação específica do manual, sem inventar outro nível de severidade.
- Ao mudar a versão, detalhes visuais e textos correspondentes mudam; não alterar prazos sem suporte no manual.

---

## 15. Lista Antes De Pilotar

Somente os nove itens previstos nas páginas 48–49:

1. Combustível.
2. Acelerador.
3. Nível do óleo e vazamentos.
4. Corrente, condição e folga; ajuste/lubrificação se necessários.
5. Funcionamento dos freios, nível dos líquidos e pastilhas.
6. Luzes, indicadores e buzina.
7. Embreagem e folga, se necessário.
8. Interruptores, especialmente o do motor.
9. Rodas e pneus, condições e pressão.

Complemento para fora do asfalto:

1. Raios apertados e aros sem danos.
2. Tampa do tanque fechada.
3. Cabos/peças soltas ou algo anormal.
4. Aperto dos fixadores acessíveis com a ferramenta correta.

Comportamento:

- Marcação individual e progresso 0/9 ou 0/13.
- Guardar a data local.
- Recomeçar a lista em um novo dia, sem fabricar horário de uma checagem não feita.
- Botão para nova verificação no mesmo dia.
- Completar a lista suprime o aviso de hoje, não os próximos dias.
- Não confundir completar checklist com revisão realizada ou certificação mecânica.
- Manter observação de que a checagem é antes de cada saída, mesmo que o lembrete tenha um horário só.

---

## 16. Uso Intenso E Cuidados Por Condição

### Situações De Uso

- Poeira: itens cobertos pela nota 4, incluindo óleo, filtro de ar, corrente e pastilhas; remover sujeira da suspensão conforme instrução específica.
- Lama: mesmas notas aplicáveis e limpeza de resíduos abrasivos.
- Chuva/lavagem: corrente e dreno com maior frequência; dreno após lavagem/queda ou resíduos visíveis.
- Umidade: nota 4 e proteção contra oxidação.
- Aceleração máxima/rápida frequente: nota 5, principalmente corrente e dreno.
- Fora do asfalto: nota 8 para corrente, deslizador, fixações, rodas e pneus; antes da trilha e ao retornar ao asfalto.
- Perto do mar: lavar/secar/remover elementos agressivos; antioxidante só nos pontos permitidos, motor frio, longe dos freios.
- Uso para trabalho: maior frequência de aperto conforme p. 17; preservar o aviso da p. 11 contra o transporte remunerado de carga previsto como não recomendado para este modelo.

Selecionar uma condição destaca os cuidados relacionados. Não reduzir todos os prazos pela metade e não criar uma troca de líquido de freio anual por maresia sem manual.

### Condições A Exibir

- Pastilhas no indicador.
- Pneus gastos, furados, danificados, pressão inadequada e válvula inclinada.
- Corrente irregular, roletes danificados, pinos presos/frouxos, engrenagens gastas.
- Cabo de embreagem dobrado/gasto e ajuste insuficiente.
- Suspensão com sujeira abrasiva, dano, vazamento ou desalinhamento.
- Folga na direção e avaliação dos rolamentos.
- Fixações/raios soltos e aros oscilando.
- Guia/deslizador e apoio nos limites de desgaste.
- Óleo deteriorado/contaminado.
- Dreno com resíduos.
- Pezinho preso, ruidoso ou mola fraca.
- Bateria e terminais sujos/corroídos; falha depois de carregar.

### Segurança

- Água entrou no motor: desligar imediatamente e encaminhar para eliminação da água e manutenção.
- Corrente com folga acima de 50 mm: não usar até corrigir.
- Pneu no limite ou lateral danificada: substituir conforme manual.
- Colisão com dano que impede pilotagem segura: não pilotar.
- Falha no checklist: corrigir antes de sair.
- ABS/PGM-FI: preservar orientação específica de reduzir velocidade e procurar assistência, sem torná-la uma proibição inventada.
- Reparo temporário de pneu: manter o limite e os avisos do manual; não normalizar pilotagem prolongada com reparo provisório.

---

## 17. Histórico De Serviços

- Categorias: cuidado de rotina, revisão programada, conserto por desgaste/defeito.
- Campos: data real, quilômetros no atendimento, etapa relacionada opcional, serviços efetivamente feitos, comprovante e observações.
- Não selecionar automaticamente todos os serviços de uma revisão.
- A seleção explícita de `oil` reinicia o relógio da troca de óleo.
- A seleção explícita de `brake-fluid` reinicia o relógio da troca do líquido de freio.
- Selecionar só "revisão" não presume essas trocas.
- Confirmação de que o atendimento já aconteceu.
- Não aceitar data futura ou anterior à entrega conhecida.
- Etapa intermediária de rotina não pode ser gravada como revisão programada sem ajuste de tipo.
- Histórico ordenado do mais antigo para o mais recente, com busca, exclusão confirmada e exportação.
- Excluir registro recalcula lembretes; não deve apagar quilômetros posteriores ou outros serviços silenciosamente.
- Backup de dados e código-fonte são coisas diferentes.

---

## 18. Conta Local, Persistência E Compatibilidade

### Chaves Existentes

- Estado principal no navegador: **`bros-maintenance-planner-v1`**.
- Histórico de notificações: **`bros-notification-journal-v1`**.

Não trocar as chaves e perder os dados. Se mudar o formato, criar migração testada e manter uma cópia antes de converter.

### Estrutura Principal Atual

- `version`: 1.
- `profile`: year, variant, km, purchaseDate, oilDate, brakeDate, usage, configured.
- `records`: atendimentos reais informados.
- `mileageReadings`: histórico de quilômetros, máximo 250.
- `reminders`: configurações de aviso.
- `checklist`: date, checked, offroad.

### Campos Dos Registros

`MaintenanceRecord`: id, milestone, type, date, km, serviceIds, notes, document.

`MileageReading`: id, km, previousKm, createdAt, source, note.

`Service`: id, component, manualName opcional, service, actions, frequency, kmInterval opcional, timeMonths opcional, description, reason, anticipation, notes, replacement, refs, severe, group, pending opcional, abs/cbs opcionais.

`ReminderSettings`: enabled, activatedAt, pausedUntil, checklist, mileage, maintenance, quiet, snoozed.

### Padrões Da Versão Transferida

- Avisos globais desligados até consentimento.
- Categorias habilitadas como preferências, mas sem envio antes da ativação global.
- Lista: todos os dias, 07h30.
- Quilômetros: a cada 3 dias, 18h30, para novos cadastros.
- Cuidados: 09h00, 7 dias antes de uma data conhecida, repetir aviso a cada 7 dias se seguir pendente.
- Descanso: 21h00–07h00.
- Histórico de avisos: até 60 eventos e 300 chaves de deduplicação.
- Preserve preferências de versões antigas, inclusive a escolha anterior de 7 dias, até o usuário mudá-la.

### Requisitos De Confiabilidade

- Validar JSON do armazenamento e arquivos importados.
- Não falhar a tela inteira por dados antigos ou corrompidos.
- Não inventar datas de registros migrados.
- Atualização entre abas sem ciclos de escrita.
- Calcular meses respeitando o último dia do mês, fevereiro e anos bissextos.
- Respeitar data local do usuário em checklist e horários, sem deslocamento por UTC indevido.
- Ao apagar tudo, cancelar os próprios avisos primeiro; se houver falha, explicar e não afirmar sucesso.
- Eventos de calendário externo precisam ser removidos pelo usuário.
- No Android final, revisar a persistência local apropriada e a migração do armazenamento web para o armazenamento do pacote.

---

## 19. Exportações E Arquivos

Preservar:

- Plano completo em texto Markdown, com todas as etapas, ações, notas e páginas.
- Impressão/PDF do plano inteiro, não apenas da parte visível da tela.
- Histórico de manutenção em CSV.
- Histórico de quilometragem em CSV.
- Backup dos dados em JSON.
- Agenda ICS com rotinas e prazos conhecidos, `VALARM` e regras recorrentes.
- Download do mega prompt e pacote de transferência do código.

Cuidados:

- Usar nomes de botão simples: Baixar plano, Baixar planilha, Guardar meus dados.
- Proteger células de planilha contra fórmulas injetadas por texto.
- Escapar corretamente CSV, Markdown e ICS.
- Em ICS, respeitar quebras de linha, fuso/horário, dias após silêncio cruzar meia-noite e UTF-8.
- Informar que baixar ICS não importa nem ativa os alarmes automaticamente.
- Não alegar sincronização bidirecional de agenda.
- Importação e compartilhamento no Android WebView precisam de teste e, se necessário, integração nativa de arquivos/compartilhamento.
- Ao transferir o projeto, dados pessoais ficam excluídos por padrão. Nunca exportar `.env`, senhas, chaves de assinatura ou credenciais administrativas.
- A ferramenta de código-fonte é de desenvolvimento/transferência; avaliar removê-la do aplicativo público depois, especialmente quando houver backend.

---

## 20. PWA E Privacidade

- Manifesto com nome Bros., `start_url` apontando para lembretes, `display: standalone` e atalhos para quilometragem/lista.
- Service worker event-driven, cache da página principal de produção, ícones e páginas offline/privacidade.
- Não armazenar o PDF escolhido pelo usuário no cache de serviço.
- Não fingir que página de desenvolvimento com scripts do servidor Vite está pronta offline.
- Cache versionado, remoção apenas dos caches pertencentes ao app e atualização com aviso ao usuário.
- Ícones atuais são SVG de 192 e 512; produzir PNGs/adaptive icons quando necessário para compatibilidade de instalação real e pacote Android.
- Função de receber evento `push` no worker não significa serviço push conectado. Ainda é necessário backend e inscrição consentida.
- URLs de abertura de notificação devem ser permitidas e internas, não aceitas livremente de payload externo.
- Manter página de privacidade descrevendo dados locais, notificações, agenda e conexões externas.
- Fontes vêm do Google Fonts; fotos da Potiguar Honda; páginas do manual do ManualPDF. Isso envolve solicitações externas e deve ser descrito.
- Antes de distribuição pública, definir responsável, contato, política da conta opcional, exclusão e direitos das imagens.
- Não adicionar analytics, publicidade ou coleta de localização sem autorização explícita e necessidade real.

---

## 21. Stack E Arquivos Do Projeto

### Stack Da Base

- React e React DOM 19.2.6.
- TypeScript 5.9.3, strict.
- Vite 7.3.2.
- Tailwind CSS 4.1.17 pelo plugin `@tailwindcss/vite`.
- Lucide React para ícones.
- Capacitor Core 8.5.x, App 8.1.x, Local Notifications 8.3.x.
- `vite-plugin-singlefile` 2.3.0 na configuração atual.
- `fflate` para gerar e conferir o ZIP de transferência no navegador.
- Não há roteador adicional: as rotas atuais usam hash e History API.
- Não há provedor de autenticação instalado/conectado atualmente.

Use `package.json` e o lockfile, se presente no pacote, como referência definitiva de versões. Não atualize tudo sem necessidade durante a reprodução.

### Arquivos Principais

| Arquivo | Responsabilidade |
| --- | --- |
| `src/App.tsx` | Navegação, estado, persistência, modais e integração de lembretes |
| `src/main.tsx` | Entrada React, estilos, PWA e limite de erros |
| `src/ui/Shell.tsx` | Menu, barra superior, dock móvel e apresentação da moto |
| `src/ui/ReminderCenter.tsx` | Central, pergunta de horário, Ativar, prévia, atividade e preferências opcionais |
| `src/ui/Timeline.tsx` | Calendário por km e tabela completa |
| `src/ui/InfoViews.tsx` | Tempo, condição, checklist, uso intenso e segurança |
| `src/ui/Odometer.tsx` | Interface de quilometragem; nome interno legado, texto público simplificado |
| `src/ui/Dialogs.tsx` | Cadastro, registro de serviço, detalhes e fonte |
| `src/ui/History.tsx` | Lista de atendimentos |
| `src/ui/PrintPlan.tsx` | Documento completo para impressão |
| `src/ui/Common.tsx` | Modais, ações, referências, avisos e termos do manual |
| `src/ui/Icon.tsx` | Ícones e identidade vetorial |
| `src/ui/AppBoundary.tsx` | Recuperação de erro e cópia dos dados |
| `src/maintenance/data.ts` | Catálogo de 32 itens, notas, limites e páginas |
| `src/maintenance/types.ts` | Contratos de dados |
| `src/maintenance/planner.ts` | Calendário, datas, histórico e exportações |
| `src/maintenance/odometer.ts` | Validação, correção e histórico de quilometragem |
| `src/maintenance/language.ts` | Explicações simples e busca por nomes do manual |
| `src/reminders/preferences.ts` | Padrões e validação das preferências |
| `src/reminders/plan.ts` | Planejamento dos avisos e agenda externa |
| `src/reminders/bridge.ts` | APIs reais web/nativas e programação |
| `src/reminders/useReminders.ts` | Integração React, eventos e entregas |
| `src/reminders/journal.ts` | Registro e deduplicação dos avisos |
| `src/reminders/pwa.ts` | Instalação, offline e atualização |
| `src/reminders/types.ts` | Contratos dos lembretes |
| `src/index.css` | Estilo-base |
| `src/responsive.css` | Ajustes visuais, responsividade e impressão |
| `src/odometer.css` | Controle de quilometragem |
| `src/reminders.css` | Central, dock e instalação |
| `public/bros-sw.js` | Worker de cache/notificações |
| `public/manifest.webmanifest` | Manifesto de instalação |
| `public/privacy.html` | Explicação de dados e privacidade |
| `public/offline.html` | Alternativa sem conexão |
| `public/icons/` | Ícones vetoriais de app e notificação |
| `public/mega-prompt-bros.md` | Este documento |
| `native-assets/android/ic_stat_bros.xml` | Ícone preparado para o Android |
| `capacitor.config.ts` | Configuração inicial nativa |
| `tests/reminders.test.mjs` | Testes escritos das regras de lembrete |
| `docs/FONTES.md` | Fontes e lacunas do manual |
| `docs/APP-E-LEMBRETES.md` | Limites de plataforma e plano Android |
| `README.md` | Visão geral e verificação declarada |

### Se O ZIP For Fornecido

1. Extrair preservando os caminhos.
2. Ler este prompt e os documentos antes de editar.
3. Não executar automaticamente scripts desconhecidos; revisar dependências e configuração.
4. Instalar dependências conforme o projeto.
5. Rodar a versão atual e fazer capturas antes de alterar.
6. Corrigir bugs sem descaracterizar o produto.
7. Implementar conta opcional e entrega Android conforme as novas prioridades.

### Se Só Este Prompt For Fornecido

Recriar as telas e regras descritas, deixando claro que uma identidade visual exata exige os arquivos/capturas. Pedir o PDF da Honda para validar a matriz pendente. Não inventar os trechos ausentes nem criar conta/notificação fake para preencher a apresentação.

---

## 22. Problemas A Auditar, Não A Reproduzir Cegamente

Estes são pontos que precisam de verificação durante a continuação. Não são declarações de testes realizados:

- Paginação da agenda por meses: limitar o botão ao valor anunciado, evitando exibir além de 120 meses quando o texto promete 120.
- Prazos de rotina com histórico desconhecido: não misturar a exibição de "dados incompletos" com afirmação de serviço certamente vencido.
- Limpeza de notificações nativas: não perder programação válida por estado temporário de permissão ainda não verificada ao iniciar.
- Notificações nativas ao chegar ao horário: não cancelar um alarme inexato que está prestes a ser entregue só porque o relógio de recálculo passou da hora.
- Janela de 28 dias: manter um convite real e suportado para o usuário que não abre o aplicativo, sem depender exclusivamente de renovação manual esquecível.
- Duplicação por duas abas, re-render, React StrictMode, reinício ou chamadas concorrentes.
- Data/fuso e silêncio que cruza meia-noite, inclusive o aviso de ontem transferido para hoje.
- Conflito entre horário usual de saída e descanso: mostrar o efeito com clareza e facilitar o ajuste, sem ignorar uma escolha explícita do usuário.
- Recebimento e navegação ao iniciar a partir da notificação, não só com app já aberto.
- Backup e restauração precisam preservar dados e estado de permissões corretamente, sem restaurar consentimento de um aparelho em outro automaticamente.
- Exportação por Blob/download e impressão no WebView Android: pode precisar de compartilhamento/armazenamento nativo.
- Serviço offline no Android vs navegador, origem/base URL e arquivos públicos.
- Ícones PWA SVG e compatibilidade real de instalação.
- Contraste dos textos suaves, fontes pequenas e tamanho dos alvos de toque.
- Foco de modal, Escape/Voltar, leitor de tela, tabs de teclado e teclado virtual.
- Direito de uso das fotos externas e carregamento sem conexão.
- Dependências com alertas de segurança devem ser auditadas; não afirmar que o projeto foi auditado apenas porque compilou.

Não preserve um bug em nome da fidelidade. Preserve a intenção, os dados e o design, e registre a correção.

---

## 23. Plano De Implementação Para A Próxima IA

1. Inventariar arquivos e executar a base web sem mudanças.
2. Conferir IDs, armazenamento e todas as telas contra este documento.
3. Preservar a pergunta de horário, padrão de quilometragem a cada 3 dias e botão Ativar, sem exigir configuração avançada.
4. Validar os fluxos existentes e consertar falhas de data, permissão, concorrência e instalação.
5. Gerar um projeto Android real e testar os lembretes locais.
6. Resolver a duração da programação para não depender de o usuário lembrar de renová-la manualmente.
7. Implementar restauração segura de backup e conta opcional com provedor real, preservando o uso sem conta.
8. Conferir visualmente as páginas pendentes do manual original.
9. Produzir APK real para instalação direta e instruções simples.
10. Entregar lista do que foi executado e do que ficou bloqueado. Não publicar na Play Store sem autorização.

Evite reescrever o projeto inteiro antes de fazê-lo rodar. Faça mudanças verificáveis, com pequenas etapas e testes.

---

## 24. Critérios De Aceitação

### Produto

- As nove telas existem e são navegáveis em desktop e celular.
- O usuário consegue fazer tudo sem conta.
- Conta opcional funciona com autenticação real quando configurada, sem dados cruzados entre usuários.
- Horário de saída é perguntado dentro do app.
- Padrões automáticos permitem tocar em Ativar sem preencher uma ficha de alarmes.
- Preferências existentes não são sobrescritas silenciosamente.
- Quilometragem funciona com total e soma, validações, correções, histórico e distância restante.
- Registro de revisão não presume troca de óleo/líquido de freio.
- Todas as regras e ações do manual continuam rastreáveis.
- Outros modelos não são adicionados nesta etapa.

### Notificações

- Nenhuma permissão é solicitada sem ação do usuário.
- Ativar chama uma API real de notificações.
- Teste gera solicitação de aviso no sistema, não só toast.
- A interface separa permissão, programação, falha e pedido de exibição.
- O toque abre a ação certa.
- Não duplica avisos em múltiplas abas ou reagendamentos.
- Completar a lista cancela/suprime apenas o convite correspondente, não os cuidados futuros.
- Adiar aviso não altera o prazo do cuidado.
- Não Perturbe, bateria restrita e force-stop são documentados sem promessa falsa.
- Android foi testado com tela apagada, sem internet, ao reiniciar e com app não aberto.
- O mecanismo de longo prazo foi testado; não depende apenas de abrir o app a cada 28 dias sem avisar essa limitação.

### Dados E Segurança

- Dados existentes migram sem perda.
- Registros com datas desconhecidas continuam desconhecidos, não recebem data inventada.
- Backup exporta e restaura com confirmação.
- Conta opcional isola dados por usuário.
- Nenhuma chave de serviço, senha ou assinatura é exposta no cliente ou no ZIP.
- Exclusão é confirmada e tenta cancelar notificações; falha não é escondida.
- Página de privacidade corresponde ao funcionamento real.

### Verificação

- Compilação web sem erro.
- Verificação TypeScript separada quando disponível; lembrar que `vite build` sozinho não é prova de typecheck completo.
- Testes unitários das regras executados, com resultado registrado.
- Testes de interface executados, não apenas arquivos de teste escritos.
- Testes físicos de Android registrados com versão do aparelho/SO e cenários.
- Arquivo APK realmente existe se a entrega afirmar que está pronto para instalação.
- Aparência comparada às capturas/base, sem conteúdo cortado ou botões ilegíveis.
- Se algo não foi testado, dizer claramente.

---

## 25. Exemplos De Testes Obrigatórios

1. Abrir sem conta e sem dados: nenhuma revisão é marcada e nenhum prazo pessoal é inventado.
2. Informar 5.200 km: total formatado, histórico criado e lembretes recalculados, sem revisão registrada.
3. Somar 35 km: prévia 5.235 km; só salvar depois de confirmação.
4. Corrigir para 5.100 km: exigir confirmação e motivo; não reduzir abaixo de um atendimento real registrado.
5. Trocar óleo registrado explicitamente: apenas o prazo do óleo é recalculado.
6. Registrar revisão sem marcar óleo: não reiniciar prazo do óleo.
7. Fazer a segunda revisão por km antes de 12 meses: não duplicar por chegar aos 12 meses.
8. Checklist preenchido hoje: convite de hoje suprimido e de amanhã preservado.
9. Quilometragem registrada hoje: lembrete de atualização recomeça conforme a frequência pessoal, não os prazos mecânicos.
10. Aviso às 23h, descanso até 07h: transferir ao dia seguinte, incluindo dia da semana na exportação.
11. Pausa de 24h: não mostrar avisos durante pausa nem modificar datas originais.
12. Adiar para amanhã, mesmo com recorrência de 3 ou 7 dias: criar o aviso desejado sem duplicação.
13. Permissão recusada: não insistir em popups e não informar ativado.
14. Sistema aceita solicitação mas oculta por Não Perturbe: não chamar de aviso visualizado.
15. Reabrir por notificação de quilômetros: abrir diretamente o controle de quilometragem.
16. Fechar o navegador: não prometer entrega; mostrar a diferença em relação ao pacote Android.
17. Passar mais de 28 dias sem abrir o Android: validar a estratégia que evita o silêncio definitivo dos convites.
18. Importar backup inválido: não apagar dados bons.
19. Convidado cria conta: migração consentida sem duplicar registros.
20. Sair da conta: continuar usando o app sem ficar bloqueado.
21. Reiniciar o Android: verificar se programação persiste/reagenda conforme a estratégia implementada.
22. Apagar dados: cancelar os avisos do app ou informar claramente a falha antes de concluir.
23. Procurar "fluido", "líquido", "cavalete", "pezinho", "deslizador" ou "guia": encontrar o item correto sem depender do acento.
24. Gerar planilha com texto começando por `=`: tratar como texto, não fórmula.
25. Abrir offline depois do primeiro carregamento: permitir consulta ao conteúdo local e aos registros.

---

## 26. Entrega Esperada

Ao concluir, forneça:

- Projeto completo, organizado e reproduzível.
- Resumo das mudanças em relação à base.
- Instruções curtas de instalação direta no Android.
- APK real, quando o ambiente permitir gerar e testar.
- Lista de serviços externos necessários à conta opcional e como configurá-los, sem expor segredos.
- Plano de migração dos dados existentes.
- Testes executados e seus resultados reais.
- Lista exata de pendências, incluindo manual, permissões e distribuição, se ainda existirem.
- Capturas ou descrição de comparação com a interface original.

Na resposta ao proprietário, use palavras simples. Explique primeiro o que ele consegue fazer. Detalhes de SDK, servidor, API e assinatura ficam na documentação ou numa seção técnica separada.

Não diga "está pronto" se apenas fez o desenho. Não diga "notificação real funcionando fechado" sem teste no pacote instalado. Não diga "conta criada" se apenas salvou nome/e-mail localmente. Não diga "recriei exatamente" se não teve acesso aos arquivos/capturas.

O resultado deve ser o **mesmo Bros. atual, preservado e melhorado**, com instalação Android e conta opcional reais, ativação simples e lembretes honestos.

## 27. Família CG 160 (Fan, Start, Titan, Cargo): Estado Atual E Regras

Esta seção descreve o que existe hoje no código além da Bros. Em caso de conflito com a seção 1, vale esta.

### Modelos Cadastrados

- Fan: de 2013 (CG 150) em diante, com chaves `FAN-2013` a `FAN-2019` e os anos seguintes. Start 2026 (`START-2026`) e Titan 2026 (`TITAN-2026`).
- Cargo ESDi/CES: 2016 a 2026 (`CARGO-2016` … `CARGO-2026`). Cargo 2016 e 2017 usam o manual D2203-MAN-1026, 2018 usa o D2203-MAN-1129, 2019 a 2022 usam o D2203-MAN-1187 e 2023 a 2026 usam o D2203-MAN-1305.
- Cargo 2016 a 2022 não têm CBS nem ABS. Cargo 2023 em diante têm CBS.

### Cargo 2016/2017 (conferido no manual D2203-MAN-1026)

- Revisões: 1.000 km ou 6 meses; 6.000 km ou 12 meses; depois a cada 6.000 km com prazo de km/1.000 + 6 meses.
- Óleo SAE 10W-30 SJ ou superior, JASO MA, 1,0 litro na troca, a cada 6.000 km ou uma vez por ano. Fluido DOT 3 ou DOT 4, troca a cada 2 anos. Corrente DID 428HX, folga 15–25 mm, verificar a cada 1.000 km. Vela com folga de 0,80–0,90 mm, verificar e trocar a cada 12.000 km. Filtro de ar úmido a cada 18.000 km.
- Não existem na Cargo: CBS/ABS, `LOWER/UPPER`, óleo Mobil, corrente RK 428HSB.
- As páginas por item não são citadas; o app aponta o manual inteiro.

### Regras Que Já Causaram Bugs

- O intervalo da corrente (500 ou 1.000 km) vem do catálogo do modelo (`chainStepKm` em `planner.ts`). Linha do tempo, lembretes e plano exportado devem usar essa mesma função.
- `first-review` não entra nas revisões periódicas de 6.000 km em diante.
- Ao montar serviços com `{ ...base, ...override }`, nunca deixe `undefined` no override: ele apaga o valor do base (`definedOnly` em `data.ts`).
- Textos herdados da Bros/Fan (notas, páginas, "nota 1", "p. 91") não valem para a Cargo. O filtro `cargoText` remove "nota N" sem diferenciar maiúsculas.
- Páginas fixas da NXR 2025/2026 (p. 91, 44, 46, 48 e 49) só aparecem nesse modelo; nos outros, o texto diz "conforme o manual".
- Fan 2013/2014 usam ciclo de revisão de 4.000 km (`reviewMonths`, `timeRows`, texto "Depois de 36.000 km").
- Os testes `tests/*-audit.test.mjs` conferem o texto do código-fonte. Eles não substituem rodar o código; use também `tests/regression-bugs-cargo-fan.test.mjs`.

## Fim Do Prompt
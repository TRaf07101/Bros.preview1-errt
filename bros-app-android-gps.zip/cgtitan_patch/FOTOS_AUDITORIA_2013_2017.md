# Auditoria de fotos — NXR 2013–2017

Revisão individual das combinações atualmente expostas no app. Fontes cromáticas conferidas em reportagens e galerias de época; as fotos históricas são tratadas no navegador para remover o fundo branco antes de entrar no hero.

## 2013 — NXR 150 Bros
- ES: Vermelha, Preta, Verde
- ESD: Vermelha, Preta, Verde
- Fontes de referência de cores: Motonline e Padrão Off-Road.

## 2014 — NXR 150 Bros
- ES: Vermelha/Branca, Branca/Preta, Branca/Azul, Preta/Branca
- ESD: Vermelha/Branca, Branca/Preta, Branca/Azul, Preta/Branca
- A combinação azul usa fonte de produto em fundo claro; a etapa de remoção preserva os tons saturados e neutraliza apenas eventuais pretos com dominante avermelhada.

## 2015 — NXR 160 Bros
- ESD: Vermelha/Branca, Branca/Preta, Preta/Cinza
- ESDD: Vermelha/Branca, Branca/Preta, Preta/Cinza
- A foto vermelha usa produto em fundo branco e o processamento agora corta barras pretas laterais antes da validação.
- A foto Preta/Cinza foi trocada para a tomada 2015-7, em três quartos dianteiro, para alinhar a direção com a maioria das fotos do app.

## 2016 — NXR 160 Bros
- ES: Vermelha/Branca, Preta
- ESDD: Vermelha/Preta, Branca/Preta, Preta
- Todas usam referências de divulgação/produto da galeria 2016; as fotos são normalizadas para o mesmo canvas transparente.

## 2016/2017 e 2017/2018
- ESDD: Vermelha/Branca, Azul/Branca
- ES: Preta, Branca
- A linha 2017 foi conferida com fontes contemporâneas: ESDD em vermelho e azul; versão de entrada em preto/branco.

## Regras de processamento
1. Foto original é validada antes da criação da tela transparente.
2. Barras pretas uniformes de enquadramento são removidas.
3. Fundo conectado às bordas é removido por flood-fill de cor clara/baixa saturação.
4. Componentes isolados de sombra/ruído são descartados.
5. Pretos com dominante vermelha em fotos comprimidas são neutralizados sem alterar cores saturadas da carenagem.
6. Moto final é centralizada em 1536×1024.

## Fontes consultadas
- Honda/Motonline — NXR 160 Bros 2017 e informações de versão/cor.
- Auto Esporte — apresentação da NXR 160 Bros 2017.
- Padrão Off-Road — histórico de cores da Bros 150/160.
- Motoo — galerias/fotos de NXR 160 Bros 2015/2016.


## Correção de fotos 2023/2024
A edição 2023/2024 agora possui três assets locais explícitos (`bros-2023-2024-cbs-preta.webp`, `...-vermelha.webp`, `...-branca.webp`), derivados dos assets transparentes já auditados da mesma família visual. O caminho local usa `import.meta.env.BASE_URL`, evitando 404 quando a aplicação é publicada em subpasta (ex.: GitHub Pages).


## Correção 2013–2016 — 12/09/2026
- RemoteMotorcycleImage: foto remota direta é exibida como fallback real; processamento transparente é oportunístico.
- Corrigido bug de stride após cropUniformFraming que podia invalidar a detecção da silhueta.
- 2013: NXR 150 Bros ES/ESD; cores vermelha, preta e verde.
- 2014: NXR 150 Bros ES/ESD; cores vermelha, branca e preta.
- 2015: NXR 160 Bros ESD/ESDD; cores vermelha, branca e preta.
- 2016: NXR 160 Bros ES; vermelha e preta. ESDD; vermelha, branca e preta.
- Nenhuma entrada abaixo de 2013 foi adicionada.

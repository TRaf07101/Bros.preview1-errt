# Auditoria Cargo 2019 e 2020

**Fonte usada:** Manual do Proprietário Honda CG 160 Cargo (2019), D2203-MAN-1187, lido por completo.
Tabela de manutenção nas páginas impressas 37 a 40.

- **2019:** manual do próprio ano.
- **2020:** não foi localizado manual específico; o de 2019 é a edição mais próxima. Os prazos podem diferir em algum item.
- **Cor branca (única):** vem de anúncios e da imprensa, não do manual.
- **Foto:** reaproveita a foto oficial da Cargo branca atual (não foi achada foto de 2019/2020).

## O que difere do catálogo base (NXR/Fan) e foi corrigido só nestes dois anos
| Item | Catálogo base | Manual da Cargo |
|---|---|---|
| Corrente: intervalo | 500 km | a cada 1.000 km |
| Corrente: folga | 20–30 mm | 15–25 mm (limite 50 mm) |
| Acelerador: folga | 2–6 mm | 2–5 mm |
| Pneus | psi e câmara de ar de outro modelo | pressão na tabela do manual; sem psi inventado |
| Suspensão dianteira (fluido) | sem prazo | 24.000 km |
| Suspensão traseira (lubrificar) | 18.000 km | 24.000 km |
| Coluna de direção | folga 12.000 km | folga 6.000 km; lubrificar 18.000 km |
| Fluido de freio | Pro Honda | Mobil Super Moto DOT 4 (troca a cada 2 anos) |
| Sistema evaporativo | presente | não existe na tabela da Cargo |
| Filtro de combustível, travas, escapamento | ausentes | 12.000 / 12.000 / 6.000 km |

Referências de página e de nota do manual da NXR foram removidas dos textos desses dois anos.

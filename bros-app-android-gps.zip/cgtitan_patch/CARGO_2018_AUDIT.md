# Auditoria Cargo 2018

**Fonte usada:** Manual do Proprietário Honda CG 160 Cargo (2018), D2203-MAN-1129, lido por completo.
Tabela de manutenção nas páginas impressas 35 a 38.

- A tabela de manutenção e os valores de corrente (15–25 mm, limite 50 mm, a cada 1.000 km), acelerador (2–5 mm),
  embreagem, vela, suspensão (24.000 km) e freios são **iguais** aos do manual de 2019. Por isso a Cargo 2018 usa as
  mesmas correções da Cargo 2019/2020 (ver `CARGO_2019_2020_AUDIT.md`); só a referência de manual e as páginas mudam.
- A Cargo 2018 foi a primeira com CBS (disco dianteiro, tambor traseiro, sem ABS), motor flex, cavalete central de série
  e bagageiro de 20 kg.
- **Cor branca (única):** vem da imprensa (lançamento da linha 2018), não do manual.
- **Foto:** reaproveita a foto oficial da Cargo branca atual (não foi achada foto de 2018).
- **Pressão e profundidade mínima dos pneus:** ficam na tabela de especificações (p. 102 do manual), que não foi lida;
  o app manda conferir no manual em vez de repetir valores de outro modelo.
- A Cargo anterior (2016/2017, "ESDi") não tinha CBS e fica fora desta entrega.

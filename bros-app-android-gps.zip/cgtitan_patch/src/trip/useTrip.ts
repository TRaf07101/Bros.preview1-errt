import { useCallback, useEffect, useRef, useState } from 'react';
import { addFix, newTrack, normalizeTrack } from './gps';
import type { Fix, TripTrack } from './gps';
import { isNativeTrip, startNativeWatch, stopNativeWatch } from './native';

const KEY = 'bros-active-trip';
export interface TripController {
  supported: boolean;
  /** True no app instalado: o rastreio continua com a tela bloqueada ou em outro app. */
  native: boolean;
  /** Viagem em andamento (null se não há). */
  track: TripTrack | null;
  /** Viagem terminada, aguardando o usuário somar ou descartar. */
  finished: TripTrack | null;
  /** True quando o GPS não enviou pontos recentemente. */
  weakSignal: boolean;
  error: string;
  start: () => void;
  stop: () => void;
  cancel: () => void;
  clearFinished: () => void;
}

const persist = (track: TripTrack | null) => { try { if (track) localStorage.setItem(KEY, JSON.stringify(track)); else localStorage.removeItem(KEY); } catch { /* sem armazenamento: a viagem segue só na memória */ } };
const stored = (): TripTrack | null => { try { const raw = localStorage.getItem(KEY); return raw ? normalizeTrack(JSON.parse(raw)) : null; } catch { return null; } };

export function useTrip(): TripController {
  const native = isNativeTrip();
  const supported = native || (typeof navigator !== 'undefined' && 'geolocation' in navigator);
  const [track, setTrack] = useState<TripTrack | null>(null);
  const [finished, setFinished] = useState<TripTrack | null>(null);
  const [weakSignal, setWeakSignal] = useState(false);
  const [error, setError] = useState('');
  const ref = useRef<TripTrack | null>(null);
  const watch = useRef<number | null>(null);
  const wake = useRef<WakeLockSentinel | null>(null);
  const lastFixAt = useRef(0);

  const requestWake = useCallback(() => {
    if (native || !('wakeLock' in navigator)) return;
    navigator.wakeLock.request('screen').then(lock => { wake.current = lock; }).catch(() => { /* a tela pode apagar; o aviso na tela explica */ });
  }, [native]);
  const halt = useCallback(() => {
    if (native) void stopNativeWatch();
    else if (watch.current !== null) navigator.geolocation.clearWatch(watch.current);
    watch.current = null;
    wake.current?.release().catch(() => undefined); wake.current = null;
  }, [native]);

  const begin = useCallback((initial: TripTrack) => {
    ref.current = initial; setTrack(initial); setError(''); setWeakSignal(false); lastFixAt.current = Date.now();
    persist(initial);
    const onFix = (fix: Fix) => {
      if (!ref.current) return;
      const next = addFix(ref.current, fix);
      lastFixAt.current = Date.now(); setWeakSignal(false);
      if (next !== ref.current) { ref.current = next; setTrack(next); persist(next); }
    };
    const denied = () => {
      halt(); ref.current = null; setTrack(null); persist(null);
      setError(native
        ? 'O app não tem permissão de localização. Abra Configurações do celular › Apps › Bros. › Permissões › Localização, escolha "Permitir" e tente de novo. Se pedir, permita também as notificações.'
        : 'O app não tem permissão para usar a localização. Libere em Configurações do navegador › Permissões do site › Localização e tente de novo.');
    };
    if (native) {
      startNativeWatch(onFix, denied, () => setWeakSignal(true)).catch(() => { halt(); ref.current = null; setTrack(null); persist(null); setError('Não foi possível iniciar o GPS do celular. Confira se a localização está ligada e tente de novo.'); });
    } else {
      watch.current = navigator.geolocation.watchPosition(
        position => onFix({ lat: position.coords.latitude, lon: position.coords.longitude, t: position.timestamp, acc: position.coords.accuracy }),
        failure => { if (failure.code === failure.PERMISSION_DENIED) denied(); else setWeakSignal(true); },
        { enableHighAccuracy: true, maximumAge: 0, timeout: 30000 },
      );
    }
    requestWake();
  }, [halt, requestWake, native]);

  const start = useCallback(() => { if (supported && !ref.current) { setFinished(null); begin(newTrack(Date.now())); } }, [supported, begin]);
  const stop = useCallback(() => { const done = ref.current; halt(); ref.current = null; setTrack(null); persist(null); setFinished(done); }, [halt]);
  const cancel = useCallback(() => { halt(); ref.current = null; setTrack(null); persist(null); }, [halt]);
  const clearFinished = useCallback(() => setFinished(null), []);

  // Retoma uma viagem que estava em andamento se o app foi recarregado.
  useEffect(() => { const resumed = supported ? stored() : null; if (resumed) begin(resumed); return halt; }, [supported, begin, halt]);
  // A tela ligada é liberada ao sair do app; ao voltar, pede de novo e avisa se o GPS ficou parado.
  useEffect(() => {
    const visible = () => { if (document.visibilityState === 'visible' && ref.current && !native) { requestWake(); if (Date.now() - lastFixAt.current > 20000) setWeakSignal(true); } };
    document.addEventListener('visibilitychange', visible);
    return () => document.removeEventListener('visibilitychange', visible);
  }, [requestWake, native]);

  return { supported, native, track, finished, weakSignal, error, start, stop, cancel, clearFinished };
}

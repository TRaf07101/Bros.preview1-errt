/// <reference types="vite/client" />
interface ImportMetaEnv {
  /** Endereço do backend do rastreador (pasta server/). Vazio = função indisponível, sem simulação. */
  readonly VITE_BROS_API_URL?: string;
}

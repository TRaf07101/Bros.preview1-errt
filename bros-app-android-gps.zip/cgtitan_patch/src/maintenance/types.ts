import type { ReminderSettings } from '../reminders/types';

export type BikeFamily = 'NXR' | 'FAN' | 'START' | 'CARGO' | 'TITAN';
export type Variant = 'ABS' | 'CBS' | 'ES' | 'ESD' | 'ESDD' | 'KS';
// NXR-20xx ids are canonical internal identifiers for individual NXR model years; grouped ranges below are legacy/manual-reference values only.
export type ModelYear = 'FAN-2013' | 'FAN-2014' | 'FAN-2015' | 'FAN-2016' | 'FAN-2017' | 'FAN-2018' | 'FAN-2019' | '2013' | '2014' | '2015' | '2015/2016' | '2016' | '2016/2017' | '2017' | '2017/2018' | '2018' | '2018/2019' | '2019' | '2019/2020' | 'NXR-2020' | 'NXR-2021' | 'NXR-2022' | 'NXR-2023' | 'NXR-2024' | 'NXR-2025' | 'NXR-2026' | '2020' | '2020/2021' | '2021' | '2021/2022' | '2022' | '2022/2023' | '2023' | '2023/2024' | '2024' | '2024/2025' | '2025' | '2025/2026' | '2026' | 'START-2026' | 'START-2022' | 'START-2015' | 'CARGO-2013' | 'CARGO-2014' | 'CARGO-2015' | 'CARGO-2016' | 'CARGO-2017' | 'CARGO-2018' | 'CARGO-2019' | 'CARGO-2020' | 'CARGO-2021' | 'CARGO-2022' | 'CARGO-2023' | 'CARGO-2024' | 'CARGO-2025' | 'CARGO-2026' | 'TITAN-2026';
export type BikeColor = 'preta' | 'vermelha' | 'branca' | 'azul' | 'cinza' | 'laranja' | 'verde' | 'prata';
export type ActionType = 'inspect' | 'adjust' | 'clean' | 'lubricate' | 'replace' | 'repair';
export type View = 'timeline' | 'time' | 'condition' | 'checklist' | 'severe' | 'safety' | 'consolidated' | 'history' | 'reminders';
export type Usage = 'dust' | 'mud' | 'rain' | 'humidity' | 'acceleration' | 'offroad' | 'coast' | 'commercial';

export interface Reference {
  page: string;
  viewer: number;
  section?: string;
}

export interface Service {
  id: string;
  component: string;
  manualName?: string;
  service: string;
  actions: ActionType[];
  frequency: string;
  kmInterval?: number;
  timeMonths?: number;
  description: string;
  reason: string;
  anticipation: string;
  notes: string;
  replacement: string;
  refs: Reference[];
  severe: Usage[];
  group: 'scheduled' | 'routine' | 'condition' | 'guidance';
  pending?: boolean;
  abs?: string;
  cbs?: string;
}

export interface Milestone {
  km: number;
  months: number | null;
  title: string;
  subtitle: string;
  kind: 'delivery' | 'routine' | 'review';
  services: Service[];
  notice?: string;
}

export interface Profile {
  family: BikeFamily;
  year: ModelYear;
  variant: Variant;
  color: BikeColor;
  km: number;
  purchaseDate: string;
  oilDate: string;
  brakeDate: string;
  usage: Usage[];
  configured: boolean;
}

export interface MaintenanceRecord {
  id: string;
  milestone: number | null;
  type: 'review' | 'routine' | 'condition';
  date: string;
  km: number;
  serviceIds: string[];
  notes: string;
  document: string;
}

export type MileageSource = 'manual' | 'trip' | 'profile' | 'maintenance' | 'legacy' | 'tracker';

export interface MileageReading {
  id: string;
  km: number;
  previousKm: number | null;
  createdAt: string | null;
  source: MileageSource;
  note: string;
}

export interface MileageUpdate {
  km: number;
  mode: 'reading' | 'trip';
  note: string;
  correctionConfirmed: boolean;
}

/** Controle local das atualizações do rastreador. Nenhum token fica aqui: credenciais ficam só no servidor. */
export interface TrackerLocal {
  /** Identifica a conexão no servidor; muda quando o rastreador é reconectado. */
  linkedAt: string | null;
  /** Última atualização do servidor já somada à quilometragem. Evita somar duas vezes. */
  appliedSeq: number;
  /** Fração de quilômetro ainda não somada (o plano trabalha com km inteiros). */
  fraction: number;
}

export interface StoredState {
  version: 1;
  profile: Profile;
  records: MaintenanceRecord[];
  mileageReadings: MileageReading[];
  tracker: TrackerLocal;
  reminders: ReminderSettings;
  checklist: { date: string; checked: string[]; offroad: boolean };
}

export interface Reminder {
  id: string;
  title: string;
  description: string;
  date: string | null;
  km: number | null;
  due: boolean;
  unknown: boolean;
  kind: 'review' | 'oil' | 'brake' | 'chain' | 'tires';
}
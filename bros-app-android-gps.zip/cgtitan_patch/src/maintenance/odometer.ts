import type { MaintenanceRecord, MileageReading, MileageSource, Profile, Reminder, StoredState, TrackerLocal } from './types';

export const MAX_MILEAGE = 999999;
export const MAX_MILEAGE_READINGS = 250;

export const MILEAGE_SOURCES: Record<MileageSource, string> = {
  manual: 'Quilometragem informada',
  trip: 'Quilômetros de uma viagem somados',
  profile: 'Alteração no cadastro da moto',
  maintenance: 'Quilometragem anotada em um serviço',
  legacy: 'Quilometragem salva anteriormente',
  tracker: 'Atualizada pelo rastreador',
};

const formatted = (value: number) => new Intl.NumberFormat('pt-BR').format(value);
export const isMileage = (value: unknown): value is number => typeof value === 'number' && Number.isInteger(value) && value >= 0 && value <= MAX_MILEAGE;

export function parseMileage(value: string): number | null {
  const text = value.trim();
  // Accept Brazilian thousands separators, but never turn a negative or decimal into an integer.
  if (!/^(?:\d{1,6}|[1-9]\d{0,2}(?:\.\d{3})+)$/.test(text)) return null;
  const km = Number(text.replace(/\./g, ''));
  return isMileage(km) ? km : null;
}

export function highestServiceMileage(records: MaintenanceRecord[]): number {
  return records.reduce((highest, record) => Math.max(highest, record.km), 0);
}

export function mileageChangeError(state: Pick<StoredState, 'profile' | 'records'>, km: number | null, confirmed = false, note = ''): string | null {
  if (!isMileage(km)) return 'Informe de 0 a 999.999 km, sem casas decimais. Exemplo: 5.200.';
  const serviceKm = highestServiceMileage(state.records);
  if (km < serviceKm) return `Há um serviço registrado com ${formatted(serviceKm)} km. Confira esse registro antes de salvar uma quilometragem menor. Os serviços anteriores não serão alterados automaticamente.`;
  if (state.profile.configured && km < state.profile.km) {
    if (!confirmed) return 'O valor é menor que a quilometragem salva. Confirme que o número anterior foi digitado errado.';
    if (note.trim().length < 3) return 'Conte em poucas palavras por que está corrigindo a quilometragem.';
  }
  return null;
}

export function legacyMileageReading(km: number): MileageReading {
  return { id: `legacy-${km}`, km, previousKm: null, createdAt: null, source: 'legacy', note: 'Quilometragem salva antes da criação deste histórico. A data original não foi registrada.' };
}

export function normalizeMileageReadings(value: unknown): MileageReading[] {
  if (!Array.isArray(value)) return [];
  const seen = new Set<string>();
  const result: MileageReading[] = [];
  for (const candidate of value) {
    if (!candidate || typeof candidate !== 'object') continue;
    const item = candidate as Partial<MileageReading>;
    if (typeof item.id !== 'string' || !isMileage(item.km) || typeof item.source !== 'string' || !Object.prototype.hasOwnProperty.call(MILEAGE_SOURCES, item.source) || seen.has(item.id)) continue;
    seen.add(item.id);
    const validDate = typeof item.createdAt === 'string' && /^\d{4}-\d{2}-\d{2}T/.test(item.createdAt) && Number.isFinite(Date.parse(item.createdAt));
    result.push({ id: item.id, km: item.km, previousKm: isMileage(item.previousKm) ? item.previousKm : null, createdAt: validDate ? item.createdAt! : null, source: item.source, note: typeof item.note === 'string' ? item.note.slice(0, 500) : '' });
  }
  return result.slice(-MAX_MILEAGE_READINGS);
}

export function withMileageReading(state: StoredState, km: number, source: Exclude<MileageSource, 'legacy'>, note = '', correctionConfirmed = false): StoredState {
  const error = mileageChangeError(state, km, correctionConfirmed, note);
  if (error) throw new Error(error);
  const readings = [...state.mileageReadings];
  if (state.profile.configured && readings[readings.length - 1]?.km !== state.profile.km) readings.push(legacyMileageReading(state.profile.km));
  const reading: MileageReading = {
    id: globalThis.crypto?.randomUUID?.() || `km-${Date.now()}-${Math.random().toString(36).slice(2)}`,
    km,
    previousKm: state.profile.configured ? state.profile.km : null,
    createdAt: new Date().toISOString(),
    source,
    note: note.trim().slice(0, 500),
  };
  return { ...state, profile: { ...state.profile, km, configured: true }, mileageReadings: [...readings, reading].slice(-MAX_MILEAGE_READINGS) };
}

export function latestMileageReading(state: StoredState): MileageReading | null {
  return state.mileageReadings[state.mileageReadings.length - 1] || null;
}

export function mileageTimestamp(iso: string | null): string {
  if (!iso) return 'Data original não informada';
  const date = new Date(iso);
  if (!Number.isFinite(date.getTime())) return 'Data original não informada';
  return date.toLocaleString('pt-BR', { day: '2-digit', month: '2-digit', year: 'numeric', hour: '2-digit', minute: '2-digit' });
}

export function mileageDistance(profile: Profile, reminder: Reminder): { label: string; detail: string; tone: 'neutral' | 'warning'; remaining: number | null } {
  if (!profile.configured) return { label: 'Informe sua quilometragem', detail: 'O cálculo usa apenas os quilômetros que você informar.', tone: 'neutral', remaining: null };
  if (reminder.km === null) return { label: 'Prazo por data', detail: 'Acompanhe a data, mesmo que a moto rode pouco.', tone: reminder.due ? 'warning' : 'neutral', remaining: null };
  if (reminder.unknown && (reminder.kind === 'chain' || reminder.kind === 'tires')) return { label: 'Último cuidado não informado', detail: 'Anote quando esse cuidado foi feito para calcular quanto falta para o próximo. Não vamos supor que ele aconteceu em 0 km.', tone: 'neutral', remaining: null };
  const delta = reminder.km - profile.km;
  if (delta < 0) return { label: `${formatted(-delta)} km além do previsto`, detail: 'Confira os serviços anteriores antes de repetir um cuidado. Passar dessa quilometragem não significa que a revisão foi feita.', tone: 'warning', remaining: 0 };
  if (delta === 0) return { label: 'Chegou à quilometragem prevista', detail: 'Confira o cuidado indicado e o que já foi registrado.', tone: 'warning', remaining: 0 };
  if (reminder.due) return { label: 'A data chegou primeiro', detail: `Ainda faltam ${formatted(delta)} km para a etapa, mas o prazo por data já chegou. Confira os serviços anteriores.`, tone: 'warning', remaining: delta };
  return { label: `Faltam ${formatted(delta)} km`, detail: 'A data, o desgaste ou um defeito podem exigir cuidado antes disso.', tone: 'neutral', remaining: delta };
}

export function mileageCsv(readings: MileageReading[]): string {
  const safe = (value: string | number) => {
    const text = typeof value === 'string' ? value.replace(/^(\s*[=+@-])/, "'$1") : String(value);
    return `"${text.replace(/"/g, '""')}"`;
  };
  const rows = [
    ['Data e hora do registro', 'Quilometragem (km)', 'Quilometragem anterior (km)', 'Diferenca entre registros (km)', 'Como foi informado', 'Valor corrigido', 'Observacao'],
    ...readings.map(item => [item.createdAt || '', item.km, item.previousKm ?? '', item.previousKm === null ? '' : item.km - item.previousKm, MILEAGE_SOURCES[item.source], item.previousKm !== null && item.km < item.previousKm ? 'Sim' : 'Nao', item.note]),
  ];
  return '\uFEFF' + rows.map(row => row.map(safe).join(',')).join('\r\n');
}
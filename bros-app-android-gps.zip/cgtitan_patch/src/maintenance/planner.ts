import { CONDITIONS, DAILY_CHECKLIST, OFFROAD_CHECKLIST, SAFETY_ALERTS, SEVERE_USE, SOURCE_LIMIT, sourceScopeForYear, ACTIONS, getServiceForModel, getModelServices } from './data';
import { isMileage, legacyMileageReading, MAX_MILEAGE_READINGS, normalizeMileageReadings } from './odometer';
import { LANGUAGE_NOTE, MANUAL_TERMS } from './language';
import { colorLabel, normalizeBikeColor, defaultVariantForYear, getVariantOptions, variantLabel } from './models';
import { defaultReminderSettings, normalizeReminderSettings } from '../reminders/preferences';
import { defaultTracker, normalizeTracker } from '../tracker/apply';
import type { BikeColor, MaintenanceRecord, Milestone, ModelYear, Profile, Reference, Reminder, StoredState, Variant } from './types';

export const STORAGE_KEY = 'bros-maintenance-planner-v1';
export const formatKm = (km: number) => new Intl.NumberFormat('pt-BR').format(km);
export const todayISO = () => {
  const date = new Date();
  return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}-${String(date.getDate()).padStart(2, '0')}`;
};
export const manualUrl = (year: ModelYear, reference?: Reference) => {
  // O visualizador do ManualPDF usa o próprio número de página no parâmetro ?p=.
  // Antes, o projeto aplicava um deslocamento de +18, fazendo p. 46 abrir p. 64.
  const base = year === 'FAN-2013' ? 'https://www.honda.com.br/pos-venda/motos/sites/customer_service_motos/files/manuais/CG%20150%20Fan%202013.pdf' : year === 'FAN-2014' ? 'https://www.honda.com.br/pos-venda/motos/sites/customer_service_motos/files/manuais/CG%20150%20Fan%202014.pdf' : year === 'FAN-2015' ? 'https://www.honda.com.br/sites/cbw/files/2016-09/MP%20CG%20160%20FAN-TITAN%20%282016%29%20D2203-MAN-1025%20Completo.pdf' : year === 'FAN-2016' ? 'https://www.honda.com.br/pos-venda/motos/sites/customer_service_motos/files/manuais/MP%20CG%20160%20FAN-TITAN%20%282016%29%20D2203-MAN-1025%20Completo.pdf' : year === 'FAN-2017' ? 'https://www.honda.com.br/pos-venda/motos/sites/customer_service_motos/files/manuais/MP%20CG160%20FAN-TITAN%20%282017%29%20D2203-MAN-1082%20Completo.pdf' : year === 'FAN-2018' ? 'https://www.honda.com.br/pos-venda/sites/customer_service_motos/files/manuais/MP%20CG%20160%20FAN-CG%20160%20TITAN%20%282018%29%20D2203-MAN-1141_WEB.pdf' : year === 'FAN-2019' ? 'https://www.honda.com.br/pos-venda/motos/sites/customer_service_motos/files/manuais/MP%20CG%20160%20FAN-CG%20160%20TITAN%20%282019~2020%29%20D2203-MAN-1185_WEB_1.pdf' : year === '2020' ? 'https://www.honda.com.br/pos-venda/motos/sites/customer_service_motos/files/manuais/MP%20CG%20160%20FAN-CG%20160%20TITAN%20%282019~2020%29%20D2203-MAN-1185_WEB_1.pdf' : year === '2021' ? 'https://www.honda.com.br/pos-venda/motos/sites/customer_service_motos/files/manuais/MP%20CG%20160%20FAN_TITAN%20%282021%29%20D2203-MAN-1255_WEB.pdf' : year === '2022' ? 'https://www.honda.com.br/pos-venda/motos/sites/customer_service_motos/files/manuais/MP%20CG%20160%20FAN-TITAN%20%282022%29%20D2203-MAN-1260_WEB_0.pdf' : year === '2023' || year === '2024' ? 'https://www.honda.com.br/pos-venda/motos/sites/customer_service_motos/files/manuais/MP%20CG%20160%20FAN-TITAN%20%282023~2024%29%20D2203-MAN-1303_WEB.pdf' : year === '2025'
    ? 'https://saladeimprensa.honda.com.br/releases/honda-cg-160-2025-nova-geracao-da-motocicleta-preferida-dos-brasileiros-traz-importantes'
    : year === '2026'
    ? 'https://www.honda.com.br/motos/street/city/cg-160-fan'
    : year === 'START-2015'
    ? 'https://www.honda.com.br/pos-venda/sites/customer_service_motos/files/manuais/CG%20150%20Start%202015.pdf'
    : year === 'START-2026' || year === 'START-2022'
    ? 'https://www.honda.com.br/pos-venda/motos/sites/customer_service_motos/files/manuais/MP%20CG%20160%20START%20%282022%29%20D2203-MAN-1261_WEB_0.pdf'
    : year === 'CARGO-2013' || year === 'CARGO-2014'
    ? 'https://www.honda.com.br/pos-venda/motos/sites/customer_service_motos/files/manuais/CG%20150%20Cargo%202014.pdf'
    : year === 'CARGO-2015'
    ? 'https://www.honda.com.br/pos-venda/sites/customer_service_motos/files/manuais/CG%20150%20Cargo%202015.pdf'
    : year === 'CARGO-2016' || year === 'CARGO-2017'
    ? 'https://www.honda.com.br/pos-venda/motos/sites/customer_service_motos/files/manuais/MP%20CG%20160%20Cargo%20ESDi%20%282016%29%20D2203-MAN-1026%20Completo.pdf'
    : year === 'CARGO-2018'
    ? 'https://www.honda.com.br/pos-venda/sites/customer_service_motos/files/manuais/MP%20CG%20160%20CARGO%20(2018)%20D2203-MAN-1129_WEB.pdf'
    : year === 'CARGO-2019' || year === 'CARGO-2020'
    ? 'https://www.honda.com.br/pos-venda/sites/customer_service_motos/files/manuais/MP%20CG%20160%20CARGO%20(2019)%20D2203-MAN-1187_WEB.pdf'
    : year === 'CARGO-2021' || year === 'CARGO-2022'
    ? 'https://www.honda.com.br/pos-venda/sites/customer_service_motos/files/manuais/MP%20CG%20160%20CARGO%20%282019~2020%29%20D2203-MAN-1187_WEB_0.pdf'
    : year === 'CARGO-2026' || year === 'CARGO-2025' || year === 'CARGO-2023' || year === 'CARGO-2024'
    ? 'https://www.honda.com.br/pos-venda/motos/sites/customer_service_motos/files/manuais/MP%20CG%20160%20CARGO%20%282023~2024%29%20D2203-MAN-1305_WEB.pdf'
    : year === 'TITAN-2026'
    ? 'https://www.honda.com.br/motos/street/city/cg-160-titan'
    : year === '2013'
    ? 'https://www.honda.com.br/pos-venda/motos/sites/customer_service_motos/files/manuais/NXR%20150%20Bros%202013.pdf'
    : year === '2014'
    ? 'https://www.manualpdf.com.br/honda/nxr-150-bros-2014/manual'
    : year === '2015'
    ? 'https://www.manualpdf.com.br/honda/nxr160-bros-2015/manual'
    : year === '2015/2016'
    ? 'https://www.manualpdf.com.br/honda/nxr160-bros-2016/manual'
    : year === '2016'
    ? 'https://www.manualpdf.com.br/honda/nxr160-bros-2016/manual'
    : year === '2016/2017'
    ? 'https://www.manualpdf.com.br/honda/nxr160-bros-2016/manual'
    : year === '2017' || year === '2017/2018'
    ? 'https://www.manualpdf.com.br/honda/nxr160-bros-2017/manual'
    : year === '2018' || year === '2018/2019'
    ? 'https://www.manualpdf.com.br/honda/nxr160-bros-2018/manual'
    : year === '2019' || year === '2019/2020'
    ? 'https://www.manualpdf.com.br/honda/nxr160-bros-2019/manual'
    : year === 'NXR-2020' || year === '2020/2021'
      ? 'https://www.manualpdf.com.br/honda/nxr160-bros-2020/manual'
      : year === 'NXR-2021' || year === '2021/2022'
        ? 'https://www.manualpdf.com.br/honda/nxr160-bros-2021/manual'
        : year === 'NXR-2022' || year === 'NXR-2023' || year === 'NXR-2024' || year === '2022/2023' || year === '2023/2024' || year === '2024/2025'
          ? 'https://www.manualpdf.com.br/honda/nxr160-bros-2023/manual'
          : year === 'NXR-2025' || year === 'NXR-2026'
            ? 'https://www.manualpdf.com.br/honda/nxr-160-bros-2025/manual'
            : `https://www.manualpdf.com.br/honda/nxr-160-bros-${year === '2025/2026' ? '2026' : year}/manual`;
  if (!reference) return base;
  const page = reference.page === 'Certificado' ? reference.viewer : Number(reference.page);
  return Number.isInteger(page) && page > 0 ? `${base}?p=${page}` : base;
};
export const displayDate = (date: string | null) => date ? new Date(`${date}T12:00:00`).toLocaleDateString('pt-BR') : 'Data não informada';

export function isValidDate(value: unknown): value is string {
  if (typeof value !== 'string' || !/^\d{4}-\d{2}-\d{2}$/.test(value)) return false;
  const d = new Date(`${value}T12:00:00`);
  return Number.isFinite(d.getTime()) && `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}` === value;
}

export function addMonths(iso: string, months: number): string | null {
  if (!isValidDate(iso)) return null;
  const date = new Date(`${iso}T12:00:00`);
  const day = date.getDate();
  date.setDate(1);
  date.setMonth(date.getMonth() + months);
  const lastDay = new Date(date.getFullYear(), date.getMonth() + 1, 0).getDate();
  date.setDate(Math.min(day, lastDay));
  return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}-${String(date.getDate()).padStart(2, '0')}`;
}

export function defaultState(): StoredState {
  return {
    version: 1,
    profile: { family: 'NXR', year: 'NXR-2026', variant: 'ABS', color: 'vermelha', km: 0, purchaseDate: '', oilDate: '', brakeDate: '', usage: [], configured: false },
    records: [],
    mileageReadings: [],
    tracker: defaultTracker(),
    reminders: defaultReminderSettings(),
    checklist: { date: todayISO(), checked: [], offroad: false },
  };
}

export function loadState(): StoredState {
  const defaults = defaultState();
  try {
    const raw = JSON.parse(localStorage.getItem(STORAGE_KEY) || 'null');
    if (!raw || raw.version !== 1) return defaults;
    const p = raw.profile || {};
    const rawFamily = p.family === 'TITAN' ? 'TITAN' : p.family === 'CARGO' ? 'CARGO' : p.family === 'START' ? 'START' : p.family === 'FAN' ? 'FAN' : 'NXR';
    let modelYear: ModelYear = ['2013', '2014', '2015', '2015/2016', '2016', '2016/2017', '2017', '2017/2018', '2018', '2018/2019', '2019', '2019/2020', 'FAN-2013', 'FAN-2014', 'FAN-2015', 'FAN-2016', 'FAN-2017', 'FAN-2018', 'FAN-2019', 'NXR-2020', 'NXR-2021', 'NXR-2022', 'NXR-2023', 'NXR-2024', 'NXR-2025', 'NXR-2026', '2020/2021', '2021/2022', '2022/2023', '2023/2024', '2024', '2024/2025', '2025', '2025/2026', '2026', 'START-2026', 'START-2022', 'START-2015', 'CARGO-2013', 'CARGO-2014', 'CARGO-2015', 'CARGO-2016', 'CARGO-2017', 'CARGO-2018', 'CARGO-2019', 'CARGO-2020', 'CARGO-2021', 'CARGO-2022', 'CARGO-2023', 'CARGO-2024', 'CARGO-2025', 'CARGO-2026', 'TITAN-2026'].includes(p.year as string) ? p.year as ModelYear : '2026';
    // Migrate old grouped NXR selections to the first concrete model year. The grouped
    // values remain valid only as historical/manual-reference internals and are never
    // exposed as selectable model years in the UI.
    const legacyNxrYearMap: Partial<Record<ModelYear, ModelYear>> = {
      '2015/2016': '2015', '2016/2017': '2016', '2017/2018': '2017',
      '2018/2019': '2018', '2019/2020': '2019', '2020/2021': 'NXR-2020',
      '2021/2022': 'NXR-2021', '2022/2023': 'NXR-2022', '2023/2024': 'NXR-2023',
      '2024/2025': 'NXR-2024', '2025/2026': 'NXR-2025',
    };
    if (rawFamily === 'NXR') {
      if (legacyNxrYearMap[modelYear]) modelYear = legacyNxrYearMap[modelYear]!;
      else if (['2021','2022','2023','2024','2025','2026'].includes(modelYear)) modelYear = `NXR-${modelYear}` as ModelYear;
    }
    if (rawFamily === 'FAN' && !['FAN-2013', 'FAN-2014', 'FAN-2015', 'FAN-2016', 'FAN-2017', 'FAN-2018', 'FAN-2019', '2020', '2021', '2022', '2023', '2024', '2025', '2026'].includes(modelYear)) modelYear = '2026';
    if (rawFamily === 'FAN' && String(modelYear).startsWith('NXR-')) modelYear = '2026';
    if (rawFamily === 'START' && modelYear !== 'START-2026' && modelYear !== 'START-2022' && modelYear !== 'START-2015') modelYear = 'START-2026';
    if (rawFamily === 'CARGO' && modelYear !== 'CARGO-2013' && modelYear !== 'CARGO-2014' && modelYear !== 'CARGO-2015' && modelYear !== 'CARGO-2016' && modelYear !== 'CARGO-2017' && modelYear !== 'CARGO-2018' && modelYear !== 'CARGO-2019' && modelYear !== 'CARGO-2020' && modelYear !== 'CARGO-2021' && modelYear !== 'CARGO-2022' && modelYear !== 'CARGO-2023' && modelYear !== 'CARGO-2024' && modelYear !== 'CARGO-2025' && modelYear !== 'CARGO-2026') modelYear = 'CARGO-2026';
    if (rawFamily === 'TITAN' && modelYear !== 'TITAN-2026') modelYear = 'TITAN-2026';
    const knownKm = isMileage(p.km) ? p.km : 0;
    const configured = Boolean(p.configured) && isMileage(p.km);
    const mileageReadings = normalizeMileageReadings(raw.mileageReadings);
    // Preserve existing v1 profiles without inventing a date for their previous reading.
    if (configured && mileageReadings[mileageReadings.length - 1]?.km !== knownKm) mileageReadings.push(legacyMileageReading(knownKm));
    const storedVariant = typeof p.variant === 'string' ? p.variant as Variant : undefined;
    const yearVariants = getVariantOptions(modelYear);
    const selectedVariant: Variant = storedVariant && yearVariants.includes(storedVariant) ? storedVariant : defaultVariantForYear(modelYear);
    const records: MaintenanceRecord[] = Array.isArray(raw.records) ? raw.records.filter((record: MaintenanceRecord) => record && typeof record.id === 'string' && isValidDate(record.date) && record.date <= todayISO() && Number.isFinite(record.km) && record.km >= 0 && ['review', 'routine', 'condition'].includes(record.type)).map((record: MaintenanceRecord) => ({ ...record, km: Math.min(999999, record.km), milestone: record.milestone === null || Number.isFinite(record.milestone) && record.milestone >= 0 ? record.milestone : null, serviceIds: Array.isArray(record.serviceIds) ? record.serviceIds.filter(id => getModelServices(modelYear, selectedVariant).some(item => item.id === id)) : [], notes: typeof record.notes === 'string' ? record.notes.slice(0, 2000) : '', document: typeof record.document === 'string' ? record.document.slice(0, 100) : '' })) : [];
    const validCheckIds = [...DAILY_CHECKLIST, ...OFFROAD_CHECKLIST].map(item => item.id);
    return {
      version: 1,
      profile: {
        family: rawFamily,
        year: modelYear, variant: selectedVariant,
        color: normalizeBikeColor(modelYear, selectedVariant, (p.color as BikeColor | undefined) || 'vermelha'),
        km: knownKm,
        purchaseDate: isValidDate(p.purchaseDate) && p.purchaseDate <= todayISO() ? p.purchaseDate : '', oilDate: isValidDate(p.oilDate) && p.oilDate <= todayISO() ? p.oilDate : '', brakeDate: isValidDate(p.brakeDate) && p.brakeDate <= todayISO() ? p.brakeDate : '',
        usage: Array.isArray(p.usage) ? p.usage.filter((item: string) => SEVERE_USE.some(option => option.id === item)) : [], configured,
      },
      records,
      mileageReadings: mileageReadings.slice(-MAX_MILEAGE_READINGS),
      tracker: normalizeTracker(raw.tracker),
      reminders: normalizeReminderSettings(raw.reminders),
      checklist: raw.checklist?.date === todayISO() ? { date: todayISO(), checked: Array.isArray(raw.checklist.checked) ? raw.checklist.checked.filter((id: string) => validCheckIds.includes(id)) : [], offroad: Boolean(raw.checklist.offroad) } : defaults.checklist,
    };
  } catch { return defaults; }
}

// Modelos cuja tabela de revisões é 1.000 km, 4.000 km e depois a cada 4.000 km (6, 12, 18... meses).
export const usesCycle4000 = (year: ModelYear): boolean => ['2013', '2014', '2015', 'FAN-2013', 'FAN-2014', 'CARGO-2013', 'CARGO-2014', 'CARGO-2015', 'START-2015'].includes(year);

export function reviewMonths(km: number, year: ModelYear = 'NXR-2026'): number | null {
  if (km === 1000) return 6;
  if (usesCycle4000(year)) return km >= 4000 && km % 4000 === 0 ? 12 + ((km - 4000) / 4000) * 6 : null;
  return km >= 6000 && km % 6000 === 0 ? km / 1000 + 6 : null;
}

export function modelIsLegacy(year: ModelYear): boolean {
  return year !== '2023' && year !== '2024' && year !== '2025' && year !== '2025/2026' && year !== '2026' && year !== 'NXR-2025' && year !== 'NXR-2026' && year !== 'START-2026' && year !== 'CARGO-2016' && year !== 'CARGO-2017' && year !== 'CARGO-2018' && year !== 'CARGO-2019' && year !== 'CARGO-2020' && year !== 'CARGO-2021' && year !== 'CARGO-2022' && year !== 'CARGO-2023' && year !== 'CARGO-2024' && year !== 'CARGO-2025' && year !== 'CARGO-2026' && year !== 'TITAN-2026';
}

export function modelLabel(year: ModelYear): string {
  return year === 'FAN-2013' ? 'CG 150 Fan 2013' : year === 'FAN-2014' ? 'CG 150 Fan 2014' : year === 'FAN-2015' ? 'CG 160 Fan 2015' : year === 'FAN-2016' ? 'CG 160 Fan 2016' : year === 'FAN-2017' ? 'CG 160 Fan 2017' : year === 'FAN-2018' ? 'CG 160 Fan 2018' : year === 'FAN-2019' ? 'CG 160 Fan 2019' : year === '2020' ? 'CG 160 Fan 2020' : year === '2013' ? 'NXR 150 Bros 2013' : year === '2014' ? 'NXR 150 Bros 2014' : year === '2015' ? 'NXR 160 Bros 2015' : year === '2015/2016' ? 'NXR 160 Bros 2015/2016' : year === '2016' ? 'NXR 160 Bros 2016' : year === '2016/2017' ? 'NXR 160 Bros 2016/2017' : year === '2017' ? 'NXR 160 Bros 2017' : year === '2017/2018' ? 'NXR 160 Bros 2017/2018' : year === '2018' ? 'NXR 160 Bros 2018' : year === '2018/2019' ? 'NXR 160 Bros 2018/2019' : year === '2019' ? 'NXR 160 Bros 2019' : year === '2019/2020' ? 'NXR 160 Bros 2019/2020' : year === 'NXR-2020' ? 'NXR 160 Bros 2020' : year === 'NXR-2021' ? 'NXR 160 Bros 2021' : year === 'NXR-2022' ? 'NXR 160 Bros 2022' : year === 'NXR-2023' ? 'NXR 160 Bros 2023' : year === 'NXR-2024' ? 'NXR 160 Bros 2024' : year === 'NXR-2025' ? 'NXR 160 Bros 2025' : year === 'NXR-2026' ? 'NXR 160 Bros 2026' : year === '2020/2021' ? 'NXR 160 Bros 2020/2021' : year === '2021/2022' ? 'NXR 160 Bros 2021/2022' : year === '2022/2023' ? 'NXR 160 Bros 2022/2023' : year === '2023/2024' ? 'NXR 160 Bros 2023/2024' : year === '2024/2025' ? 'NXR 160 Bros 2024/2025' : year === '2021' ? 'CG 160 Fan 2021' : year === '2022' ? 'CG 160 Fan 2022' : year === '2023' ? 'CG 160 Fan 2023' : year === '2024' ? 'CG 160 Fan 2024' : year === '2025' ? 'CG 160 Fan 2025' : year === '2026' ? 'CG 160 Fan 2026' : year === 'START-2015' ? 'CG 150 Start 2015' : year === 'START-2022' ? 'CG 160 Start 2022' : year === 'START-2026' ? 'CG 160 Start 2026' : year === 'CARGO-2013' ? 'CG 150 Cargo 2013' : year === 'CARGO-2014' ? 'CG 150 Cargo 2014' : year === 'CARGO-2015' ? 'CG 150 Cargo 2015' : year === 'CARGO-2016' ? 'CG 160 Cargo 2016' : year === 'CARGO-2017' ? 'CG 160 Cargo 2017' : year === 'CARGO-2018' ? 'CG 160 Cargo 2018' : year === 'CARGO-2019' ? 'CG 160 Cargo 2019' : year === 'CARGO-2020' ? 'CG 160 Cargo 2020' : year === 'CARGO-2021' ? 'CG 160 Cargo 2021' : year === 'CARGO-2022' ? 'CG 160 Cargo 2022' : year === 'CARGO-2023' ? 'CG 160 Cargo 2023' : year === 'CARGO-2024' ? 'CG 160 Cargo 2024' : year === 'CARGO-2025' ? 'CG 160 Cargo 2025' : year === 'CARGO-2026' ? 'CG 160 Cargo 2026' : year === 'TITAN-2026' ? 'CG 160 Titan 2026' : 'NXR 160 Bros 2025/2026';
}

// Fonte única do intervalo da corrente: o catálogo do modelo. A linha do tempo, os lembretes e o plano usam o mesmo valor.
export const chainStepKm = (year: ModelYear): number => {
  try { return getServiceForModel('chain', year).kmInterval === 500 ? 500 : 1000; } catch { return 1000; }
};

// Serviços marcados na coluna de 1.000 km das tabelas da Cargo 150 (manual 2014 e manual 2015), conferidos na imagem.
const cargo150Km1000Ids = (year: ModelYear): string[] => year === 'CARGO-2015'
  ? ['first-review', 'chain', 'tires', 'oil', 'valves', 'idle', 'brakes', 'clutch', 'suspension', 'fasteners', 'wheels', 'steering']
  : ['first-review', 'chain', 'tires', 'oil', 'valves', 'idle', 'brakes', 'clutch', 'fasteners', 'wheels', 'steering'];

// Start 2022: 12.000 km = vela e filtros de óleo; 18.000 km = filtro de ar; 24.000 km = fluido da suspensão dianteira (tabela do manual).
const start2022Title = (km: number): string => {
  const parts = [km % 12000 === 0 ? 'vela e filtros de óleo' : '', km % 18000 === 0 ? 'filtro de ar' : '', km % 24000 === 0 ? 'fluido da suspensão' : ''].filter(Boolean);
  return parts.length ? `Revisão com ${parts.join(', ').replace(/, ([^,]*)$/, ' e $1')}` : 'Revisão do calendário';
};

export function milestoneAt(km: number, year: ModelYear = 'NXR-2026', variant: Variant = 'ESDD'): Milestone {
  const legacy = modelIsLegacy(year);
  const service = (id: string) => getServiceForModel(id, year, variant);
  if (km === 0) return { km, months: null, kind: 'delivery', title: 'Tudo começa com uma boa entrega', subtitle: legacy ? 'Documentos, verificações antes de sair e primeiros cuidados.' : 'Documentos, verificações antes de sair e primeiros cuidados.', services: [service('delivery'), service('break-in')] };
  const months = reviewMonths(km, year);
  if (km === 1000) return { km, months, kind: 'review', title: 'Primeira revisão', subtitle: year === '2013' ? '900–1.100 km. A segunda fica em 3.600–4.400 km.' : '1.000 km ou 6 meses. O que ocorrer primeiro.', services: (/^CARGO-201[345]$/.test(year) ? cargo150Km1000Ids(year) : ['first-review', 'chain', 'tires', 'oil-level']).map(service), notice: year === '2013' ? 'O manual 2013 determina a primeira revisão entre 900 e 1.100 km a partir da compra e a segunda entre 3.600 e 4.400 km. As rotinas da corrente e dos pneus têm intervalos próprios.' : /^CARGO-201[345]$/.test(year) ? 'A primeira revisão da Cargo 150 é em 1.000 km ou 6 meses e a segunda em 4.000 km ou 12 meses, o que ocorrer primeiro. Esta etapa segue a coluna de 1.000 km da tabela do manual, conferida na imagem; a corrente e os pneus têm rotinas próprias a cada 1.000 km.' + (year === 'CARGO-2013' ? ' Para a Cargo 2013 vale a tabela do manual da Cargo 2014, porque não há manual próprio.' : '') : year === 'START-2022' ? 'A primeira revisão da CG 160 Start (2022) é em 1.000 km ou 6 meses e a segunda em 6.000 km ou 12 meses, o que ocorrer primeiro; o certificado admite tolerância de 900 a 1.100 km e de 5.400 a 6.600 km. As marcações por coluna da tabela (quais serviços caem em 1.000, 6.000, 12.000 km...) não aparecem no texto do PDF e não foram conferidas na imagem: confira no manual da sua moto o que entra nessa revisão. A corrente (a cada 1.000 km) e os pneus (a cada 1.000 km ou semanalmente) têm rotinas próprias.' : year === 'START-2015' ? 'A primeira revisão da CG 150 Start é em 1.000 km ou 6 meses e a segunda em 4.000 km ou 12 meses, o que ocorrer primeiro. As rotinas da corrente e dos pneus têm intervalos próprios. As marcações da coluna de 1.000 km da tabela não foram conferidas na imagem do manual: confira no manual da sua moto para qualquer troca específica.' : /^CARGO-20(16|17|18|19|20)$/.test(year) ? 'O manual da Cargo foi lido por completo: a primeira revisão é em 1.000 km ou 6 meses, o que ocorrer primeiro. As rotinas da corrente e dos pneus têm intervalos próprios; a lista de serviços desta etapa segue a tabela do manual.' : legacy ? 'O manual confirma a revisão inicial no certificado; as rotinas da corrente e dos pneus têm intervalos próprios. Confira no manual a coluna de 1.000 km para qualquer marcação específica de troca.' : 'Ainda precisamos conferir as marcações da coluna de 1.000 km no manual original, inclusive a troca do óleo. Já os cuidados abaixo com corrente, pneus e nível do óleo têm seus próprios intervalos confirmados.' };
  const periodic = (usesCycle4000(year) ? km >= 4000 : km >= 6000) ? getModelServices(year, variant).filter(item => item.group === 'scheduled' && item.id !== 'first-review' && item.kmInterval && km % item.kmInterval === 0 && !item.pending) : [];
  const priorities = legacy ? ['oil', 'spark', 'oil-screen', 'centrifugal', 'valves', 'air', 'fork-oil', 'rear-suspension-lube'] : ['oil', 'spark', 'oil-screen', 'centrifugal', 'valves', 'air', 'electrical'];
  periodic.sort((a, b) => {
    const ai = priorities.indexOf(a.id), bi = priorities.indexOf(b.id);
    return (ai < 0 ? 99 : ai) - (bi < 0 ? 99 : bi);
  });
  const chainDue = km % chainStepKm(year) === 0;
  const routine = [ ...(chainDue ? [service('chain')] : []), ...(km % 1000 === 0 ? [service('tires')] : []) ];
  const services = [...periodic, ...routine];
  return {
    km, months,
    kind: months ? 'review' : 'routine',
    title: months ? year === 'START-2022' ? start2022Title(km) : /^(CARGO-201[345]|START-2015)$/.test(year) ? (km % 16000 === 0 ? (year === 'CARGO-2015' || year === 'START-2015' ? 'Revisão com filtro de ar e fluido da suspensão' : 'Revisão com filtro de ar') : km % 12000 === 0 ? 'Revisão com limpeza dos filtros de óleo' : 'Revisão do calendário') : km % 18000 === 0 ? (legacy ? 'Revisão com filtro de ar e suspensão' : 'Revisão com filtro de ar') : km % 12000 === 0 ? 'Revisão com limpeza dos filtros de óleo' : 'Revisão do calendário' : km === 500 && !legacy ? 'O primeiro cuidado com a corrente' : chainDue ? 'Corrente e pneus em dia' : 'Cuidado entre revisões',
    subtitle: months ? `${formatKm(km)} km ou ${months} meses da entrega, o que ocorrer primeiro.` : chainDue ? (year === '2021' || year === 'FAN-2014' || year === 'FAN-2015' || year === 'FAN-2016' || year === 'FAN-2017' || year === 'FAN-2018' || year === 'FAN-2019' || year === 'CARGO-2016' || year === 'CARGO-2017' || year === 'CARGO-2018' || year === 'CARGO-2019' || year === 'CARGO-2020' || year === 'CARGO-2021' || year === 'CARGO-2022' || legacy ? 'Cuidados de rotina. Para este modelo, a corrente tem intervalo de 1.000 km.' : 'Cuidados de rotina. A corrente também precisa de cuidado a cada 500 km.') : 'Verificar, ajustar se necessário, limpar e passar o lubrificante indicado na corrente.',
    services,
    notice: months ? (year === '2015' ? 'Tabela histórica 2015: revisões a cada 1.000 km na primeira etapa e depois a cada 4.000 km; corrente e pneus têm intervalos próprios. Fluido de freio: 2 anos.' : year === 'START-2022' ? 'Serviços organizados pelos intervalos escritos na tabela do manual da CG 160 Start (2022): 6.000, 12.000, 18.000 e 24.000 km. A CG 160 Start tem freios a tambor, sem fluido de freio.' : year === 'START-2015' ? 'Serviços organizados pelos intervalos escritos na tabela do manual da CG 150 Start (4.000, 8.000, 12.000 e 16.000 km).' : /^CARGO-201[345]$/.test(year) ? 'Serviços organizados pelos intervalos escritos na tabela do manual da Cargo 150 (4.000, 8.000, 12.000 e 16.000 km). O líquido de freio tem prazo próprio de 2 anos, independentemente desta etapa.' : /^CARGO-20(16|17|18|19|20)$/.test(year) ? 'Serviços organizados pelos intervalos escritos na tabela do manual da Cargo. O líquido de freio tem prazo próprio de 2 anos, independentemente desta etapa.' : legacy ? 'Intervalos da tabela pré-2025: corrente a cada 1.000 km; direção a cada 6.000 km; óleo das bengalas e lubrificação da suspensão traseira previstos a cada 18.000 km.' : 'Serviços organizados pelos intervalos escritos na tabela. Ainda falta conferir em qual revisão começa a verificação da vela. O líquido de freio tem prazo próprio de 2 anos, independentemente desta etapa.') : km === 500 && !legacy ? 'Você completou os primeiros 500 km de amaciamento do motor. Isso não cria uma troca obrigatória de óleo, pneus ou peças nesta etapa.' : undefined,
  };
}

export function milestones(upTo = 36000, halfSteps = false, year: ModelYear = 'NXR-2026', variant: Variant = 'ESDD'): Milestone[] {
  const legacy = modelIsLegacy(year);
  const values = new Set<number>([0, 1000]);
  const step = halfSteps && !legacy && year !== 'FAN-2014' && year !== 'FAN-2015' && year !== 'FAN-2016' && year !== 'FAN-2017' && year !== 'FAN-2018' && year !== 'FAN-2019' && year !== 'CARGO-2016' && year !== 'CARGO-2017' && year !== 'CARGO-2018' && year !== 'CARGO-2019' && year !== 'CARGO-2020' && year !== 'CARGO-2021' && year !== 'CARGO-2022' ? 500 : 1000;
  if (!legacy && year !== 'FAN-2014' && year !== 'FAN-2015' && year !== 'FAN-2016' && year !== 'FAN-2017' && year !== 'FAN-2018' && year !== 'FAN-2019' && year !== 'CARGO-2016' && year !== 'CARGO-2017' && year !== 'CARGO-2018' && year !== 'CARGO-2019' && year !== 'CARGO-2020' && year !== 'CARGO-2021' && year !== 'CARGO-2022') values.add(500);
  for (let km = step; km <= upTo; km += step) values.add(km);
  return [...values].sort((a, b) => a - b).map(km => milestoneAt(km, year, variant));
}

export function lastServiceDate(state: StoredState, serviceId: string): string | null {
  const explicit = serviceId === 'oil' ? state.profile.oilDate : serviceId === 'brake-fluid' ? state.profile.brakeDate : '';
  const dates = state.records.filter(record => record.serviceIds.includes(serviceId)).map(record => record.date);
  if (explicit) dates.push(explicit);
  return dates.sort().slice(-1)[0] || null;
}

export function isRecorded(state: StoredState, milestone: Milestone): boolean {
  return state.records.some(record => record.milestone === milestone.km && (milestone.kind !== 'review' || record.type === 'review'));
}

export function reminderList(state: StoredState): Reminder[] {
  const { profile, records } = state;
  const now = todayISO();
  const scheduledKms = usesCycle4000(profile.year) ? [1000, ...Array.from({ length: 250 }, (_, i) => (i + 1) * 4000)] : [1000, ...Array.from({ length: 167 }, (_, i) => (i + 1) * 6000)];
  const next = scheduledKms.find(km => !records.some(record => record.type === 'review' && record.milestone === km)) || 1008000;
  const months = reviewMonths(next, profile.year)!;
  const reviewDate = profile.purchaseDate ? addMonths(profile.purchaseDate, months) : null;
  const results: Reminder[] = [{ id: 'review', title: `Revisão de ${formatKm(next)} km`, description: `${months} meses da entrega ou ${formatKm(next)} km. Passar dessa quilometragem não marca a revisão como feita. Confira se o serviço já aconteceu e registre.`, date: reviewDate, km: next, due: profile.configured && (profile.km >= next || !!reviewDate && now >= reviewDate), unknown: !profile.configured, kind: 'review' }];
  for (const [serviceId, count, kind, title] of [['oil', 12, 'oil', 'Prazo de um ano do óleo'], ['brake-fluid', 24, 'brake', 'Prazo do líquido de freio']] as const) {
    const last = lastServiceDate(state, serviceId);
    const origin = last || profile.purchaseDate;
    const date = origin ? addMonths(origin, count) : null;
    results.push({ id: serviceId, title, description: last ? `Contado da última troca informada: ${displayDate(last)}. ${kind === 'oil' ? 'Uma revisão pode exigir a troca antes de completar um ano.' : 'Vale mesmo que a moto rode pouco.'}` : origin ? `Por enquanto, contamos da entrega: ${displayDate(origin)}. Se o produto já foi trocado, informe a data em que isso aconteceu.` : 'Informe a data da entrega ou da última troca. Sem ela, não é possível calcular o prazo.', date, km: null, due: !!date && now >= date, unknown: !date, kind });
  }
  for (const [serviceId, interval, kind, title] of [['chain', chainStepKm(profile.year), 'chain', 'Corrente da moto'], ['tires', 1000, 'tires', 'Pneus e pressão']] as const) {
    const entries = records.filter(record => record.serviceIds.includes(serviceId));
    const lastKm = entries.length ? Math.max(...entries.map(record => record.km)) : 0;
    const lastDate = entries.map(record => record.date).sort().slice(-1)[0];
    const date = serviceId === 'tires' && lastDate ? (() => { const d = new Date(`${lastDate}T12:00:00`); d.setDate(d.getDate() + 7); return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`; })() : null;
    results.push({ id: serviceId, title, description: `${formatKm(interval)} km${serviceId === 'tires' ? ' ou uma vez por semana. Continue verificando antes de cada saída.' : '. Faça antes do prazo nas situações indicadas no manual.'}${!entries.length ? ' Você ainda não informou quando fez esse cuidado.' : ''}`, date, km: lastKm + interval, due: profile.configured && (profile.km >= lastKm + interval || !!date && now >= date), unknown: !profile.configured || !entries.length || serviceId === 'tires' && !lastDate, kind });
  }
  return results;
}

export function timeRows(until = 60, year: ModelYear = '2025/2026') {
  return Array.from({ length: Math.floor(until / 6) }, (_, index) => {
    const months = (index + 1) * 6;
    const legacy4000 = usesCycle4000(year);
    const km = legacy4000 ? (months === 6 ? 1000 : 4000 + ((months - 12) / 6) * 4000) : months === 6 ? 1000 : (months - 6) * 1000;
    return { months, km, review: milestoneAt(km, year), oil: months % 12 === 0, brake: months % 24 === 0 };
  });
}

function escapeMarkdown(value: string) { return value.replace(/\|/g, '\\|').replace(/\n/g, '<br>'); }
export function fullPlanMarkdown(profile: Profile, upTo = 36000): string {
  const refs = (references: Reference[]) => references.map(reference => `[p. ${reference.page}${reference.page === 'Certificado' ? ` (arquivo ${reference.viewer})` : ''}](${manualUrl(profile.year, reference)})`).join(', ');
  const nxrPages = profile.year === '2025/2026' || profile.year === 'NXR-2025' || profile.year === 'NXR-2026';
  const lines = [
    `# Plano de cuidados | Honda ${modelLabel(profile.year)} · ${variantLabel(profile.variant)} · ${colorLabel(profile.color)}`,
    '', sourceScopeForYear(profile.year), '', LANGUAGE_NOTE, '', `**O que ainda precisa ser conferido:** ${SOURCE_LIMIT}`, '',
    '## Como usar', '',
    'Quilometragem / meses significa OU, o que ocorrer primeiro. Não precisa chegar aos dois. Os meses do certificado são contados desde a entrega da moto nova. Passar da quilometragem não significa que um serviço foi feito.',
    '', 'Óleo: no máximo um ano ou o intervalo da tabela, o que ocorrer primeiro. Líquido de freio: a cada dois anos. Conte os prazos a partir da troca que realmente aconteceu. Fazer uma revisão por tempo não significa trocar todas as peças.',
    '', '### O que significa cada ação', '', ...Object.values(ACTIONS).map(action => `- ${action.code}) ${action.noun}: ${action.description}`),
    '', '## Linha do tempo', '',
  ];
  for (const item of milestones(upTo, true, profile.year, profile.variant)) {
    lines.push(`### ${formatKm(item.km)} km${item.months ? ` / ${item.months} meses (o que ocorrer primeiro)` : ''}`, '', item.subtitle, '');
    if (item.notice) lines.push(`**Observação:** ${item.notice}`, '');
    lines.push('| Quando | Serviço | Peça ou sistema | O que fazer | Tipo | Por que fazer | Quando fazer antes do prazo | O que o manual diz | Página do manual |', '| --- | --- | --- | --- | --- | --- | --- | --- | --- |');
    for (const service of item.services) lines.push(`| ${formatKm(item.km)} km${item.months ? ` ou ${item.months} meses` : ''} | ${escapeMarkdown(service.service)} | ${escapeMarkdown(service.component)}${service.manualName ? ` (no manual: ${escapeMarkdown(service.manualName)})` : ''} | ${escapeMarkdown(service.description)} | ${service.actions.map(action => ACTIONS[action].label).join(', ')} | ${escapeMarkdown(service.reason)} | ${escapeMarkdown(service.anticipation)} | ${escapeMarkdown(service.notes)} | ${refs(service.refs)} |`);
    lines.push('', 'Continue fazendo todas as verificações antes de pilotar. Desgaste ou defeito pode exigir cuidado antes da próxima etapa.', '');
  }
  const cycle4000 = profile.year === '2013' || profile.year === '2014' || profile.year === 'FAN-2013' || profile.year === 'FAN-2014' || profile.year === 'CARGO-2013' || profile.year === 'CARGO-2014' || profile.year === 'CARGO-2015' || profile.year === 'START-2015';
  const next4000 = [40000, 44000, 48000, 52000, 56000, 60000].map(km => `${formatKm(km)} km / ${reviewMonths(km, profile.year)} meses`).join('; ');
  const post36 = profile.year === '2015' ? 'A nota 1 do manual manda repetir os intervalos. Depois de 36.000 km, as próximas revisões são 40.000 km / 66 meses; 44.000 km / 72 meses; 48.000 km / 78 meses; 52.000 km / 84 meses; 56.000 km / 90 meses; 60.000 km / 96 meses, sempre o que ocorrer primeiro. Continue corrente a cada 1.000 km, pneus a cada 1.000 km ou semanalmente, e os serviços programados de 4.000, 8.000, 12.000 e 16.000 km conforme a tabela 2015. O óleo continua com limite máximo de um ano e o líquido de freio, de dois anos.' : cycle4000 ? `Os intervalos se repetem a cada 4.000 km. Próximas revisões: ${next4000}, sempre o que ocorrer primeiro. Continue corrente a cada 1.000 km e pneus a cada 1.000 km ou semanalmente, e os serviços programados de 4.000, 8.000, 12.000 e 16.000 km conforme a tabela do manual. O óleo continua com o prazo próprio e o líquido de freio, com o de dois anos.` : `A tabela repete os intervalos. Próximas revisões: 42.000 km / 48 meses; 48.000 km / 54 meses; 54.000 km / 60 meses; 60.000 km / 66 meses; 66.000 km / 72 meses; 72.000 km / 78 meses, sempre o que ocorrer primeiro. Continue os serviços a cada 6.000, 12.000 ou 18.000 km, conforme o intervalo de cada um. Corrente: a cada ${profile.year === '2026' || profile.year === '2025/2026' || profile.year === 'NXR-2025' || profile.year === 'NXR-2026' ? '500' : '1.000'} km. Pneus: a cada 1.000 km ou uma vez por semana. Os prazos próprios do óleo e do líquido de freio continuam valendo.`;
  lines.push('## Depois de 36.000 km', '', post36, '', '## Cuidados por data', '', 'As etapas abaixo não zeram os prazos do óleo e do líquido de freio. Se já houve uma troca, conte da data real dessa troca. O limite de um ano do óleo não dispensa troca antes disso se a revisão exigir.', '', '| Meses desde a entrega | Revisão (km OU meses) | Óleo do motor | Líquido de freio |', '| --- | --- | --- | --- |');
  for (const row of timeRows(72, profile.year)) lines.push(`| ${row.months} meses | ${formatKm(row.km)} km ou ${row.months} meses | ${row.oil ? 'Limite de um ano: confira a última troca e os serviços da revisão.' : 'Não há um prazo próprio de seis meses. Confira a última troca e os serviços da revisão.'} | ${row.brake ? 'Prazo de dois anos: troque se passaram 24 meses desde a última troca.' : 'Confira o nível. Não trocar automaticamente só por chegar a este mês.'} |`);
  lines.push('', `Moto parada por muito tempo: retire e carregue a bateria uma vez por mês${nxrPages ? ' (p. 91)' : ''}. Isso não significa trocar a bateria todo mês nem fazer uma nova revisão mensal.`, '', '## Cuidados por desgaste ou defeito', '');
  for (const item of CONDITIONS) lines.push(`### ${item.title}`, `- Sinal: ${item.trigger}`, `- Ação: ${item.action}`, `- Fonte: ${refs(item.refs)}`, '');
  lines.push('## Uso intenso: quando a moto exige mais cuidado', '', 'No manual, uso severo. Não inventamos intervalos menores. '+(nxrPages ? 'A página 44 orienta' : 'O manual orienta')+' conversar com a concessionária para definir a frequência adequada ao seu uso.', '');
  for (const use of SEVERE_USE) lines.push(`### ${use.title}`, use.text, '', use.action, '', `Fonte: ${refs(use.refs)}`, '');
  lines.push('## O que verificar antes de pilotar', '', ...DAILY_CHECKLIST.map(item => `- [ ] **${item.title}:** ${item.text} ${refs(item.refs)}`), '', '### Verificações extras antes de sair do asfalto', '', ...OFFROAD_CHECKLIST.map(item => `- [ ] **${item.title}:** ${item.text} ${refs(item.refs)}`), '', '## Alertas de segurança', '');
  for (const alert of SAFETY_ALERTS) lines.push(`### ${alert.level === 'stop' ? 'Não continuar até corrigir' : 'Atenção: seguir orientação específica'}: ${alert.title}`, alert.text, '', `Fonte: ${refs(alert.refs)}`, '');
  lines.push('## Tabela completa', '', '| Item | Quando fazer | Prazo por tempo | Ação | Fazer antes do prazo? | Quando trocar | Página do manual |', '| --- | --- | --- | --- | --- | --- | --- |');
  for (const item of getModelServices(profile.year, profile.variant)) lines.push(`| ${item.component}${item.manualName ? ` (no manual: ${item.manualName})` : ''}: ${item.service} | ${escapeMarkdown(item.frequency)} | ${item.timeMonths ? `${item.timeMonths} meses, contados da troca real` : item.id === 'first-review' ? '6 meses desde a entrega' : 'O manual não dá um prazo próprio em meses'} | ${item.actions.map(action => ACTIONS[action].label).join(', ')} | ${escapeMarkdown(item.anticipation)} | ${escapeMarkdown(item.replacement)} | ${refs(item.refs)} |`);
  lines.push('', '**MANUTENÇÃO PROGRAMADA:** fazer o serviço previsto para cada intervalo. Pode ser só verificar, ajustar ou limpar. **CONSERTO POR DESGASTE OU DEFEITO:** depende do estado da peça e da avaliação; não é uma troca obrigatória em toda revisão.', '', '## Palavras do manual, sem complicação', '', ...MANUAL_TERMS.map(item => `- **${item.simple}** (no manual: ${item.term}): ${item.explanation}`), '', 'Guia independente, sem vínculo com a Honda. Não incluímos preços. As orientações vêm apenas do manual, não das perguntas frequentes do site. Confira o PDF original para completar as marcações da tabela que ainda faltam.');
  return lines.join('\n');
}

export function downloadText(content: string, name: string, type = 'text/plain;charset=utf-8') {
  const url = URL.createObjectURL(new Blob([content], { type }));
  const link = document.createElement('a');
  link.href = url; link.download = name;
  document.body.appendChild(link); link.click(); link.remove();
  window.setTimeout(() => URL.revokeObjectURL(url), 1000);
}

export function recordsCsv(records: MaintenanceRecord[], year: ModelYear = 'NXR-2026'): string {
  const quoted = (value: string | number) => `"${String(value).replace(/^[=+@-]/, "'$&").replace(/"/g, '""')}"`;
  return '\uFEFF' + [
    ['Data', 'Quilometragem (km)', 'Etapa do calendario (km)', 'Tipo de cuidado', 'Servicos informados', 'Numero do comprovante da oficina', 'Observacoes'],
    ...records.slice().sort((a, b) => a.date.localeCompare(b.date)).map(record => [record.date, record.km, record.milestone ?? '', record.type === 'review' ? 'Revisao programada' : record.type === 'condition' ? 'Conserto por desgaste ou defeito' : 'Cuidado de rotina', record.serviceIds.map(id => getServiceForModel(id, year, undefined).service).join('; '), record.document, record.notes]),
  ].map(row => row.map(quoted).join(',')).join('\r\n');
}

export function calendarFile(state: StoredState): string {
  const rows = ['BEGIN:VCALENDAR', 'VERSION:2.0', 'PRODID:-//Bros Caderno//Manutencao//PT-BR', 'CALSCALE:GREGORIAN'];
  const escape = (value: string) => value.replace(/\\/g, '\\\\').replace(/\n/g, '\\n').replace(/,/g, '\\,').replace(/;/g, '\\;');
  for (const reminder of reminderList(state).filter(item => item.date)) {
    rows.push('BEGIN:VEVENT', `UID:bros-${reminder.id}-${reminder.date}@caderno.local`, `DTSTAMP:${todayISO().replace(/-/g, '')}T120000Z`, `DTSTART;VALUE=DATE:${reminder.date!.replace(/-/g, '')}`, `SUMMARY:${escape(`${modelLabel(state.profile.year)}: ${reminder.title}`)}`, `DESCRIPTION:${escape(`${reminder.description} Confira a quilometragem e os serviços anteriores. A distância, o desgaste ou um defeito podem exigir cuidado antes desta data. Orientação do Manual do Proprietário ${modelLabel(state.profile.year)} · ${variantLabel(state.profile.variant)}. ${manualUrl(state.profile.year)}`)}`, 'END:VEVENT');
  }
  rows.push('END:VCALENDAR');
  return rows.map(line => {
    const chunks: string[] = [];
    let chunk = '', length = 0;
    for (const char of line) {
      const bytes = new TextEncoder().encode(char).length;
      if (length + bytes > 70) { chunks.push(chunk); chunk = ' '; length = 1; }
      chunk += char; length += bytes;
    }
    chunks.push(chunk);
    return chunks.join('\r\n');
  }).join('\r\n');
}
import { MAX_MILEAGE, withMileageReading } from '../maintenance/odometer';
import type { StoredState, TrackerLocal } from '../maintenance/types';
import type { TrackerEvent } from './types';

export const defaultTracker = (): TrackerLocal => ({ linkedAt: null, appliedSeq: 0, fraction: 0 });

export function normalizeTracker(value: unknown): TrackerLocal {
  const raw = (value && typeof value === 'object' ? value : {}) as Partial<TrackerLocal>;
  const seq = typeof raw.appliedSeq === 'number' && Number.isInteger(raw.appliedSeq) && raw.appliedSeq >= 0 ? raw.appliedSeq : 0;
  const fraction = typeof raw.fraction === 'number' && raw.fraction >= 0 && raw.fraction < 1 ? raw.fraction : 0;
  return { linkedAt: typeof raw.linkedAt === 'string' ? raw.linkedAt : null, appliedSeq: seq, fraction };
}

const km1 = (value: number) => new Intl.NumberFormat('pt-BR', { minimumFractionDigits: 1, maximumFractionDigits: 1 }).format(value);
const hhmm = (iso: string | null) => iso && Number.isFinite(Date.parse(iso)) ? new Date(iso).toLocaleString('pt-BR', { day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit' }) : '';

export interface ApplyResult {
  state: StoredState;
  /** Quilômetros somados nesta chamada (decimal). 0 quando não havia nada novo. */
  addedKm: number;
  /** Maior sequência processada; é o valor a confirmar ao servidor. */
  ackSeq: number;
  /** Atualizações ignoradas porque a quilometragem passaria do limite do app. */
  skipped: number;
}

function auditNote(event: TrackerEvent): string {
  const source = event.source === 'hardware' ? 'odômetro do rastreador' : event.source === 'accumulated' ? 'distância acumulada do rastreador' : 'viagens do rastreador';
  const when = event.tripStart && event.tripEnd ? ` Viagem de ${hhmm(event.tripStart)} a ${hhmm(event.tripEnd)}.` : '';
  const trips = event.tripIds.length ? ` Viagens: ${event.tripIds.slice(0, 3).join(', ')}${event.tripIds.length > 3 ? '…' : ''}.` : '';
  return `+${km1(event.distanceMeters / 1000)} km por ${source}. Rastreador: ${km1(event.kmBefore)} → ${km1(event.kmAfter)} km.${when}${trips} Sincronizado em ${hhmm(event.syncedAt)}.`;
}

/**
 * Soma ao plano as atualizações do rastreador ainda não aplicadas. Idempotente: cada
 * atualização tem um número de sequência e só entra se for maior que o último aplicado.
 * Trabalha com a distância (não com o total do servidor), então ajustes manuais da
 * quilometragem feitos no app continuam valendo.
 */
export function applyTrackerEvents(state: StoredState, linkedAt: string, events: TrackerEvent[]): ApplyResult {
  let tracker: TrackerLocal = state.tracker.linkedAt === linkedAt ? state.tracker : { linkedAt, appliedSeq: 0, fraction: 0 };
  let current = state;
  let added = 0; let skipped = 0; let ackSeq = tracker.appliedSeq;
  for (const event of [...events].sort((a, b) => a.seq - b.seq)) {
    if (event.seq <= tracker.appliedSeq) { ackSeq = Math.max(ackSeq, event.seq); continue; }
    if (!(event.distanceMeters > 0) || !current.profile.configured) { tracker = { ...tracker, appliedSeq: event.seq }; ackSeq = event.seq; continue; }
    const total = current.profile.km + tracker.fraction + event.distanceMeters / 1000;
    const nextKm = Math.floor(total);
    if (nextKm > MAX_MILEAGE) { skipped++; tracker = { ...tracker, appliedSeq: event.seq }; ackSeq = event.seq; continue; }
    const fraction = total - nextKm;
    current = nextKm > current.profile.km ? withMileageReading(current, nextKm, 'tracker', auditNote(event)) : current;
    tracker = { linkedAt, appliedSeq: event.seq, fraction };
    added += event.distanceMeters / 1000; ackSeq = event.seq;
  }
  return { state: { ...current, tracker }, addedKm: added, ackSeq, skipped };
}

export const formatKmDecimal = km1;

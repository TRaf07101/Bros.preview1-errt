import type { TrackerDeviceInfo, TrackerProviderInfo, TrackerStatus } from './types';

/**
 * Endereço do backend do bros. (pasta server/). Definido no build:  VITE_BROS_API_URL=https://api.exemplo.com
 * Sem ele, o app funciona como antes e a tela do rastreador explica o que falta.
 */
const RAW = (import.meta.env?.VITE_BROS_API_URL as string | undefined) || '';
export const TRACKER_API = RAW.replace(/\/$/, '');
export const trackerApiConfigured = TRACKER_API !== '';

export class TrackerApiError extends Error {
  status: number;
  code?: string;
  constructor(message: string, status: number, code?: string) { super(message); this.name = 'TrackerApiError'; this.status = status; this.code = code; }
}

async function call<T>(method: 'GET' | 'POST' | 'DELETE', path: string, body?: unknown): Promise<T> {
  if (!trackerApiConfigured) throw new TrackerApiError('O servidor do rastreador ainda não foi configurado neste app.', 0);
  let response: Response;
  try {
    response = await fetch(`${TRACKER_API}${path}`, {
      method,
      // O cookie de sessão é HttpOnly: o JavaScript do app nunca vê credenciais nem identificador.
      credentials: 'include',
      headers: { 'Content-Type': 'application/json', 'X-Bros-Client': '1' },
      body: body === undefined ? undefined : JSON.stringify(body),
    });
  } catch {
    throw new TrackerApiError('Sem conexão com o servidor do bros. Seus registros continuam neste aparelho.', 0);
  }
  const text = await response.text();
  let data: { error?: string; code?: string } & Record<string, unknown> = {};
  try { data = text ? JSON.parse(text) : {}; } catch { /* resposta fora do padrão */ }
  if (!response.ok) throw new TrackerApiError(typeof data.error === 'string' ? data.error : `O servidor respondeu com erro (${response.status}).`, response.status, data.code);
  return data as T;
}

export const trackerApi = {
  providers: () => call<{ providers: TrackerProviderInfo[] }>('GET', '/api/tracker/providers'),
  discover: (provider: string, fields: Record<string, string>) => call<{ draftId: string; devices: TrackerDeviceInfo[] }>('POST', '/api/tracker/discover', { provider, fields }),
  connect: (draftId: string, deviceId: string, bikeKm: number, bikeLabel: string) => call<TrackerStatus>('POST', '/api/tracker/connect', { draftId, deviceId, bikeKm, bikeLabel }),
  status: () => call<TrackerStatus>('GET', '/api/tracker/status'),
  sync: () => call<TrackerStatus>('POST', '/api/tracker/sync'),
  ack: (upToSeq: number) => call<TrackerStatus>('POST', '/api/tracker/ack', { upToSeq }),
  resolve: (eventId: number, action: 'apply' | 'discard') => call<TrackerStatus>('POST', `/api/tracker/events/${eventId}/resolve`, { action }),
  disconnect: () => call<TrackerStatus>('DELETE', '/api/tracker/connection'),
};

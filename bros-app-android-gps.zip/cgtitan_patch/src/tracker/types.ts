/** Formatos trocados com o servidor do bros. (server/src/app.ts). Nenhum campo sensível passa por aqui. */
export interface TrackerProviderInfo {
  id: string;
  label: string;
  help: string;
  fields: Array<{ key: string; label: string; type: 'url' | 'secret' | 'text'; placeholder?: string; help?: string }>;
}
export interface TrackerDeviceInfo { id: string; name: string; status?: string; lastUpdate?: string | null }

export type ServerStatus = 'connected' | 'trip_in_progress' | 'pending' | 'error' | 'reauth_required';

export interface TrackerConnection {
  provider: string;
  providerLabel: string;
  deviceName: string;
  bikeLabel: string;
  status: ServerStatus;
  statusMessage: string;
  odometerKind: 'hardware' | 'accumulated' | null;
  syncedKm: number;
  linkedAt: string;
  lastSyncAt: string | null;
  webhookUrl: string | null;
}

export interface TrackerEvent {
  seq: number;
  id: number;
  distanceMeters: number;
  kmBefore: number;
  kmAfter: number;
  tripStart: string | null;
  tripEnd: string | null;
  tripIds: string[];
  source: 'hardware' | 'accumulated' | 'trips';
  syncedAt: string;
}

export interface TrackerPending { id: number; reason: string; message: string; distanceKm: number; syncedAt: string; canApply: boolean }

export interface TrackerStatus { connection: TrackerConnection | null; events: TrackerEvent[]; pending: TrackerPending[] }

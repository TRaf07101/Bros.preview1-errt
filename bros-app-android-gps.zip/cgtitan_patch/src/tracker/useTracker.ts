import { useCallback, useEffect, useRef, useState } from 'react';
import type { Dispatch, SetStateAction } from 'react';
import type { StoredState } from '../maintenance/types';
import { trackerApi, trackerApiConfigured, TrackerApiError } from './api';
import { applyTrackerEvents, defaultTracker, formatKmDecimal } from './apply';
import type { TrackerDeviceInfo, TrackerProviderInfo, TrackerStatus } from './types';

export type TrackerPhase = 'unavailable' | 'none' | 'connecting' | 'connected' | 'syncing' | 'synced' | 'failed';

const EMPTY: TrackerStatus = { connection: null, events: [], pending: [] };
const POLL_VISIBLE_MS = 60_000;
const STALE_MS = 2 * 60_000;

const friendly = (error: unknown): string => error instanceof TrackerApiError ? error.message : 'Algo deu errado. Tente de novo em instantes.';

export function useTracker(state: StoredState, setState: Dispatch<SetStateAction<StoredState>>, notify: (message: string) => void) {
  const [server, setServer] = useState<TrackerStatus>(EMPTY);
  const [loaded, setLoaded] = useState(false);
  const [busy, setBusy] = useState<'connecting' | 'syncing' | null>(null);
  const [error, setError] = useState('');
  const [justSynced, setJustSynced] = useState(false);
  const stateRef = useRef(state); stateRef.current = state;
  const serverRef = useRef(server); serverRef.current = server;
  const handled = useRef(new Set<string>());
  const hasLink = state.tracker.linkedAt !== null;

  const receive = useCallback((payload: TrackerStatus) => {
    setServer(payload); setLoaded(true);
    const connection = payload.connection;
    if (!connection) {
      // O servidor não conhece mais a conexão: o controle local recomeça, sem mexer na quilometragem.
      if (stateRef.current.tracker.linkedAt !== null) setState(current => ({ ...current, tracker: defaultTracker() }));
      return;
    }
    if (!payload.events.length) return;
    const key = `${connection.linkedAt}:${payload.events.map(item => item.seq).join(',')}`;
    if (handled.current.has(key)) return;
    handled.current.add(key);
    const result = applyTrackerEvents(stateRef.current, connection.linkedAt, payload.events);
    // O atualizador é puro e idempotente (usa o número de sequência): repetir não soma duas vezes.
    setState(current => applyTrackerEvents(current, connection.linkedAt, payload.events).state);
    if (result.addedKm > 0) notify(`Quilometragem atualizada automaticamente. +${formatKmDecimal(result.addedKm)} km desde a última sincronização.`);
    else if (result.skipped > 0) notify('Uma atualização do rastreador passaria do limite de 999.999 km e não foi somada. Confira os valores.');
    void trackerApi.ack(result.ackSeq).then(setServer).catch(() => { /* a mesma atualização volta e é ignorada pela sequência */ });
  }, [setState, notify]);

  const run = useCallback(async (kind: 'status' | 'sync', quiet = false) => {
    if (!trackerApiConfigured) return;
    if (!quiet) { setBusy('syncing'); setJustSynced(false); }
    try {
      receive(kind === 'sync' ? await trackerApi.sync() : await trackerApi.status());
      setError('');
      if (!quiet) setJustSynced(true);
    } catch (caught) {
      if (!quiet) setError(friendly(caught));
      else if (caught instanceof TrackerApiError && caught.status === 0) setError(friendly(caught));
    } finally { if (!quiet) setBusy(null); setLoaded(true); }
  }, [receive]);

  // Ao abrir o app e ao voltar para ele, busca o que o servidor já sincronizou em segundo plano.
  useEffect(() => {
    if (!trackerApiConfigured || !hasLink) return;
    const refresh = () => {
      if (document.visibilityState !== 'visible') return;
      const current = serverRef.current.connection;
      const last = current?.lastSyncAt ? Date.parse(current.lastSyncAt) : 0;
      void run(Date.now() - last > STALE_MS && current ? 'sync' : 'status', true);
    };
    refresh();
    const timer = window.setInterval(refresh, POLL_VISIBLE_MS);
    document.addEventListener('visibilitychange', refresh);
    window.addEventListener('online', refresh);
    return () => { window.clearInterval(timer); document.removeEventListener('visibilitychange', refresh); window.removeEventListener('online', refresh); };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [hasLink, run]);

  const loadProviders = useCallback(async (): Promise<TrackerProviderInfo[]> => (await trackerApi.providers()).providers, []);
  const discover = useCallback(async (provider: string, fields: Record<string, string>): Promise<{ draftId: string; devices: TrackerDeviceInfo[] }> => {
    setBusy('connecting'); setError('');
    try { return await trackerApi.discover(provider, fields); }
    finally { setBusy(null); }
  }, []);
  const connect = useCallback(async (draftId: string, deviceId: string, bikeKm: number, bikeLabel: string): Promise<boolean> => {
    setBusy('connecting'); setError('');
    try {
      const payload = await trackerApi.connect(draftId, deviceId, bikeKm, bikeLabel);
      if (payload.connection) setState(current => ({ ...current, tracker: { linkedAt: payload.connection!.linkedAt, appliedSeq: 0, fraction: 0 } }));
      receive(payload); setJustSynced(true);
      return true;
    } catch (caught) { setError(friendly(caught)); return false; }
    finally { setBusy(null); }
  }, [receive, setState]);
  const resolve = useCallback(async (eventId: number, action: 'apply' | 'discard') => {
    setBusy('syncing'); setError('');
    try { receive(await trackerApi.resolve(eventId, action)); }
    catch (caught) { setError(friendly(caught)); }
    finally { setBusy(null); }
  }, [receive]);
  const disconnect = useCallback(async (): Promise<boolean> => {
    setBusy('syncing'); setError('');
    try {
      await trackerApi.disconnect();
      setServer(EMPTY); setState(current => ({ ...current, tracker: defaultTracker() }));
      return true;
    } catch (caught) { setError(friendly(caught)); return false; }
    finally { setBusy(null); }
  }, [setState]);

  const connection = server.connection;
  let phase: TrackerPhase;
  if (!trackerApiConfigured) phase = 'unavailable';
  else if (busy === 'connecting') phase = 'connecting';
  else if (busy === 'syncing') phase = 'syncing';
  else if (!connection) phase = 'none';
  else if (connection.status === 'error' || connection.status === 'reauth_required' || (error && connection.status !== 'connected')) phase = 'failed';
  else if (connection.status === 'connected' && connection.lastSyncAt && !error) phase = justSynced || Date.now() - Date.parse(connection.lastSyncAt) < 10 * 60_000 ? 'synced' : 'connected';
  else phase = 'connected';

  return { phase, server, connection, loaded, error, busy, hasLink, configured: trackerApiConfigured, refresh: () => run('sync'), load: () => run('status'), loadProviders, discover, connect, resolve, disconnect };
}

export type TrackerController = ReturnType<typeof useTracker>;

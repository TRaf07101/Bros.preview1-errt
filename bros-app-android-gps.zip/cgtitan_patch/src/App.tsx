import { useCallback, useEffect, useMemo, useState } from 'react';
import { App as NativeApp } from '@capacitor/app';
import { Capacitor } from '@capacitor/core';
import { ACTIONS, SOURCE_LIMIT, getService, getServiceForModel } from './maintenance/data';
import { highestServiceMileage, mileageChangeError, withMileageReading } from './maintenance/odometer';
import { STORAGE_KEY, defaultState, displayDate, downloadText, formatKm, fullPlanMarkdown, loadState, modelLabel, recordsCsv, reminderList, todayISO } from './maintenance/planner';
import type { MaintenanceRecord, MileageUpdate, Milestone, Profile, Service, StoredState, Usage, View } from './maintenance/types';
import { ManualTerms, Modal, Notice } from './ui/Common';
import { ProfileForm, RecordForm, ServiceDetails, SourceContent } from './ui/Dialogs';
import { HistoryView } from './ui/History';
import { Icon } from './ui/Icon';
import { ChecklistView, ConditionView, MilestoneOverview, SafetyView, SevereView, TimeView } from './ui/InfoViews';
import { PrintPlan } from './ui/PrintPlan';
import { MobileDock, NAV_ITEMS, Sidebar, Topbar, VehicleHero } from './ui/Shell';
import { ConsolidatedView, Timeline } from './ui/Timeline';
import { OdometerPanel } from './ui/Odometer';
import { TrackerPanel } from './ui/TrackerPanel';
import { useTracker } from './tracker/useTracker';
import { TripPanel } from './ui/TripPanel';
import { useTrip } from './trip/useTrip';
import { NotificationGuide, ReminderCenter, ReminderInvite } from './ui/ReminderCenter';
import { useReminders } from './reminders/useReminders';
import { appBase, useInstallState } from './reminders/pwa';
import { calendarReminders } from './reminders/plan';
import { normalizeReminderSettings } from './reminders/preferences';
import type { ReminderSettings, ReminderTarget } from './reminders/types';

type Dialog =
  | { type: 'profile' | 'source' | 'export' | 'reminders' | 'settings' | 'reset' | 'mileage' | 'tracker' | 'trip' | 'notification-guide' | 'reminder-calendar' | 'install' }
  | { type: 'service'; service: Service; milestone?: number }
  | { type: 'record'; milestone?: Milestone; serviceId?: string; recordType?: MaintenanceRecord['type'] }
  | { type: 'review'; milestone: Milestone }
  | { type: 'remove'; record: MaintenanceRecord };

const viewFromHash = (): View => {
  const id = window.location.hash.slice(1).split('/')[0];
  // A entrada padrão do app é sempre Meu plano. Um #reminders antigo,
  // deixado pela versão anterior, não deve virar a tela inicial novamente.
  if (!id || id === 'reminders') return 'timeline';
  return NAV_ITEMS.some(item => item.id === id) ? id as View : 'timeline';
};

export default function App() {
  const [state, setState] = useState<StoredState>(loadState);
  const [view, setView] = useState<View>(viewFromHash);
  const [dialog, setDialog] = useState<Dialog | null>(null);
  const [mobileMenu, setMobileMenu] = useState(false);
  const [saved, setSaved] = useState(true);
  const [toast, setToast] = useState('');
  const [printReady, setPrintReady] = useState(false);
  const [resetting, setResetting] = useState(false);
  const reminders = useMemo(() => reminderList(state), [state]);
  const closeDialog = useCallback(() => setDialog(null), []);
  const openProfile = useCallback(() => setDialog({ type: 'profile' }), []);
  const openMileage = useCallback(() => setDialog({ type: 'mileage' }), []);
  const openSource = useCallback(() => setDialog({ type: 'source' }), []);
  const openService = useCallback((service: Service, milestone?: number) => setDialog({ type: 'service', service, milestone }), []);
  const openRecord = useCallback((milestone?: Milestone) => setDialog({ type: 'record', milestone }), []);
  const navigate = useCallback((next: View) => {
    setView(next); setMobileMenu(false); setDialog(null);
    if (window.location.hash !== `#${next}`) window.history.pushState(null, '', `#${next}`);
    window.scrollTo({ top: 0, behavior: 'instant' });
  }, []);
  const openReminderAction = useCallback((target: ReminderTarget) => {
    if (target === 'checklist') { navigate('checklist'); return; }
    if (target === 'history') { navigate('history'); return; }
    navigate('reminders');
    if (target === 'mileage') setDialog({ type: 'mileage' });
    if (target === 'profile') setDialog({ type: 'profile' });
    if (target === 'maintenance') setDialog({ type: 'reminders' });
  }, [navigate]);
  const notificationController = useReminders(state, openReminderAction);
  const showToast = useCallback((message: string) => setToast(message), []);
  const tracker = useTracker(state, setState, showToast);
  const trip = useTrip();
  const installState = useInstallState();
  const setReminderSettings = (settings: ReminderSettings) => setState(current => ({ ...current, reminders: normalizeReminderSettings(settings) }));
  const installApp = async () => { const message = await installState.install(); setToast(message); if (!installState.available && !installState.installed) setDialog({ type: 'install' }); };
  const resetAll = async () => {
    setResetting(true);
    setState(current => ({ ...current, reminders: { ...current.reminders, enabled: false } }));
    const cancelled = await notificationController.reset();
    if (cancelled) { setState(defaultState()); closeDialog(); navigate('timeline'); setToast('Seus dados e a programação de notificações do app foram apagados. Eventos importados na agenda precisam ser removidos por você.'); }
    else setToast('Não foi possível confirmar o cancelamento dos avisos. Desative as notificações do app no aparelho antes de tentar apagar novamente.');
    setResetting(false);
  };

  useEffect(() => {
    try { localStorage.setItem(STORAGE_KEY, JSON.stringify(state)); setSaved(true); }
    catch { setSaved(false); }
  }, [state]);
  useEffect(() => {
    const synchronizeTabs = (event: StorageEvent) => {
      if (event.key !== STORAGE_KEY) return;
      const next = event.newValue ? loadState() : defaultState();
      setState(current => JSON.stringify(current) === JSON.stringify(next) ? current : next);
    };
    window.addEventListener('storage', synchronizeTabs);
    return () => window.removeEventListener('storage', synchronizeTabs);
  }, []);
  useEffect(() => {
    const back = () => {
      const [hash, action] = window.location.hash.slice(1).split('/');
      const isBareReminders = hash === 'reminders' && !action;
      if (hash === 'reminders' && action) setView('reminders');
      else if (!hash || isBareReminders || NAV_ITEMS.some(item => item.id === hash)) setView(viewFromHash());
      if (!hash || isBareReminders) {
        if (window.location.hash !== '#timeline') window.history.replaceState(null, '', '#timeline');
      }
      if (hash === 'reminders' && action === 'mileage') setDialog({ type: 'mileage' });
      else if (hash === 'reminders' && action === 'care') setDialog({ type: 'reminders' });
      else if (hash === 'reminders' && action === 'profile') setDialog({ type: 'profile' });
      else setDialog(null);
      setMobileMenu(false);
    };
    back();
    window.addEventListener('popstate', back);
    window.addEventListener('hashchange', back);
    return () => { window.removeEventListener('popstate', back); window.removeEventListener('hashchange', back); };
  }, []);
  useEffect(() => { document.title = `Bros. | ${NAV_ITEMS.find(item => item.id === view)?.label || 'Seu caminho em dia'}`; }, [view]);
  useEffect(() => {
    const timer = window.setInterval(() => setState(current => current.checklist.date !== todayISO() ? { ...current, checklist: { ...current.checklist, date: todayISO(), checked: [] } } : current), 30000);
    return () => window.clearInterval(timer);
  }, []);
  useEffect(() => {
    if (!toast) return;
    const timer = window.setTimeout(() => setToast(''), 4500);
    return () => window.clearTimeout(timer);
  }, [toast]);
  useEffect(() => {
    if (!mobileMenu) return;
    const dismiss = (event: KeyboardEvent) => { if (event.key === 'Escape') setMobileMenu(false); };
    window.addEventListener('keydown', dismiss);
    return () => window.removeEventListener('keydown', dismiss);
  }, [mobileMenu]);
  useEffect(() => {
    if (Capacitor.getPlatform() !== 'android') return;
    let stopped = false;
    let remove: (() => Promise<void>) | undefined;
    void NativeApp.addListener('backButton', () => {
      if (dialog) { closeDialog(); return; }
      if (mobileMenu) { setMobileMenu(false); return; }
      if (view !== 'reminders') { navigate('reminders'); return; }
      void NativeApp.minimizeApp().catch(() => {});
    }).then(handle => { if (stopped) void handle.remove(); else remove = () => handle.remove(); }).catch(() => {});
    return () => { stopped = true; void remove?.(); };
  }, [dialog, mobileMenu, view, navigate, closeDialog]);
  useEffect(() => {
    if (!printReady) return;
    const print = window.setTimeout(() => window.print(), 150);
    const after = () => setPrintReady(false);
    window.addEventListener('afterprint', after);
    return () => { window.clearTimeout(print); window.removeEventListener('afterprint', after); };
  }, [printReady]);

  const check = useCallback((id: string) => setState(current => {
    const checked = current.checklist.date === todayISO() ? current.checklist.checked : [];
    return { ...current, checklist: { ...current.checklist, date: todayISO(), checked: checked.includes(id) ? checked.filter(item => item !== id) : [...checked, id] } };
  }), []);
  const toggleUsage = (usage: Usage) => setState(current => ({ ...current, profile: { ...current.profile, usage: current.profile.usage.includes(usage) ? current.profile.usage.filter(item => item !== usage) : [...current.profile.usage, usage] } }));
  const saveProfile = (profile: Profile) => {
    setState(current => {
      const changed = !current.profile.configured || current.profile.km !== profile.km;
      const updated = changed ? withMileageReading(current, profile.km, 'profile') : current;
      const next = { ...updated, profile };
      // Persiste imediatamente no ato do salvamento. Assim, recarregar ou
      // fechar a aba logo depois de escolher uma moto não perde a seleção.
      try {
        localStorage.setItem(STORAGE_KEY, JSON.stringify(next));
      } catch {
        // O efeito de persistência abaixo sinaliza a falha na interface.
      }
      return next;
    });
    closeDialog(); setToast('Sua moto foi atualizada. Os lembretes já consideram os dados informados.');
  };
  const saveMileage = (update: MileageUpdate): string | null => {
    const error = mileageChangeError(state, update.km, update.correctionConfirmed, update.note);
    if (error) return error;
    if (update.mode === 'trip' && (!state.profile.configured || update.km <= state.profile.km)) return 'Para somar uma viagem, informe mais de zero quilômetros rodados a partir do valor salvo.';
    setState(current => withMileageReading(current, update.km, update.mode === 'trip' ? 'trip' : 'manual', update.note, update.correctionConfirmed));
    closeDialog();
    setToast(`${formatKm(update.km)} km registrados. Lembretes atualizados, sem marcar nenhum serviço como realizado.`);
    return null;
  };
  const saveRecord = (record: MaintenanceRecord) => {
    setState(current => {
      const updated = { ...current, records: [...current.records, record] };
      const knownKm = Math.max(current.profile.km, highestServiceMileage(updated.records));
      return !current.profile.configured || knownKm > current.profile.km
        ? withMileageReading(updated, knownKm, 'maintenance', `Quilometragem anotada no serviço de ${displayDate(record.date)}. O aplicativo não leu o painel automaticamente.`)
        : updated;
    });
    closeDialog(); setToast('Cuidado registrado. Somente os serviços selecionados foram anotados.');
  };
  const exportHistory = () => { downloadText(recordsCsv(state.records, state.profile.year), 'historico-bros.csv', 'text/csv;charset=utf-8'); setToast('Histórico baixado. Abra o arquivo em um aplicativo de planilhas.'); };
  const recordService = (serviceId: string, recordType?: MaintenanceRecord['type']) => setDialog({ type: 'record', serviceId, recordType });
  const activeLabel = NAV_ITEMS.find(item => item.id === view)?.label || 'Linha do tempo';

  let title = '';
  if (dialog) {
    if (dialog.type === 'profile') title = 'Sua moto. Seu ritmo.';
    if (dialog.type === 'mileage') title = 'Sua quilometragem, em dia.';
    if (dialog.type === 'tracker') title = 'Rastreador da moto';
    if (dialog.type === 'trip') title = 'Sua viagem, anotada sozinha.';
    if (dialog.type === 'source') title = 'O manual por trás do plano.';
    if (dialog.type === 'service') title = dialog.service.service;
    if (dialog.type === 'record') title = 'Registrar um cuidado.';
    if (dialog.type === 'review') title = `${formatKm(dialog.milestone.km)} km / ${dialog.milestone.months} meses`;
    if (dialog.type === 'export') title = 'Leve seu plano com você.';
    if (dialog.type === 'reminders') title = 'O próximo cuidado começa aqui.';
    if (dialog.type === 'settings') title = 'Seus dados, sob seu controle.';
    if (dialog.type === 'reset') title = 'Recomeçar este caderno?';
    if (dialog.type === 'remove') title = 'Excluir este registro?';
    if (dialog.type === 'notification-guide') title = 'Lembretes sem promessas vazias.';
    if (dialog.type === 'reminder-calendar') title = 'Sua agenda também pode lembrar.';
    if (dialog.type === 'install') title = 'Sua Bros, na tela inicial.';
  }

  return <>
    <div className="application">
      <Sidebar state={state} view={view} onView={navigate} onProfile={openProfile} onSource={openSource} onSettings={() => setDialog({ type: 'settings' })} mobile={mobileMenu} onClose={() => setMobileMenu(false)} />
      <div className="main-shell">
        <Topbar view={view} saved={saved} profile={state.profile} due={reminders.filter(item => item.due).length} onMenu={() => setMobileMenu(true)} onReminders={() => navigate('reminders')} onProfile={openProfile} onMileage={openMileage} />
        {installState.offline && <div className="connection-banner" role="status"><Icon name="wifi-off" size={15} /><span>Sem conexão. Seus registros continuam neste aparelho; links externos precisam de internet.</span></div>}
        {installState.updateReady && <div className="connection-banner update-banner"><Icon name="refresh" size={15} /><span>Uma nova versão está pronta. Salve o que estiver editando antes de atualizar.</span><button onClick={() => void installState.update()}>Atualizar app</button></div>}
        <main className="page-content" id="main-content" tabIndex={-1}>
          <header className="page-heading"><div><span className="page-overline">MANUAL NA MÃO. TRANQUILIDADE NO CAMINHO.</span><h2>{view === 'timeline' ? 'Plano de manutenção' : activeLabel}</h2></div><div className="page-actions"><button className="model-switch" onClick={openProfile}><span className="model-status-dot" />{state.profile.year} <span>/</span> {state.profile.variant}<Icon name="chevron-down" size={13} /></button><button className="button secondary export-button" onClick={() => setDialog({ type: 'export' })} aria-label="Baixar ou imprimir o plano"><Icon name="download" size={16} /><span>Baixar plano</span></button></div></header>
          {view === 'reminders' && <ReminderCenter state={state} saved={saved} controller={notificationController} install={installState} onSettings={setReminderSettings} onOpen={openReminderAction} onCalendar={() => setDialog({ type: 'reminder-calendar' })} onInstall={() => void installApp()} onGuide={() => setDialog({ type: 'notification-guide' })} />}
          {view === 'timeline' && <><VehicleHero state={state} onMileage={openMileage} onSource={openSource} onTrip={() => setDialog({ type: 'trip' })} tripActive={!!trip.track} /><ReminderInvite state={state} onOpen={() => navigate('reminders')} /><Timeline state={state} onService={openService} onRecord={openRecord} onView={navigate} onCheck={check} onSource={openSource} onConfigure={openProfile} /></>}
          {view === 'time' && <TimeView state={state} onService={openService} onMilestone={milestone => setDialog({ type: 'review', milestone })} onConfigure={openProfile} />}
          {view === 'condition' && <ConditionView state={state} onService={openService} onRecord={id => recordService(id, 'condition')} />}
          {view === 'checklist' && <ChecklistView state={state} onCheck={check} onOffroad={offroad => setState(current => ({ ...current, checklist: { ...current.checklist, offroad } }))} onReset={() => { setState(current => ({ ...current, checklist: { ...current.checklist, checked: [], date: todayISO() } })); setToast('Lista pronta para uma nova verificação.'); }} />}
          {view === 'severe' && <SevereView state={state} onToggle={toggleUsage} onService={openService} />}
          {view === 'safety' && <SafetyView state={state} />}
          {view === 'consolidated' && <ConsolidatedView state={state} onService={openService} />}
          {view === 'history' && <HistoryView state={state} onAdd={() => openRecord()} onRemove={record => setDialog({ type: 'remove', record })} onExport={exportHistory} />}
          <footer className="page-footer"><span>Seu caminho em dia.</span><p>Guia independente · Honda NXR 160 Bros · {state.profile.year} · {state.profile.variant}</p><button onClick={openSource}>Manual e avisos<Icon name="external" size={12} /></button></footer>
        </main>
      </div>
      <MobileDock view={view} onView={navigate} onMileage={openMileage} />
    </div>
    {dialog && <Modal key={dialog.type} title={title} onClose={closeDialog} drawer={dialog.type === 'service' || dialog.type === 'reminders'} wide={dialog.type === 'source' || dialog.type === 'record' || dialog.type === 'notification-guide'}>
      {dialog.type === 'profile' && <ProfileForm state={state} onSave={saveProfile} onClose={closeDialog} />}
      {dialog.type === 'mileage' && <OdometerPanel state={state} onSave={saveMileage} onClose={closeDialog} onProfile={openProfile} onHistory={() => navigate('history')} onReminders={() => navigate('reminders')} />}
      {dialog.type === 'trip' && <TripPanel state={state} trip={trip} onSave={saveMileage} onMileage={openMileage} onClose={closeDialog} />}
      {dialog.type === 'tracker' && <TrackerPanel state={state} tracker={tracker} onMileage={openMileage} onHistory={() => navigate('history')} onClose={closeDialog} />}
      {dialog.type === 'source' && <SourceContent year={state.profile.year} />}
      {dialog.type === 'service' && <ServiceDetails service={dialog.service} state={state} milestone={dialog.milestone} onRecord={recordService} />}
      {dialog.type === 'record' && <RecordForm state={state} preset={dialog.milestone} serviceId={dialog.serviceId} recordType={dialog.recordType} onSave={saveRecord} onClose={closeDialog} />}
      {dialog.type === 'review' && <MilestoneOverview state={state} milestone={dialog.milestone} onService={service => openService(service, dialog.milestone.km)} />}
      {(dialog.type === 'reminders' || dialog.type === 'settings') && <button className="mileage-access-row" onClick={openMileage}><Icon name="gauge" size={23} /><span><strong>{state.profile.configured ? `${formatKm(state.profile.km)} km informados` : 'Informe a quilometragem da sua moto'}</strong><small>Veja ou atualize o total e os registros anteriores.</small></span><Icon name="chevron" size={16} /></button>}
      {dialog.type === 'export' && <div className="export-options">
        <p>Baixe o calendário para consultar, imprimir ou levar à concessionária. Os avisos sobre o que ainda precisa ser conferido vão junto com o plano.</p>
        <button onClick={() => { downloadText(fullPlanMarkdown(state.profile), `plano-bros-${state.profile.year}-${state.profile.variant.toLowerCase()}.md`, 'text/markdown;charset=utf-8'); setToast('Plano baixado com todas as etapas e páginas do manual.'); }}><span className="export-icon"><Icon name="file" size={24} /></span><span><strong>Baixar o plano em texto</strong><small>Todas as etapas e orientações · Arquivo de texto no formato Markdown (.md)</small></span><Icon name="download" size={18} /></button>
        <button onClick={() => { closeDialog(); setPrintReady(true); }}><span className="export-icon"><Icon name="print" size={24} /></span><span><strong>Imprimir ou salvar como PDF</strong><small>Abre a impressão do plano completo, não só desta tela</small></span><Icon name="external" size={18} /></button>
        <button onClick={() => setDialog({ type: 'reminder-calendar' })}><span className="export-icon"><Icon name="calendar" size={24} /></span><span><strong>Adicionar lembretes à sua agenda</strong><small>Horários da rotina e prazos conhecidos, com pedidos de alerta</small></span><Icon name="external" size={18} /></button>
        <Notice title="Antes de pedir os serviços" tone="warning">{SOURCE_LIMIT}</Notice>
      </div>}
      {dialog.type === 'reminders' && <div className="reminders-panel">
        <p className="form-intro">Faça o cuidado quando chegar a quilometragem ou a data, o que ocorrer primeiro. Um desgaste ou defeito pode exigir atenção antes disso.</p>
        {!state.profile.configured && <Notice title="Vamos conhecer sua moto?"><p>Sem a quilometragem e as datas, mostramos apenas o plano geral. O aplicativo não detecta problemas na moto automaticamente.</p><button className="text-button" onClick={openProfile}>Informar dados da minha moto<Icon name="arrow" size={14} /></button></Notice>}
        {reminders.map(reminder => <article className={`reminder-item ${reminder.due ? 'due' : ''}`} key={reminder.id}>
          <div><span className="reminder-icon"><Icon name={reminder.kind === 'review' ? 'wrench' : reminder.kind === 'chain' ? 'chain' : reminder.kind === 'tires' ? 'circle' : 'droplet'} size={22} /></span><span><h3>{reminder.title}</h3><small>{reminder.due ? 'Prazo chegou. Confira os serviços anteriores.' : reminder.unknown ? 'Ainda faltam informações' : 'Acompanhar'}</small></span></div>
          <p>{reminder.description}</p>
          <div className="reminder-target">{reminder.km !== null && <strong>{formatKm(reminder.km)} km</strong>}{reminder.km !== null && reminder.date && <span>ou</span>}{reminder.date && <strong>{displayDate(reminder.date)}</strong>}</div>
          {reminder.kind !== 'review' && <button className="text-button" onClick={() => openService(getServiceForModel(reminder.id, state.profile.year, state.profile.variant))}>Ver orientação<Icon name="arrow" size={14} /></button>}
        </article>)}
        <button className="button primary full-width" onClick={() => openRecord()}><Icon name="plus" size={16} />Registrar um cuidado já feito</button>
        <p className="form-hint">Não ter um registro aqui não significa que o serviço nunca aconteceu. Confira os comprovantes da oficina antes de repetir um serviço.</p>
      </div>}
      {dialog.type === 'settings' && <div className="settings-content">
        <button className="settings-row" onClick={() => navigate('reminders')}><Icon name="bell-ring" size={21} /><span><strong>Meus lembretes</strong><small>Horários, dias, permissão e teste de notificação</small></span><Icon name="chevron" size={17} /></button>
        <button className="settings-row" onClick={() => void installApp()}><Icon name="smartphone" size={21} /><span><strong>{installState.installed ? 'App na tela inicial' : 'Instalar na tela inicial'}</strong><small>Acesso direto ao caderno da moto</small></span><Icon name="chevron" size={17} /></button>
        <Notice title="Seus dados ficam só neste navegador." tone={saved ? 'neutral' : 'warning'}>Modelo, quilometragem, lista de verificações e histórico ficam salvos aqui, sem criar conta. Só a função Rastreador da moto, se você conectar, usa um servidor. Se limpar os dados do navegador, perderá esses registros. O PDF que você abre não é enviado pela internet.</Notice>
        <button className="settings-row" onClick={() => setDialog({ type: 'trip' })}><Icon name="route" size={21} /><span><strong>Registrar viagem com o GPS do celular</strong><small>{trip.track ? 'Viagem em andamento' : 'Toque em iniciar, ande de moto e some os km no fim'}</small></span><Icon name="chevron" size={17} /></button>
        <button className="settings-row" onClick={() => setDialog({ type: 'tracker' })}><Icon name="route" size={21} /><span><strong>Rastreador da moto</strong><small>{!tracker.configured ? 'Atualização automática da quilometragem · servidor ainda não configurado' : tracker.connection ? `${tracker.connection.deviceName} · ${tracker.phase === 'failed' ? 'não foi possível sincronizar' : 'conectado'}` : 'Conecte para atualizar a quilometragem automaticamente'}</small></span><Icon name="chevron" size={17} /></button>
        <button className="settings-row" onClick={openProfile}><Icon name="bike" size={21} /><span><strong>Minha moto</strong><small>{state.profile.year} · {state.profile.variant}{state.profile.configured ? ` · ${formatKm(state.profile.km)} km` : ' · dados ainda não informados'}</small></span><Icon name="chevron" size={17} /></button>
        <button className="settings-row" onClick={() => { downloadText(JSON.stringify(state, null, 2), 'backup-caderno-bros.json', 'application/json'); setToast('Cópia dos seus dados baixada. Guarde o arquivo em um lugar seguro.'); }}><Icon name="download" size={21} /><span><strong>Baixar cópia de segurança</strong><small>Guarda os dados da moto e os históricos em um arquivo (.json)</small></span><Icon name="chevron" size={17} /></button>
        <button className="settings-row" onClick={exportHistory}><Icon name="history" size={21} /><span><strong>Baixar histórico para planilha</strong><small>{state.records.length} registros · Arquivo CSV</small></span><Icon name="chevron" size={17} /></button>
        <div className="settings-legend"><h3>O que significa cada cuidado?</h3>{Object.values(ACTIONS).map(action => <p key={action.code}><strong>{action.code} · {action.noun}.</strong> {action.description}</p>)}</div>
        <ManualTerms />
        <a className="settings-row" href={new URL('privacy.html', appBase()).href} target="_blank" rel="noopener noreferrer"><Icon name="shield" size={21} /><span><strong>Seus dados e privacidade</strong><small>O que fica salvo, notificações e conexões externas</small></span><Icon name="external" size={17} /></a>
        <button className="text-button danger" onClick={() => setDialog({ type: 'reset' })}><Icon name="trash" size={15} />Apagar meus dados deste navegador</button>
      </div>}
      {dialog.type === 'reset' && <div className="confirmation-content">
        <Icon name="trash" size={35} />
        <p>Serão apagados o cadastro da moto, a lista de verificações, os <strong>{state.records.length} registros de cuidados</strong> e os <strong>{state.mileageReadings.length} registros de quilometragem</strong> deste navegador. O plano geral e o manual continuarão disponíveis.</p>
        <p>Baixe uma cópia dos dados antes, se precisar guardar os históricos.</p>
        <p>Os avisos agendados pelo app serão cancelados. Eventos que você importou na agenda do celular precisam ser removidos por lá.</p>
        <div className="form-actions"><button className="button secondary" disabled={resetting} onClick={closeDialog}>Manter meus dados</button><button className="button danger-button" disabled={resetting} onClick={() => void resetAll()}>{resetting ? 'Cancelando avisos...' : 'Apagar dados'}</button></div>
      </div>}
      {dialog.type === 'notification-guide' && <NotificationGuide native={notificationController.capability.native} />}
      {dialog.type === 'install' && <div className="install-instructions"><span className="install-large-icon"><Icon name="smartphone" size={45} strokeWidth={1.3} /></span><p>No Android, abra o endereço em uma aba do navegador. No menu, escolha <strong>Instalar app</strong> ou <strong>Adicionar à tela inicial</strong>, se a opção estiver disponível.</p><p>No iPhone, use <strong>Compartilhar</strong> e <strong>Adicionar à Tela de Início</strong>. A instalação depende do navegador e de HTTPS.</p><Notice title="Instalar não é publicar na Play Store.">O ícone abre a versão web. O uso offline exige um primeiro acesso com internet à versão de produção. A instalação sozinha não cria avisos confiáveis com o site fechado.</Notice><button className="button primary full-width" onClick={() => setDialog({ type: 'notification-guide' })}>Entender os lembretes<Icon name="arrow" size={16} /></button></div>}
      {dialog.type === 'reminder-calendar' && <div className="calendar-import-guide"><span className="install-large-icon"><Icon name="calendar" size={41} strokeWidth={1.3} /></span><p>Uma alternativa para ser lembrado mesmo sem abrir este site. O arquivo usa os tipos de aviso e os horários escolhidos em Meus lembretes.</p><ol><li><strong>Baixe o arquivo.</strong> Ele inclui a rotina de verificação, a atualização dos quilômetros e os prazos futuros conhecidos que estiverem habilitados.</li><li><strong>Importe na sua agenda.</strong> Se o arquivo não abrir no celular, use a opção Importar no aplicativo ou site da sua agenda.</li><li><strong>Confira os alertas.</strong> Ative as notificações da agenda e teste um evento. Alguns aplicativos não mantêm os alarmes do arquivo.</li><li><strong>Mudou o plano? Atualize a agenda.</strong> Não há sincronização automática com este app. Remova eventos antigos para evitar duplicação.</li></ol><Notice title="Os intervalos de manutenção continuam os mesmos." tone="warning">Os horários são lembretes pessoais. Não comprovam que você conferiu a moto, não registram revisões e não substituem uma inspeção antes de cada saída. Pausar os avisos aqui não cancela eventos importados na agenda.</Notice><button className="button primary full-width" disabled={!state.reminders.checklist.enabled && !state.reminders.mileage.enabled && !state.reminders.maintenance.enabled} onClick={() => { downloadText(calendarReminders(state, notificationController.capability.native ? '' : appBase().href), 'lembretes-bros.ics', 'text/calendar;charset=utf-8'); setToast('Arquivo baixado. Importe na agenda e confira os alertas. O download sozinho não ativa notificações.'); }}><Icon name="download" size={17} />Baixar lembretes para a agenda</button></div>}
      {dialog.type === 'remove' && <div className="confirmation-content"><Icon name="trash" size={35} /><p>O atendimento de <strong>{displayDate(dialog.record.date)}</strong>, com <strong>{formatKm(dialog.record.km)} km</strong>, será removido. Os lembretes serão recalculados usando os dados restantes.</p><div className="form-actions"><button className="button secondary" onClick={closeDialog}>Manter registro</button><button className="button danger-button" onClick={() => { setState(current => ({ ...current, records: current.records.filter(record => record.id !== dialog.record.id) })); closeDialog(); setToast('Registro excluído. Lembretes recalculados.'); }}>Excluir registro</button></div></div>}
    </Modal>}
    {toast && <div className="app-toast" role="status"><span><Icon name="check" size={16} /></span><p>{toast}</p><button aria-label="Dispensar mensagem" onClick={() => setToast('')}><Icon name="close" size={15} /></button></div>}
    <PrintPlan profile={state.profile} />
    <a className="skip-link" href="#main-content" onClick={event => { event.preventDefault(); document.getElementById('main-content')?.focus({ preventScroll: true }); document.getElementById('main-content')?.scrollIntoView(); }}>Pular para o conteúdo</a>
  </>;
}
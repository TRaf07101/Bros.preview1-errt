import { useMemo, useState } from 'react';
import type { MaintenanceRecord, Milestone, Service, StoredState, View } from '../maintenance/types';
import { ACTIONS, DAILY_CHECKLIST, SOURCE_LIMIT, ref, variantNote, getModelServices } from '../maintenance/data';
import { normalizeSearch, serviceSearchText } from '../maintenance/language';
import { addMonths, formatKm, milestones, reviewMonths, isRecorded, todayISO, reminderList } from '../maintenance/planner';
import { ActionLabels, Notice, References, SectionHeading, ServiceButton } from './Common';
import { Icon } from './Icon';

interface Props {
  state: StoredState;
  onService: (service: Service, milestone?: number) => void;
  onRecord: (milestone: Milestone) => void;
  onView: (view: View) => void;
  onCheck: (id: string) => void;
  onSource: () => void;
  onConfigure: () => void;
}

export function Timeline({ state, onService, onRecord, onView, onCheck, onSource, onConfigure }: Props) {
  const [filter, setFilter] = useState<'all' | 'reviews'>('all');
  const [open, setOpen] = useState<number | null>(500);
  const [search, setSearch] = useState('');
  const [halfSteps, setHalfSteps] = useState(false);
  const [upTo, setUpTo] = useState(36000);
  const [range, setRange] = useState('all');
  const [showSearch, setShowSearch] = useState(false);
  const items = useMemo(() => milestones(upTo, halfSteps, state.profile.year, state.profile.variant).filter(item => {
    if (filter === 'reviews' && item.kind !== 'review' && item.km !== 0) return false;
    if (range === 'start' && item.km > 6000) return false;
    if (range === 'middle' && (item.km <= 6000 || item.km > 18000)) return false;
    if (range === 'end' && (item.km <= 18000 || item.km > 36000)) return false;
    if (range === 'beyond' && item.km <= 36000) return false;
    const needle = normalizeSearch(search);
    return !needle || normalizeSearch(`${item.km} ${item.title} ${item.services.map(serviceSearchText).join(' ')}`).includes(needle);
  }), [upTo, halfSteps, filter, range, search, state.profile.year]);
  const checkedCount = DAILY_CHECKLIST.filter(item => state.checklist.checked.includes(item.id)).length;
  const recordFor = (km: number): MaintenanceRecord | undefined => state.records.find(record => record.milestone === km);
  const reminders = useMemo(() => {
    const all = reminderList(state);
    const due = all.filter(item => item.due);
    const knownNext = all.find(item => !item.due && !item.unknown) || all.find(item => !item.due);
    return { due, knownNext };
  }, [state]);
  const primaryReminder = reminders.due[0] || reminders.knownNext;
  const oilReminder = reminders.due.find(item => item.kind === 'oil') || (reminders.knownNext?.kind === 'oil' ? reminders.knownNext : undefined);
  return <div className="planning-layout">
    {!state.profile.configured ? <section className="easy-start-card" aria-labelledby="easy-start-title">
      <div className="easy-start-copy"><span className="eyebrow">COMECE PELO ESSENCIAL</span><h2 id="easy-start-title">Vamos cuidar da sua Bros sem complicação.</h2><p>Você não precisa conhecer mecânica. Informe a sua versão, a quilometragem e, se souber, a última troca de óleo. O app organiza o resto para você.</p><div className="easy-start-points"><span><Icon name="gauge" size={16} /><b>Quilometragem</b><small>o número do painel</small></span><span><Icon name="droplet" size={16} /><b>Óleo</b><small>pode dizer “não lembro”</small></span><span><Icon name="bike" size={16} /><b>Sua Bros</b><small>ano, freio e cor</small></span></div></div><button className="button primary easy-start-button" onClick={onConfigure}><Icon name="sparkle" size={16} />Montar meu plano</button>
    </section> : <section className="easy-now-card" aria-labelledby="easy-now-title">
      <div className="easy-now-heading"><div><span className="eyebrow">O QUE FAZER AGORA</span><h2 id="easy-now-title">{reminders.due.length ? 'Há um cuidado para conferir.' : 'Seu plano está em dia por enquanto.'}</h2></div><button className="text-button" onClick={onConfigure}><Icon name="edit" size={13} />Atualizar dados</button></div>
      {primaryReminder ? <div className="easy-now-main"><div className={`easy-now-icon ${primaryReminder.due ? 'attention' : ''}`}><Icon name={primaryReminder.kind === 'oil' ? 'droplet' : primaryReminder.kind === 'chain' ? 'chain' : primaryReminder.kind === 'tires' ? 'circle' : 'wrench'} size={22} /></div><div><strong>{primaryReminder.title}</strong><p>{primaryReminder.description}</p>{primaryReminder.km !== null && <small>{state.profile.km >= primaryReminder.km ? 'Já chegou na quilometragem prevista.' : `Faltam ${formatKm(primaryReminder.km - state.profile.km)} km aproximadamente.`}</small>}</div></div> : <div className="easy-now-main"><div className="easy-now-icon"><Icon name="check-circle" size={22} /></div><div><strong>Você já tem um ponto de partida.</strong><p>Continue informando a quilometragem e registre o que fizer. O plano se atualiza sozinho.</p></div></div>}
      <div className="easy-now-secondary"><span><b>Próximo cuidado importante</b><small>{oilReminder?.title || 'Revisão do calendário'}</small></span><span><b>Quilometragem</b><small>{formatKm(state.profile.km)} km</small></span><span><b>O manual</b><small>detalhes continuam disponíveis abaixo</small></span></div>
    </section>}

    <section className="timeline-main">
      <SectionHeading title="Cada cuidado no seu momento." description="Da primeira saída aos próximos 36.000 km e além."><span className="range-caption">0 <span /> {formatKm(upTo)} km</span></SectionHeading>
      <div className="timeline-toolbar">
        <div className="segmented" aria-label="Filtrar etapas do calendário"><button className={filter === 'all' ? 'active' : ''} onClick={() => setFilter('all')}>Todas as etapas</button><button className={filter === 'reviews' ? 'active' : ''} onClick={() => setFilter('reviews')}>Só revisões</button></div>
        <div className="timeline-tools"><select aria-label="Quilometragem do calendário" value={range} onChange={event => { setRange(event.target.value); if (event.target.value === 'beyond') setUpTo(72000); }}><option value="all">Todas as quilometragens</option><option value="start">0 a 6.000 km</option><option value="middle">7.000 a 18.000 km</option><option value="end">19.000 a 36.000 km</option><option value="beyond">Depois de 36.000 km</option></select><button className={`icon-button ${showSearch ? 'selected' : ''}`} onClick={() => setShowSearch(!showSearch)} aria-label="Buscar uma peça ou um serviço no calendário" aria-expanded={showSearch}><Icon name="search" size={17} /></button></div>
      </div>
      {showSearch && <div className="inline-search"><Icon name="search" size={18} /><input value={search} onChange={event => setSearch(event.target.value)} placeholder="Busque peça, serviço ou quilometragem" aria-label="Buscar no calendário, por nome simples ou nome do manual" autoFocus />{search && <button onClick={() => setSearch('')} aria-label="Limpar busca"><Icon name="close" size={15} /></button>}</div>}
      <div className="timeline-interval-note"><Icon name="info" size={14} /><span>A corrente também precisa de cuidado entre estas etapas.</span><label className="tiny-toggle"><input type="checkbox" checked={halfSteps} onChange={event => setHalfSteps(event.target.checked)} /><span />Mostrar a cada 500 km</label></div>
      <div className="chronology">
        {items.map((item, index) => {
          const complete = isRecorded(state, item);
          const isOpen = open === item.km;
          const existing = recordFor(item.km);
          const deadline = item.months && state.profile.purchaseDate ? addMonths(state.profile.purchaseDate, item.months) : null;
          const due = state.profile.configured && item.km > 0 && !complete && (state.profile.km >= item.km || !!deadline && todayISO() >= deadline);
          return <article key={item.km} className={`milestone ${isOpen ? 'expanded' : ''} ${item.kind === 'review' ? 'review' : ''} ${complete ? 'recorded' : ''}`} style={{ '--row-index': Math.min(index, 7) } as React.CSSProperties}>
            <span className="timeline-node"><Icon name={complete ? 'check' : item.km === 0 ? 'flag' : item.kind === 'review' ? 'wrench' : 'circle'} size={item.kind === 'routine' && !complete ? 8 : 13} /></span>
            <button className="milestone-toggle" onClick={() => setOpen(isOpen ? null : item.km)} aria-expanded={isOpen} aria-controls={`milestone-${item.km}`}>
              <span className="milestone-distance"><strong>{formatKm(item.km)}<small>km</small></strong>{item.months && <span>ou {item.months} meses</span>}</span>
              <span className="milestone-title"><strong>{item.title}</strong><small>{item.kind === 'review' ? 'Revisão programada' : item.km === 0 ? 'Entrega da moto' : item.services.length === 1 ? 'Corrente da moto' : 'Corrente e pneus'}</small></span>
              <span className={`milestone-status ${complete ? 'complete' : due ? 'attention' : ''}`}>{complete ? 'Registrado' : due ? 'Sem registro' : item.km === 1000 ? '1ª revisão' : item.kind === 'review' ? `${item.km / 6000 + 1}ª revisão` : ''}</span>
              <Icon name="chevron-down" size={17} className="accordion-chevron" />
            </button>
            {isOpen && <div className="milestone-body" id={`milestone-${item.km}`}>
              <p className="milestone-description">{item.subtitle}</p>
              {item.km === 500 && <div className="chain-quick"><span className="chain-illustration"><svg viewBox="0 0 90 35" width="87" height="35" fill="none" aria-hidden="true"><path d="m12 14 15-4 17 4 17-4 16 4" stroke="#a6aaa6" strokeWidth="12" strokeLinecap="round" /><path d="m12 14 15-4 17 4 17-4 16 4" stroke="#f8f9f5" strokeWidth="6" strokeLinecap="round" />{[12, 28, 45, 61, 77].map((x, i) => <circle key={x} cx={x} cy={i % 2 ? 10 : 14} r="2.5" fill="#939c94" />)}<path d="M20 30h49m-4-3 5 3-5 3m-41-6-5 3 5 3" stroke="#d27555" strokeWidth="1.3" /></svg></span><p><strong>Uma corrente bem cuidada faz diferença.</strong><span>Folga: movimento livre de 20 a 30 mm. Confira com o motor desligado.</span></p><References refs={[ref(66)]} year={state.profile.year} compact /></div>}
              <div className="milestone-services">{item.services.map(service => <ServiceButton key={service.id} service={service} onClick={() => onService(service, item.km)} year={state.profile.year} done={!!existing?.serviceIds.includes(service.id)} />)}</div>
              {item.notice && <div className={`milestone-footnote ${item.km === 1000 ? 'pending' : ''}`}><Icon name={item.km === 1000 ? 'alert' : 'info'} size={14} /><p>{item.notice}</p></div>}
              <div className="milestone-bottom"><span><Icon name="book" size={13} />Verificar não significa trocar.</span><button className="text-button" onClick={() => onRecord(item)}><Icon name="plus" size={14} />Registrar cuidado</button></div>
            </div>}
          </article>;
        })}
        {!items.length && <div className="empty-state"><Icon name="search" size={30} /><h3>Nenhuma etapa encontrada.</h3><p>Tente outra peça ou limpe os filtros.</p><button className="button secondary" onClick={() => { setSearch(''); setRange('all'); setFilter('all'); }}>Limpar filtros</button></div>}
      </div>
      <div className="beyond-section">
        <span className="eyebrow">O CAMINHO CONTINUA</span><h3>E depois de 36.000 km?</h3>
        <p>A nota 2 manda repetir os intervalos. Continue as revisões a cada 6.000 km, respeitando também os meses do certificado. Os serviços de 12.000 km se repetem a cada 12.000 km; os de 18.000 km, a cada 18.000 km.</p>
        <div className="next-milestones">{[42000, 48000, 54000].map(km => <button key={km} onClick={() => { setUpTo(72000); setRange('beyond'); setOpen(km); }}><strong>{formatKm(km)} <small>km</small></strong><span>ou {reviewMonths(km)} meses</span><Icon name="arrow" size={16} /></button>)}</div>
        <p className="beyond-note">Não zere os prazos da corrente, dos pneus ou do líquido de freio ao avançar no calendário. <References refs={[ref(46)]} year={state.profile.year} /></p>
        {upTo === 36000 && <button className="text-button" onClick={() => { setUpTo(72000); setRange('beyond'); }}>Ver até 72.000 km<Icon name="arrow" size={16} /></button>}
      </div>
    </section>
    <aside className="planner-aside">
      <div className="daily-preview"><div className="aside-kicker"><span><Icon name="checklist" size={18} />CUIDADOS DO DIA</span><span>{checkedCount}<small>/9</small></span></div><h3>Antes de pegar<br />a estrada.</h3><p>Pequenas verificações.<br />Mais tranquilidade para pilotar.</p><div className="daily-preview-list">{[DAILY_CHECKLIST[2], DAILY_CHECKLIST[4], DAILY_CHECKLIST[8]].map(item => <label key={item.id}><input type="checkbox" checked={state.checklist.checked.includes(item.id)} onChange={() => onCheck(item.id)} /><span className="custom-check"><Icon name="check" size={11} /></span><span>{item.title}</span></label>)}</div><button className="text-button" onClick={() => onView('checklist')}>Abrir lista completa<Icon name="arrow" size={15} /></button><div className="daily-preview-progress"><span style={{ width: `${checkedCount / 9 * 100}%` }} /></div></div>
      <div className="first-rule"><span className="aside-line-icon"><Icon name="clock" size={23} /></span><h4>O que ocorrer primeiro.</h4><p>Quilometragem <strong>ou</strong> tempo. Você não precisa atingir os dois para fazer a revisão.</p><button className="text-button" onClick={() => onView('time')}>Entenda os prazos<Icon name="external" size={13} /></button></div>
      <div className="action-key"><span className="eyebrow">CADA CUIDADO É DIFERENTE</span>{(['inspect', 'adjust', 'clean', 'lubricate', 'replace', 'repair'] as const).map(action => <div key={action}><span className={`legend-dot ${action}`} /><strong>{ACTIONS[action].label}</strong><span>{ACTIONS[action].code}</span></div>)}<p>Verificar não significa trocar.</p></div>
      <div className="variant-note"><Icon name="shield" size={19} /><h4>Um cuidado para sua versão {state.profile.variant}.</h4><p>{variantNote(state.profile.variant, state.profile.year)}</p><References refs={[ref(19), ref(64)]} year={state.profile.year} compact /></div>
      <button className="source-aside" onClick={onSource}><Icon name="book" size={23} /><span><strong>O manual é o ponto de partida.</strong><small>Veja o manual e o que ainda falta conferir.</small></span><Icon name="external" size={15} /></button>
    </aside>
  </div>;
}

export function ConsolidatedView({ state, onService }: { state: StoredState; onService: (service: Service) => void }) {
  const [search, setSearch] = useState('');
  const [category, setCategory] = useState('all');
  const services = getModelServices(state.profile.year, state.profile.variant).filter(item => (category === 'all' || item.actions.includes(category as 'inspect')) && normalizeSearch(serviceSearchText(item)).includes(normalizeSearch(search)));
  return <section className="full-section">
    <SectionHeading label="CONSULTA COMPLETA" title="Tudo em uma só tabela." description="Quando cuidar, o que fazer e quando trocar. Nomes simples, com o nome do manual nos detalhes." />
    <div className="table-tools"><div className="inline-search"><Icon name="search" size={18} /><input placeholder="Buscar peça ou serviço" value={search} onChange={event => setSearch(event.target.value)} aria-label="Buscar na tabela, por nome simples ou nome do manual" /></div><select aria-label="Filtrar por tipo de cuidado" value={category} onChange={event => setCategory(event.target.value)}><option value="all">Todos os cuidados</option>{Object.entries(ACTIONS).map(([id, action]) => <option value={id} key={id}>{action.label}</option>)}</select></div>
    <div className="table-scroll"><table className="consolidated-table">
      <thead><tr><th>Item</th><th>Quando fazer</th><th>Prazo por tempo</th><th>O que fazer</th><th>Fazer antes do prazo?</th><th>Quando trocar</th></tr></thead>
      <tbody>{services.map(item => <tr key={item.id}>
        <td><button className="table-item" onClick={() => onService(item)}>{item.component}<Icon name="external" size={12} /></button><small>{item.service}</small>{item.manualName && <small>No manual: {item.manualName}</small>}<References refs={item.refs.slice(0, 2)} year={state.profile.year} compact /></td>
        <td>{item.frequency}{item.pending && <span className="validation-pending">Ainda falta conferir no original</span>}</td>
        <td>{item.timeMonths ? `${item.timeMonths} meses` : item.id === 'first-review' ? 'Revisão: 6 meses desde a entrega' : 'O manual não dá um prazo próprio em meses'}</td>
        <td><ActionLabels actions={item.actions} compact /></td><td>{item.anticipation}</td><td>{item.replacement}</td>
      </tr>)}</tbody>
    </table>{!services.length && <div className="empty-state"><p>Nenhuma peça ou serviço encontrado.</p></div>}</div>
    <div className="programmed-vs-condition"><div><Icon name="calendar" size={22} /><h3>Manutenção programada</h3><p>Fazer o cuidado previsto no manual: verificar, ajustar se necessário, limpar, lubrificar ou trocar. Uma revisão não é uma lista de peças que precisam ser novas.</p></div><div><Icon name="wrench" size={22} /><h3>Conserto por desgaste ou defeito</h3><p>Depende do estado da peça e do problema encontrado. Pastilhas, pneus, corrente, cabos e rolamentos não são trocados automaticamente em toda revisão.</p></div></div>
    <Notice title="O que ainda precisa ser conferido" tone="warning">{SOURCE_LIMIT}</Notice>
  </section>;
}
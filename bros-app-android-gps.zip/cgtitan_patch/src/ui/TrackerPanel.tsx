import { useEffect, useState } from 'react';
import type { FormEvent } from 'react';
import { modelLabel } from '../maintenance/planner';
import type { StoredState } from '../maintenance/types';
import { formatKmDecimal } from '../tracker/apply';
import type { TrackerController } from '../tracker/useTracker';
import type { TrackerDeviceInfo, TrackerProviderInfo } from '../tracker/types';
import { Notice } from './Common';
import { Icon } from './Icon';

const PHASE_LABEL = {
  unavailable: 'Indisponível', none: 'Não conectado', connecting: 'Conectando...', connected: 'Conectado',
  syncing: 'Sincronizando...', synced: 'Sincronizado', failed: 'Não foi possível sincronizar',
} as const;

export function syncMoment(iso: string | null): string {
  if (!iso || !Number.isFinite(Date.parse(iso))) return 'ainda não sincronizado';
  const date = new Date(iso); const now = new Date();
  const time = date.toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' });
  const same = (a: Date, b: Date) => a.toDateString() === b.toDateString();
  if (same(date, now)) return `hoje, ${time}`;
  const yesterday = new Date(now); yesterday.setDate(now.getDate() - 1);
  if (same(date, yesterday)) return `ontem, ${time}`;
  return `${date.toLocaleDateString('pt-BR', { day: '2-digit', month: '2-digit' })}, ${time}`;
}

function ConnectFlow({ state, tracker, onMileage, onDone }: { state: StoredState; tracker: TrackerController; onMileage: () => void; onDone: () => void }) {
  const [providers, setProviders] = useState<TrackerProviderInfo[] | null>(null);
  const [providerId, setProviderId] = useState('');
  const [fields, setFields] = useState<Record<string, string>>({});
  const [draft, setDraft] = useState<{ id: string; devices: TrackerDeviceInfo[] } | null>(null);
  const [deviceId, setDeviceId] = useState('');
  const [loadError, setLoadError] = useState('');
  const provider = providers?.find(item => item.id === providerId);

  useEffect(() => {
    let alive = true;
    tracker.loadProviders().then(list => { if (alive) { setProviders(list); setProviderId(list[0]?.id || ''); } })
      .catch(() => { if (alive) setLoadError('Não foi possível carregar os rastreadores compatíveis. Verifique a internet e tente de novo.'); });
    return () => { alive = false; };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  if (!state.profile.configured) return <Notice tone="warning" title="Antes de conectar, informe a quilometragem da sua moto.">
    O rastreador mede a distância percorrida, mas não sabe quanto a moto já rodou. Você informa o total atual uma única vez; depois o bros. soma só o que o rastreador medir.
    <button type="button" className="text-button" onClick={onMileage}>Informar quilometragem<Icon name="arrow" size={14} /></button>
  </Notice>;
  if (loadError) return <Notice tone="warning" title="Não foi possível continuar.">{loadError}</Notice>;
  if (!providers) return <p className="tracker-wait" role="status">Carregando...</p>;
  if (!providers.length) return <Notice tone="warning" title="Nenhum rastreador compatível.">O servidor do bros. não tem nenhum provedor ativado.</Notice>;

  const find = async (event: FormEvent) => {
    event.preventDefault();
    try { const result = await tracker.discover(providerId, fields); setDraft({ id: result.draftId, devices: result.devices }); setDeviceId(result.devices.length === 1 ? result.devices[0].id : ''); setFields(current => ({ ...current, token: '' })); }
    catch { /* a mensagem aparece abaixo pelo estado do hook */ }
  };
  const link = async (event: FormEvent) => {
    event.preventDefault();
    if (!draft || !deviceId) return;
    if (await tracker.connect(draft.id, deviceId, state.profile.km, modelLabel(state.profile.year) || 'Minha moto')) onDone();
  };
  const busy = tracker.phase === 'connecting';

  if (draft) return <form className="tracker-form" onSubmit={link}>
    <fieldset className="tracker-devices" disabled={busy}>
      <legend>Qual destes rastreadores está na sua moto?</legend>
      {draft.devices.map(device => <label key={device.id} className={deviceId === device.id ? 'selected' : ''}>
        <input type="radio" name="tracker-device" value={device.id} checked={deviceId === device.id} onChange={() => setDeviceId(device.id)} />
        <span><strong>{device.name}</strong><small>{device.status === 'online' ? 'Online agora' : device.lastUpdate ? `Último sinal: ${syncMoment(device.lastUpdate)}` : 'Sem sinal recente'}</small></span>
      </label>)}
    </fieldset>
    <p className="tracker-baseline">A quilometragem de partida será <strong>{formatKmDecimal(state.profile.km)} km</strong>, a que está salva no bros. Viagens anteriores a esta conexão não são somadas.</p>
    {tracker.error && <p className="form-error" role="alert">{tracker.error}</p>}
    <footer className="form-actions"><button type="button" className="button secondary" disabled={busy} onClick={() => setDraft(null)}>Voltar</button><button type="submit" className="button primary" disabled={busy || !deviceId}>{busy ? 'Conectando...' : 'Conectar este rastreador'}</button></footer>
  </form>;

  return <form className="tracker-form" onSubmit={find}>
    {providers.length > 1 && <label className="form-label">Plataforma do rastreador<select value={providerId} onChange={event => { setProviderId(event.target.value); setFields({}); }}>{providers.map(item => <option key={item.id} value={item.id}>{item.label}</option>)}</select></label>}
    {provider && <>
      <p className="form-intro">{provider.help}</p>
      {provider.fields.map(field => <label className="form-label" key={field.key}>{field.label}
        <input required type={field.type === 'secret' ? 'password' : field.type === 'url' ? 'url' : 'text'} autoComplete="off" autoCapitalize="none" spellCheck={false} value={fields[field.key] || ''} placeholder={field.placeholder} onChange={event => setFields(current => ({ ...current, [field.key]: event.target.value }))} />
        {field.help && <small className="optional">{field.help}</small>}
      </label>)}
    </>}
    {tracker.error && <p className="form-error" role="alert">{tracker.error}</p>}
    <footer className="form-actions"><button type="submit" className="button primary" disabled={busy || !provider}>{busy ? 'Conectando...' : 'Continuar'}</button></footer>
  </form>;
}

export function TrackerPanel({ state, tracker, onMileage, onHistory, onClose }: { state: StoredState; tracker: TrackerController; onMileage: () => void; onHistory: () => void; onClose: () => void }) {
  const [connecting, setConnecting] = useState(false);
  const [confirmOff, setConfirmOff] = useState(false);
  const { phase, connection, server } = tracker;

  // Ao abrir a tela, confere o servidor. Quem já tem rastreador recebe a sincronização mais recente.
  useEffect(() => { if (tracker.configured) void (tracker.hasLink ? tracker.refresh() : tracker.load()); /* eslint-disable-next-line react-hooks/exhaustive-deps */ }, []);

  if (phase === 'unavailable') return <div className="tracker-panel">
    <p className="tracker-state"><span className="tracker-dot" />Indisponível neste app</p>
    <Notice tone="warning" title="O servidor do rastreador ainda não foi configurado.">
      A conexão com o rastreador funciona por um servidor próprio do bros., que guarda a senha ou o token com segurança e sincroniza com o app fechado. Este app foi gerado sem o endereço desse servidor (VITE_BROS_API_URL). Veja o passo a passo em server/README.md. Enquanto isso, a quilometragem continua sendo informada por você.
    </Notice>
  </div>;

  if (!connection) return <div className="tracker-panel">
    <p className="tracker-state"><span className="tracker-dot off" />{PHASE_LABEL[phase === 'connecting' ? 'connecting' : 'none']}</p>
    {!connecting ? <>
      <p className="tracker-lead">Conecte o rastreador da sua moto para atualizar a quilometragem automaticamente.</p>
      <ul className="tracker-points">
        <li>O bros. recebe as viagens do rastreador e soma a distância percorrida, sem você digitar nada.</li>
        <li>A sincronização acontece em um servidor, com o app fechado.</li>
        <li>Se os dados não forem confiáveis, a quilometragem não muda e você é avisado.</li>
      </ul>
      {tracker.error && <p className="form-error" role="alert">{tracker.error}</p>}
      <button type="button" className="button primary" onClick={() => setConnecting(true)}><Icon name="link" size={16} />Conectar</button>
    </> : <ConnectFlow state={state} tracker={tracker} onMileage={onMileage} onDone={() => setConnecting(false)} />}
  </div>;

  const total = state.profile.km + state.tracker.fraction;
  const kindText = connection.odometerKind === 'hardware' ? 'Usando o odômetro do rastreador' : connection.odometerKind === 'accumulated' ? 'Usando a distância acumulada do rastreador' : 'Somando as viagens registradas';
  const failed = phase === 'failed';
  return <div className="tracker-panel">
    <p className={`tracker-state ${failed ? 'failed' : ''}`} role="status"><span className={`tracker-dot ${failed ? 'bad' : phase === 'syncing' ? 'busy' : ''}`} />{failed ? PHASE_LABEL.failed : connection.status === 'trip_in_progress' ? 'Viagem em andamento' : PHASE_LABEL[phase]}</p>
    <h3 className="tracker-title">Rastreador conectado</h3>
    <dl className="tracker-facts">
      <div><dt>Moto</dt><dd>{connection.bikeLabel}</dd></div>
      <div><dt>Rastreador</dt><dd>{connection.deviceName} · {connection.providerLabel}</dd></div>
      <div><dt>Última sincronização</dt><dd>{syncMoment(connection.lastSyncAt)}</dd></div>
      <div><dt>Quilometragem sincronizada</dt><dd className="tracker-km">{state.profile.configured ? formatKmDecimal(total) : formatKmDecimal(connection.syncedKm)} <small>km</small></dd></div>
    </dl>
    <p className="tracker-source">{kindText}.</p>
    {(failed || tracker.error) && <Notice tone="warning" title="Não foi possível sincronizar.">{tracker.error || connection.statusMessage || 'Tente de novo em instantes.'}{connection.status === 'reauth_required' && <button type="button" className="text-button" onClick={() => { void tracker.disconnect().then(ok => ok && setConnecting(true)); }}>Conectar de novo<Icon name="arrow" size={14} /></button>}</Notice>}
    {server.pending.map(item => <Notice key={item.id} tone="warning" title="Atualização aguardando conferência">
      <p>{item.message}</p>
      {item.canApply && <p>O rastreador mediu {formatKmDecimal(item.distanceKm)} km.</p>}
      <span className="tracker-pending-actions">
        {item.canApply && <button type="button" className="button secondary" disabled={tracker.busy !== null} onClick={() => void tracker.resolve(item.id, 'apply')}>Somar {formatKmDecimal(item.distanceKm)} km</button>}
        <button type="button" className="button secondary" disabled={tracker.busy !== null} onClick={() => void tracker.resolve(item.id, 'discard')}>Não somar</button>
      </span>
    </Notice>)}
    <div className="tracker-actions">
      <button type="button" className="button secondary" disabled={tracker.busy !== null} onClick={() => void tracker.refresh()}><Icon name="refresh" size={15} />{tracker.busy === 'syncing' ? 'Sincronizando...' : 'Sincronizar agora'}</button>
      <button type="button" className="text-button" onClick={onHistory}>Ver histórico de quilometragem<Icon name="arrow" size={14} /></button>
    </div>
    <p className="tracker-note">O bros. mostra quilômetros inteiros nos lembretes; a fração fica guardada até completar o próximo quilômetro. Ajustes feitos por você na quilometragem continuam valendo.</p>
    {!confirmOff ? <button type="button" className="text-button danger" onClick={() => setConfirmOff(true)}>Desconectar rastreador</button>
      : <div className="tracker-confirm"><p>Isto apaga a credencial e as viagens guardadas no servidor. A quilometragem e o histórico do bros. ficam como estão.</p><span><button type="button" className="button secondary" onClick={() => setConfirmOff(false)}>Manter conectado</button><button type="button" className="button danger-button" disabled={tracker.busy !== null} onClick={() => void tracker.disconnect().then(ok => { if (ok) { setConfirmOff(false); onClose(); } })}>Desconectar</button></span></div>}
  </div>;
}

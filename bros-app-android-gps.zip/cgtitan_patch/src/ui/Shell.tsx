import { useLayoutEffect, useState } from 'react';
import type { Profile, StoredState, View } from '../maintenance/types';
import { displayDate, formatKm, reminderList } from '../maintenance/planner';
import { latestMileageReading, mileageDistance, mileageTimestamp } from '../maintenance/odometer';
import { colorLabel, motorcycleImagePath } from '../maintenance/models';
import { modelLabel } from '../maintenance/planner';
import { BrandMark, Icon } from './Icon';
import { RemoteMotorcycleImage } from './RemoteMotorcycleImage';

export const NAV_ITEMS: { id: View; label: string; icon: string; group: string }[] = [
  { id: 'reminders', label: 'Meus lembretes', icon: 'bell', group: 'SEU PLANO' },
  { id: 'timeline', label: 'Meu plano', icon: 'route', group: 'SEU PLANO' },
  { id: 'time', label: 'Prazos por data', icon: 'calendar', group: 'SEU PLANO' },
  { id: 'condition', label: 'Desgaste e defeitos', icon: 'wrench', group: 'SEU PLANO' },
  { id: 'checklist', label: 'Antes de pilotar', icon: 'checklist', group: 'NA ROTINA' },
  { id: 'severe', label: 'Uso intenso', icon: 'mountain', group: 'NA ROTINA' },
  { id: 'safety', label: 'Alertas de segurança', icon: 'shield', group: 'NA ROTINA' },
  { id: 'consolidated', label: 'Tabela completa', icon: 'layers', group: 'MEUS REGISTROS' },
  { id: 'history', label: 'Histórico de cuidados', icon: 'history', group: 'MEUS REGISTROS' },
];

export function Sidebar({ state, view, onView, onProfile, onSource, onSettings, mobile, onClose }: { state: StoredState; view: View; onView: (view: View) => void; onProfile: () => void; onSource: () => void; onSettings: () => void; mobile: boolean; onClose: () => void }) {
  return <><div className={`mobile-nav-scrim ${mobile ? 'open' : ''}`} onClick={onClose} /><aside className={`sidebar ${mobile ? 'mobile-open' : ''}`}>
    <button className="sidebar-brand" onClick={() => onView('timeline')} aria-label="Bros: voltar ao plano"><BrandMark /></button>
    <button className="garage-select" onClick={onProfile}><span className="garage-icon"><Icon name="bike" size={21} /></span><span><strong>Minha moto</strong><small>{state.profile.configured ? `${modelLabel(state.profile.year)} · ${state.profile.variant} · ${colorLabel(state.profile.color)}` : 'Ainda não configurada'}</small></span><Icon name="chevron-down" size={15} /></button>
    <nav aria-label="Navegação do plano">{['SEU PLANO', 'NA ROTINA', 'MEUS REGISTROS'].map(group => <div className="nav-group" key={group}><span>{group}</span>{NAV_ITEMS.filter(item => item.group === group).map(item => <button key={item.id} className={`nav-item ${item.id === view ? 'active' : ''}`} onClick={() => onView(item.id)} aria-current={item.id === view ? 'page' : undefined}><Icon name={item.icon} size={18} /><span>{item.label}</span>{item.id === view && <i />}{item.id === 'history' && state.records.length > 0 && <small>{state.records.length}</small>}</button>)}</div>)}</nav>
    <div className="sidebar-bottom"><button className="sidebar-manual" onClick={onSource}><span><Icon name="book" size={24} /></span><strong>Seu manual,<br />sempre por perto.</strong><small>Ver manual e avisos<Icon name="external" size={12} /></small></button><button className="sidebar-settings" onClick={onSettings}><Icon name="settings" size={17} />Configurações e dados<Icon name="chevron" size={13} /></button><div className="independent-label"><span />GUIA INDEPENDENTE · NÃO OFICIAL</div></div>
  </aside></>;
}

export function MobileDock({ view, onView, onMileage }: { view: View; onView: (view: View) => void; onMileage: () => void }) {
  return <nav className="mobile-app-dock" aria-label="Acesso rápido no celular">
    <button className={view === 'reminders' ? 'active' : ''} onClick={() => onView('reminders')} aria-current={view === 'reminders' ? 'page' : undefined}><Icon name="bell" size={20} /><span>Lembretes</span></button>
    <button className={view === 'timeline' ? 'active' : ''} onClick={() => onView('timeline')} aria-current={view === 'timeline' ? 'page' : undefined}><Icon name="route" size={20} /><span>Meu plano</span></button>
    <button className="dock-mileage" onClick={onMileage}><span><Icon name="gauge" size={23} /></span><small>Atualizar km</small></button>
    <button className={view === 'checklist' ? 'active' : ''} onClick={() => onView('checklist')} aria-current={view === 'checklist' ? 'page' : undefined}><Icon name="checklist" size={20} /><span>Antes de sair</span></button>
    <button className={view === 'history' ? 'active' : ''} onClick={() => onView('history')} aria-current={view === 'history' ? 'page' : undefined}><Icon name="history" size={20} /><span>Histórico</span></button>
  </nav>;
}

export function Topbar({ view, saved, profile, onMenu, onReminders, onProfile, onMileage, due }: { view: View; saved: boolean; profile: Profile; onMenu: () => void; onReminders: () => void; onProfile: () => void; onMileage: () => void; due: number }) {
  return <header className="topbar">
    <button className="icon-button mobile-menu" aria-label="Abrir navegação" onClick={onMenu}><Icon name="menu" /></button>
    <div className="breadcrumb"><Icon name="bike" size={16} /><span>Minha garagem</span><Icon name="chevron" size={12} /><strong>{NAV_ITEMS.find(item => item.id === view)?.label}</strong></div>
    <div className="topbar-actions">
      <span className="local-save"><span className={saved ? '' : 'save-error'} />{saved ? 'Salvo neste dispositivo' : 'Não foi possível salvar'}</span>
      <button className="topbar-mileage" onClick={onMileage} aria-label={profile.configured ? `Quilometragem informada: ${formatKm(profile.km)} km. Ver ou atualizar o valor.` : 'Informar e acompanhar a quilometragem da moto'} title="Ver, atualizar ou somar quilômetros rodados">
        <Icon name="gauge" size={17} /><span>{profile.configured ? <>{formatKm(profile.km)} <small>km</small></> : 'Informar km'}</span><Icon name="edit" size={12} />
      </button>
      <button className="icon-button notification-button" aria-label={`Abrir lembretes${due ? `, ${due} pontos de atenção` : ''}`} onClick={onReminders}><Icon name="bell" size={19} />{due > 0 && <i />}</button>
      <span className="topbar-divider" />
      <button className="profile-button" aria-label="Configurar minha motocicleta" onClick={onProfile}><Icon name="user" size={17} /></button>
    </div>
  </header>;
}

export function VehicleHero({ state, onMileage, onSource, onTrip, tripActive = false }: { state: StoredState; onMileage: () => void; onSource: () => void; onTrip?: () => void; tripActive?: boolean }) {
  const [failed, setFailed] = useState(false);
  const [loaded, setLoaded] = useState(false);
  const next = reminderList(state)[0];
  const distance = mileageDistance(state.profile, next);
  const latestReading = latestMileageReading(state);
  const source = motorcycleImagePath(state.profile.year, state.profile.variant, state.profile.color);
  useLayoutEffect(() => { setFailed(false); setLoaded(false); }, [source]);
  return <>
    <section className={`vehicle-hero ${!state.profile.configured ? 'vehicle-hero-unconfigured' : ''}`} aria-label={`Plano da ${modelLabel(state.profile.year)}`}><div className="hero-copy"><span className="eyebrow"><span className="red-rule" />{state.profile.configured ? `HONDA · ${state.profile.year.replace('/', ' / ')}` : 'HONDA · SUA MOTO'}</span><h1>{state.profile.year === 'START-2015' ? <>CG 150 <span>Start.</span></> : state.profile.year === 'START-2026' || state.profile.year === 'START-2022' ? <>CG 160 <span>Start.</span></> : state.profile.year === 'CARGO-2013' || state.profile.year === 'CARGO-2014' || state.profile.year === 'CARGO-2015' ? <>CG 150 <span>Cargo.</span></> : state.profile.year === 'CARGO-2016' || state.profile.year === 'CARGO-2017' || state.profile.year === 'CARGO-2018' || state.profile.year === 'CARGO-2019' || state.profile.year === 'CARGO-2020' || state.profile.year === 'CARGO-2021' || state.profile.year === 'CARGO-2022' || state.profile.year === 'CARGO-2023' || state.profile.year === 'CARGO-2024' || state.profile.year === 'CARGO-2025' || state.profile.year === 'CARGO-2026' ? <>CG 160 <span>Cargo.</span></> : state.profile.year === 'TITAN-2026' ? <>CG 160 <span>Titan.</span></> : state.profile.year === 'FAN-2013' || state.profile.year === 'FAN-2014' ? <>CG 150 <span>Fan.</span></> : state.profile.year === 'FAN-2015' || state.profile.year === 'FAN-2016' || state.profile.year === 'FAN-2017' || state.profile.year === 'FAN-2018' || state.profile.year === 'FAN-2019' || state.profile.year === '2020' || state.profile.year === '2021' || state.profile.year === '2022' || state.profile.year === '2023' || state.profile.year === '2024' || state.profile.year === '2025' || state.profile.year === '2026' ? <>CG 160 <span>Fan.</span></> : state.profile.year === '2013' || state.profile.year === '2014' ? <>NXR 150 <span>Bros.</span></> : <>NXR 160 <span>Bros.</span></>}</h1><p>{state.profile.configured ? <>Cuidado certo. No momento certo.<br /><span>Mais tranquilidade em cada caminho.</span></> : <>Primeiro, vamos descobrir qual é a sua.<br /><span>Depois eu organizo os cuidados para você.</span></>}</p><button className="hero-source-link" onClick={onSource}><Icon name="book" size={13} />Baseado no Manual do Proprietário<Icon name="external" size={12} /></button></div><div className="hero-motorcycle"><span className="hero-number" aria-hidden="true">{state.profile.year === '2013' || state.profile.year === '2014' || state.profile.year === 'FAN-2013' || state.profile.year === 'FAN-2014' || state.profile.year === 'START-2015' ? '150' : '160'}</span>{state.profile.configured ? (!failed ? (source.startsWith('http') ? <RemoteMotorcycleImage source={source} alt={`${modelLabel(state.profile.year)}, ${state.profile.variant}, cor ${colorLabel(state.profile.color)}, imagem de apresentação do modelo`} onReady={() => setLoaded(true)} onError={() => setFailed(true)} /> : <img key={source} className={`${loaded ? 'loaded ' : ''}transparent-motorcycle`} src={source} alt={`${modelLabel(state.profile.year)}, ${state.profile.variant}, cor ${colorLabel(state.profile.color)}, imagem de apresentação do modelo`} onLoad={() => setLoaded(true)} onError={() => setFailed(true)} fetchPriority="high" />) : <div className="motorcycle-fallback" role="img" aria-label={`Foto indisponível para ${modelLabel(state.profile.year)}`}><span>Foto indisponível</span></div>) : <div className="hero-setup-placeholder"><Icon name="bike" size={92} /><strong>Escolha sua moto</strong><span>Ano · freio · cor</span></div>}<span className="motorcycle-ground" /></div><span className="hero-caption">{state.profile.configured ? 'UM PLANO PARA SEGUIR EM FRENTE.' : 'SEU PLANO COMEÇA COM TRÊS ESCOLHAS.'}</span></section>
    <div className="vehicle-progress">
      <span className="odometer-symbol"><Icon name="gauge" size={24} /></span>
      <div className="odometer-copy">
        <span className="eyebrow">{state.profile.configured ? 'QUILOMETRAGEM INFORMADA' : 'CADA JORNADA É DIFERENTE'}</span>
        <strong>{state.profile.configured ? <>{formatKm(state.profile.km)} <span>km</span></> : 'Qual é a quilometragem da sua moto?'}</strong>
        <small>{state.profile.configured ? latestReading?.createdAt ? `Atualizada em ${mileageTimestamp(latestReading.createdAt)}` : 'Quilometragem anterior salva. Confira o painel para atualizar.' : 'Informe a quilometragem para acompanhar os próximos cuidados.'}</small>
      </div>
      <div className="next-review-copy">
        <span>Próxima revisão {next.due ? 'sem registro' : 'do plano'}</span>
        <strong>{formatKm(next.km!)} <small>km</small><i />ou {next.date ? displayDate(next.date) : `${next.km === 1000 ? 6 : next.km! / 1000 + 6} meses`}</strong>
        <small className={`review-distance ${distance.tone}`} title={distance.detail}>{state.profile.configured ? distance.label : 'O que ocorrer primeiro.'}</small>
      </div>
      <button className={`button ${state.profile.configured ? 'secondary' : 'primary'}`} onClick={onMileage}><Icon name={state.profile.configured ? 'edit' : 'gauge'} size={15} />{state.profile.configured ? 'Atualizar km' : 'Informar km'}</button>
      {onTrip && <button className="button primary" onClick={onTrip}><Icon name="route" size={15} />{tripActive ? 'Ver viagem em andamento' : 'Vou andar de moto'}</button>}
    </div>
    <div className="source-status"><Icon name="file" size={13} /><span>{state.profile.year === 'START-2022' ? 'Manutenção baseada no Manual Honda CG 160 Start (2022), D2203-MAN-1261, Tabela de Manutenção, páginas impressas 32 a 35; as marcações por coluna ainda não foram conferidas na tabela.' : state.profile.year === 'START-2015' ? 'Manutenção baseada no Manual Honda CG150 Start (2015), Tabela de Manutenção, páginas impressas 34 a 37; as marcações por coluna ainda não foram conferidas na tabela.' : state.profile.year === 'START-2026' ? 'Especificações consultadas na Honda 2026; manutenção baseada na última referência específica de Start encontrada.' : state.profile.year === 'CARGO-2013' ? 'Cargo 2013: manual próprio não encontrado; manutenção baseada no Manual Honda CG150 Fan Cargo ESDi (2014), a edição mais próxima. Confira o manual da sua moto.' : state.profile.year === 'CARGO-2014' ? 'Manutenção baseada no Manual Honda CG150 Fan Cargo ESDi (2014), Plano de Manutenção Preventiva, páginas 6-1 a 6-3, conferido na tabela do manual.' : state.profile.year === 'CARGO-2015' ? 'Manutenção baseada no Manual Honda CG150 Cargo ESD (2015), Tabela de Manutenção, páginas impressas 35 a 38, conferida na tabela do manual.' : state.profile.year === 'CARGO-2016' ? 'Manutenção conferida no Manual Honda CG 160 Cargo ESDi 2016 (D2203-MAN-1026), páginas impressas 34 a 37.' : state.profile.year === 'CARGO-2017' ? 'Manutenção baseada no Manual Honda CG 160 Cargo ESDi 2016 (D2203-MAN-1026), a edição mais próxima encontrada para 2017; confira no manual impresso da sua moto.' : state.profile.year === 'CARGO-2018' ? 'Manutenção conferida no Manual Honda CG 160 Cargo 2018 (D2203-MAN-1129), páginas impressas 35 a 38.' : state.profile.year === 'CARGO-2019' ? 'Manutenção conferida no Manual Honda CG 160 Cargo 2019 (D2203-MAN-1187), páginas impressas 37 a 40.' : state.profile.year === 'CARGO-2020' ? 'Manutenção baseada no Manual Honda CG 160 Cargo 2019 (D2203-MAN-1187), a edição mais próxima encontrada para 2020; confira no manual impresso da sua moto.' : state.profile.year === 'CARGO-2021' || state.profile.year === 'CARGO-2022' ? 'Manutenção baseada no Manual Honda CG 160 Cargo 2019~2020 (D2203-MAN-1187), a edição de Cargo mais próxima encontrada; confira no manual impresso da sua moto.' : state.profile.year === 'CARGO-2023' || state.profile.year === 'CARGO-2024' ? 'Manutenção baseada no Manual Honda CG 160 Cargo 2023~2024 (D2203-MAN-1305); confira a tabela no PDF original.' : state.profile.year === 'CARGO-2025' ? 'Especificações consultadas na comunicação oficial Honda da CG 160 2025; manutenção usa a referência oficial da família Cargo localizada.' : state.profile.year === 'CARGO-2026' ? 'Especificações do modelo consultadas na Honda 2026; manutenção baseada na tabela Honda mais recente localizada para a Cargo.' : state.profile.year === '2025/2026' ? 'Prazos consultados no manual. Algumas marcações da tabela ainda precisam ser conferidas.' : state.profile.year === 'TITAN-2026' ? 'Especificações do modelo consultadas na Honda 2026; manutenção baseada na referência oficial da 10ª geração.' : 'Prazos do manual da base técnica anterior incorporados ao plano.'}</span><button onClick={onSource}>Ver avisos<Icon name="external" size={11} /></button></div>
  </>;
}
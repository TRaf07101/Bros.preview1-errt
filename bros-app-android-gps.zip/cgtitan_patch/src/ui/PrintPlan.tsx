import { memo } from 'react';
import { ACTIONS, CONDITIONS, DAILY_CHECKLIST, OFFROAD_CHECKLIST, SAFETY_ALERTS, SEVERE_USE, SOURCE_LIMIT, sourceScopeForYear, getModelServices } from '../maintenance/data';
import { LANGUAGE_NOTE, MANUAL_TERMS } from '../maintenance/language';
import { chainStepKm, formatKm, manualUrl, milestones, timeRows } from '../maintenance/planner';
import { colorLabel } from '../maintenance/models';
import { modelLabel } from '../maintenance/planner';
import type { Profile } from '../maintenance/types';

function PrintPlanContent({ profile }: { profile: Profile }) {
  const printPage = (page: string) => page;
  const nxrPages = profile.year === '2025/2026' || profile.year === 'NXR-2025' || profile.year === 'NXR-2026';
  const cycle4000 = profile.year === '2013' || profile.year === '2014' || profile.year === 'FAN-2013' || profile.year === 'FAN-2014' || profile.year === 'CARGO-2013' || profile.year === 'CARGO-2014' || profile.year === 'CARGO-2015' || profile.year === 'START-2015';
  return <div className="print-document">
    <h1>Plano de cuidados com a moto</h1>
    <h2>{modelLabel(profile.year)} · {profile.variant} · {colorLabel(profile.color)}</h2>
    <p>{sourceScopeForYear(profile.year)}</p><p>{LANGUAGE_NOTE}</p>
    <p className="print-warning"><strong>O que ainda precisa ser conferido:</strong> {SOURCE_LIMIT}</p>
    <p>Faça a revisão quando chegar a quilometragem OU o prazo em meses desde a entrega, o que ocorrer primeiro. Se o serviço já foi feito pela quilometragem, não repita apenas porque chegou o mês correspondente. Conte os prazos do óleo e do líquido de freio desde a última troca real.</p>
    <p>Manual consultado: {manualUrl(profile.year)}. Os números abaixo são das páginas impressas, exceto o certificado, que está nas páginas 7–8 do arquivo.</p>
    <h2>Etapas do calendário</h2>
    {milestones(36000, true, profile.year, profile.variant).map(milestone => <section key={milestone.km} className="print-milestone">
      <h3>{formatKm(milestone.km)} km{milestone.months ? ` / ${milestone.months} meses (o que ocorrer primeiro)` : ''}</h3>
      <p>{milestone.subtitle}</p>{milestone.notice && <p><strong>Atenção:</strong> {milestone.notice}</p>}
      {milestone.services.map(service => <div className="print-service" key={service.id}>
        <h4>{service.component} | {service.service}</h4>
        {service.manualName && <p><strong>Nome no manual:</strong> {service.manualName}</p>}
        <p><strong>Tipo de cuidado:</strong> {service.actions.map(action => ACTIONS[action].label).join(' / ')}. <strong>Quando:</strong> {service.frequency}.</p>
        <p><strong>O que fazer:</strong> {service.description}</p>
        <p><strong>Por que fazer:</strong> {service.reason}</p>
        <p><strong>Quando fazer antes do prazo:</strong> {service.anticipation}</p>
        <p><strong>O que o manual diz:</strong> {service.notes}</p>
        <p><strong>Páginas:</strong> {service.refs.map(reference => reference.page === 'Certificado' ? `Certificado, página ${reference.viewer} do arquivo` : `p. ${printPage(reference.page)}`).join(', ')}.</p>
      </div>)}
    </section>)}
    <h2>Depois de 36.000 km</h2>
    {cycle4000
      ? <p>Os intervalos se repetem a cada 4.000 km. Próximas revisões: 40.000 km, 44.000 km, 48.000 km, 52.000 km, 56.000 km e 60.000 km, sempre o que ocorrer primeiro. Continue os serviços de 4.000, 8.000, 12.000 e 16.000 km conforme a tabela. Corrente a cada 1.000 km; pneus a cada 1.000 km ou uma vez por semana. Os prazos do óleo e do líquido de freio continuam valendo.</p>
      : <p>{nxrPages ? 'A nota 2 da página 46 manda repetir' : 'A tabela do manual repete'} os intervalos. Próximas revisões: 42.000 km / 48 meses; 48.000 km / 54 meses; 54.000 km / 60 meses; 60.000 km / 66 meses; 66.000 km / 72 meses; 72.000 km / 78 meses. Sempre o que ocorrer primeiro. Continue os serviços a cada 12.000 ou 18.000 km conforme o intervalo de cada um, além dos cuidados a cada 6.000 km. Corrente a cada {chainStepKm(profile.year) === 500 ? '500' : '1.000'} km; pneus a cada 1.000 km ou uma vez por semana. Os prazos do óleo e do líquido de freio continuam valendo.</p>}
    <h2>Cuidados por data</h2>
    <p>Óleo: no máximo um ano ou o intervalo da tabela, o que ocorrer primeiro. Líquido de freio: dois anos. As datas abaixo são contadas desde a entrega apenas como referência. Se houve uma troca anterior, conte o prazo do produto desde a troca real. As revisões continuam por km ou por tempo.</p>
    <table><thead><tr><th>Meses desde a entrega</th><th>Revisão</th><th>Óleo do motor</th><th>Líquido de freio</th></tr></thead><tbody>{timeRows(72, profile.year).map(row => <tr key={row.months}><td>{row.months} meses</td><td>{formatKm(row.km)} km ou {row.months} meses</td><td>{row.oil ? 'Limite de um ano. Confira a última troca e os serviços da revisão.' : row.months === 6 ? 'Conferir a coluna de 1.000 km no original.' : 'Conforme a revisão; não há prazo separado de seis meses.'}</td><td>{row.brake ? 'Prazo de dois anos. Troque se completou 24 meses da última troca.' : 'Conferir nível, sem troca automática só por chegar a este mês.'}</td></tr>)}</tbody></table>
    <p>Moto guardada por muito tempo: retirar a bateria e carregá-la uma vez por mês, {nxrPages ? 'conforme página 91' : 'conforme o manual'}. Não significa trocar a bateria todo mês nem criar uma revisão mensal para a moto em uso.</p>
    <h2>Cuidados por desgaste ou defeito</h2>
    {CONDITIONS.map(item => <section key={item.id}><h3>{item.title}</h3><p><strong>Sinal para cuidar antes:</strong> {item.trigger}</p><p><strong>O que fazer:</strong> {item.action}</p><p>Páginas do manual: {item.refs.map(r => r.page).join(', ')}.</p></section>)}
    <h2>Uso intenso: quando a moto exige mais cuidado</h2>
    <p>No manual, uso severo. Não há um prazo menor que sirva para todas as situações. Peça à concessionária uma frequência adequada ao seu uso, {nxrPages ? 'conforme página 44' : 'conforme o manual'}.</p>
    {SEVERE_USE.map(item => <section key={item.id}><h3>{item.title}</h3><p>{item.text} {item.action}</p><p>Páginas do manual: {item.refs.map(r => r.page).join(', ')}.</p></section>)}
    <h2>O que verificar antes de pilotar</h2>
    <ul>{DAILY_CHECKLIST.map(item => <li key={item.id}><strong>{item.title}:</strong> {item.text}</li>)}</ul><p>{nxrPages ? 'Manual: páginas 48 e 49.' : 'Veja o manual do seu modelo.'}</p>
    <h3>Cuidados extras antes de sair do asfalto</h3>
    <ul>{OFFROAD_CHECKLIST.map(item => <li key={item.id}><strong>{item.title}:</strong> {item.text}</li>)}</ul>
    <h2>Alertas de segurança</h2>
    {SAFETY_ALERTS.map(item => <section key={item.id}><h3>{item.title}</h3><p><strong>{item.level === 'stop' ? 'Não continue até corrigir ou verificar.' : 'Siga a orientação do manual para este caso.'}</strong> {item.text}</p><p>Páginas do manual: {item.refs.map(r => r.page).join(', ')}.</p></section>)}
    <h2>Tabela completa</h2>
    <table><thead><tr><th>Item</th><th>Quando fazer</th><th>Prazo por tempo</th><th>Ação</th><th>Fazer antes do prazo?</th><th>Quando trocar</th></tr></thead><tbody>{getModelServices(profile.year, profile.variant).map(item => <tr key={item.id}><td>{item.component}{item.manualName ? ` (no manual: ${item.manualName})` : ''}: {item.service}</td><td>{item.frequency}</td><td>{item.timeMonths ? `${item.timeMonths} meses` : 'Sem prazo próprio em meses; conferir a revisão dessa etapa'}</td><td>{item.actions.map(action => ACTIONS[action].label).join(', ')}</td><td>{item.anticipation}</td><td>{item.replacement}</td></tr>)}</tbody></table>
    <p><strong>MANUTENÇÃO PROGRAMADA:</strong> fazer o cuidado indicado no intervalo. Pode ser só verificar. <strong>CONSERTO POR DESGASTE OU DEFEITO:</strong> consertar ou trocar quando o estado da peça ou a avaliação mostrar necessidade.</p>
    <h2>Palavras do manual, sem complicação</h2>
    {MANUAL_TERMS.map(item => <p key={item.term}><strong>{item.simple}</strong> (no manual: {item.term}): {item.explanation}</p>)}
    <p>Guia independente, sem vínculo com a Honda. Não incluímos preços. Confira no PDF original as marcações da tabela que ainda faltam.</p>
  </div>;
}

export const PrintPlan = memo(PrintPlanContent);
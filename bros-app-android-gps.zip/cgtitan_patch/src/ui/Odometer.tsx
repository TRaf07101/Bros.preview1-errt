import { useState } from 'react';
import type { FormEvent } from 'react';
import { highestServiceMileage, isMileage, latestMileageReading, MAX_MILEAGE, MAX_MILEAGE_READINGS, MILEAGE_SOURCES, mileageChangeError, mileageCsv, mileageDistance, mileageTimestamp, parseMileage } from '../maintenance/odometer';
import { displayDate, downloadText, formatKm, reminderList } from '../maintenance/planner';
import type { MileageUpdate, StoredState } from '../maintenance/types';
import { Notice } from './Common';
import { Icon } from './Icon';

export function MileageCorrection({ state, km, confirmed, note, onConfirm, onNote, onHistory }: {
  state: StoredState;
  km: number | null;
  confirmed: boolean;
  note: string;
  onConfirm: (value: boolean) => void;
  onNote: (value: string) => void;
  onHistory?: () => void;
}) {
  if (km === null) return null;
  const serviceKm = highestServiceMileage(state.records);
  if (km < serviceKm) return <Notice tone="warning" title="Já existe um serviço com mais quilômetros.">
    Há um serviço registrado com {formatKm(serviceKm)} km. Se essa informação estiver errada, corrija o registro do serviço antes de colocar um valor menor aqui. Os registros anteriores não mudam sozinhos.
    {onHistory && <button type="button" className="text-button" onClick={onHistory}>Conferir histórico de cuidados<Icon name="arrow" size={14} /></button>}
  </Notice>;
  if (!state.profile.configured || km >= state.profile.km) return null;
  return <div className="mileage-correction">
    <Notice tone="warning" title="A quilometragem total normalmente não diminui.">
      O valor salvo é {formatKm(state.profile.km)} km. Use esta opção apenas para corrigir um número digitado errado. Não use só os quilômetros da última viagem e não zere o total rodado ao trocar o painel.
    </Notice>
    <label className="confirmation-check"><input type="checkbox" checked={confirmed} onChange={event => onConfirm(event.target.checked)} required /><span>O número anterior estava errado. Sei que ele continuará no histórico.</span></label>
    <label className="form-label">Por que está corrigindo?<textarea rows={2} required minLength={3} maxLength={500} value={note} onChange={event => onNote(event.target.value)} placeholder="Ex.: digitei um zero a mais no número anterior." /></label>
  </div>;
}

export function MileageSummary({ state, onReminders }: { state: StoredState; onReminders: () => void }) {
  const reminders = reminderList(state).filter(item => item.km !== null);
  return <section className="mileage-care-summary" aria-labelledby="mileage-care-title">
    <header><div><span className="eyebrow">COM A QUILOMETRAGEM SALVA</span><h3 id="mileage-care-title">Quanto falta para cuidar?</h3></div><button type="button" className="text-button" onClick={onReminders}>Todos os lembretes<Icon name="arrow" size={14} /></button></header>
    {reminders.map(reminder => {
      const distance = mileageDistance(state.profile, reminder);
      return <div className={`mileage-care-row ${distance.tone}`} key={reminder.id}>
        <span className="mileage-care-icon"><Icon name={reminder.kind === 'review' ? 'wrench' : reminder.kind === 'chain' ? 'chain' : 'circle'} size={17} /></span>
        <div><h4>{reminder.title}</h4><strong>{distance.label}</strong><p>{distance.detail}</p>{reminder.date && <small>Data de referência: {displayDate(reminder.date)}. O que ocorrer primeiro.</small>}</div>
      </div>;
    })}
    <p className="mileage-safety-note"><Icon name="info" size={14} />Atualizar km não marca revisão como feita e não muda os prazos de troca do óleo ou do líquido de freio.</p>
  </section>;
}

export function OdometerPanel({ state, onSave, onClose, onProfile, onHistory, onReminders }: {
  state: StoredState;
  onSave: (update: MileageUpdate) => string | null;
  onClose: () => void;
  onProfile: () => void;
  onHistory: () => void;
  onReminders: () => void;
}) {
  const [mode, setMode] = useState<MileageUpdate['mode']>('reading');
  const [input, setInput] = useState(state.profile.configured ? formatKm(state.profile.km) : '');
  const [note, setNote] = useState('');
  const [confirmed, setConfirmed] = useState(false);
  const [error, setError] = useState('');
  const [showAll, setShowAll] = useState(false);
  const previous = latestMileageReading(state);
  const parsed = parseMileage(input);
  const proposed = parsed === null ? null : mode === 'trip' ? state.profile.km + parsed : parsed;
  const nextKm = isMileage(proposed) ? proposed : null;
  const lowering = nextKm !== null && state.profile.configured && nextKm < state.profile.km;
  const difference = nextKm !== null && state.profile.configured ? nextKm - state.profile.km : null;
  const entries = showAll ? state.mileageReadings : state.mileageReadings.slice(-6);
  const changeMode = (next: MileageUpdate['mode']) => {
    setMode(next); setInput(next === 'reading' && state.profile.configured ? formatKm(state.profile.km) : ''); setConfirmed(false); setError('');
  };
  const submit = (event: FormEvent) => {
    event.preventDefault();
    if (mode === 'trip' && !state.profile.configured) { setError('Primeiro informe a quilometragem total da moto.'); return; }
    if (mode === 'trip' && parsed === 0) { setError('Informe mais de zero quilômetros rodados ou escolha Informar quilometragem.'); return; }
    if (proposed !== null && proposed > MAX_MILEAGE) { setError('A soma ultrapassa o limite de 999.999 km. Confira os valores informados.'); return; }
    const validation = mileageChangeError(state, nextKm, confirmed, note);
    if (validation) { setError(validation); return; }
    const result = onSave({ km: nextKm!, mode, note, correctionConfirmed: confirmed });
    if (result) setError(result);
  };
  return <div className="odometer-panel">
    <div className="saved-mileage">
      <span className="saved-mileage-icon"><Icon name="gauge" size={31} strokeWidth={1.5} /></span>
      <div><span className="eyebrow">ÚLTIMA QUILOMETRAGEM INFORMADA</span><strong>{state.profile.configured ? formatKm(state.profile.km) : '--'}<small>km</small></strong><p>{state.profile.configured ? previous?.createdAt ? `Registrada em ${mileageTimestamp(previous.createdAt)}` : 'Quilometragem anterior mantida. A data não foi informada.' : 'Sua quilometragem ainda não foi cadastrada.'}</p></div>
    </div>
    <p className="mileage-manual-note"><Icon name={state.tracker.linkedAt ? 'route' : 'edit'} size={14} />{state.tracker.linkedAt ? 'O rastreador conectado soma as viagens automaticamente. Informe o valor do painel só para corrigir.' : 'Você digita os quilômetros. O bros. não lê o painel da moto. Para atualizar sozinho, conecte um rastreador em Configurações e dados.'}</p>
    <form className="odometer-form" onSubmit={submit}>
      <div className="segmented mileage-mode" role="group" aria-label="Como atualizar a quilometragem">
        <button type="button" className={mode === 'reading' ? 'active' : ''} aria-pressed={mode === 'reading'} onClick={() => changeMode('reading')}><Icon name="gauge" size={15} />Informar quilometragem</button>
        <button type="button" className={mode === 'trip' ? 'active' : ''} aria-pressed={mode === 'trip'} disabled={!state.profile.configured} title={!state.profile.configured ? 'Primeiro informe a quilometragem total.' : 'Somar os quilômetros de uma viagem que você já fez.'} onClick={() => changeMode('trip')}><Icon name="plus" size={15} />Somar km rodados</button>
      </div>
      <label className="form-label mileage-input-label" htmlFor="odometer-km">{mode === 'reading' ? 'Qual é a quilometragem total no painel?' : 'Quantos quilômetros você percorreu?'}<span className="mileage-input-wrap"><input id="odometer-km" type="text" inputMode="numeric" autoComplete="off" maxLength={12} required value={input} placeholder={mode === 'reading' ? 'Ex.: 5.200' : 'Ex.: 35'} aria-describedby="odometer-input-help odometer-error" aria-invalid={error ? true : undefined} onChange={event => { setInput(event.target.value); setConfirmed(false); setError(''); }} onBlur={() => { const value = parseMileage(input); if (value !== null) setInput(formatKm(value)); }} /><span>km</span></span></label>
      <p className="mileage-input-help" id="odometer-input-help">{mode === 'reading' ? 'Use o total de quilômetros que a moto já rodou, indicado como ODO no painel. TRIP mostra só uma viagem. Aceita 5200 ou 5.200, sem casas decimais.' : 'Some apenas quilômetros de uma viagem já feita e que ainda não entrou no total. Confira o resultado com a quilometragem total do painel.'}</p>
      {nextKm !== null && <div className={`mileage-preview ${lowering ? 'correction' : ''}`} aria-live="polite"><span>{mode === 'trip' ? `${formatKm(state.profile.km)} + ${formatKm(parsed!)} km` : lowering ? 'Valor corrigido' : 'Quilometragem que será salva'}</span><strong>{formatKm(nextKm)} <small>km</small></strong>{difference !== null && <small>{difference < 0 ? 'É uma correção, não quilômetros rodados' : difference === 0 ? 'Mesmo valor, com novo horário' : `+${formatKm(difference)} km desde o registro anterior`}</small>}</div>}
      <MileageCorrection state={state} km={nextKm} confirmed={confirmed} note={note} onConfirm={setConfirmed} onNote={setNote} onHistory={onHistory} />
      {!lowering && <label className="form-label">Observação <span className="optional">opcional</span><input value={note} onChange={event => setNote(event.target.value)} maxLength={500} placeholder="Ex.: conferi o painel depois de abastecer." /></label>}
      <p id="odometer-error" className={error ? 'form-error' : 'odometer-error-placeholder'} role={error ? 'alert' : undefined}>{error}</p>
      <footer className="form-actions"><button type="button" className="button secondary" onClick={onClose}>Cancelar</button><button type="submit" className="button primary"><Icon name="check" size={16} />Salvar quilometragem</button></footer>
    </form>
    <MileageSummary state={state} onReminders={onReminders} />
    <section className="mileage-log" aria-labelledby="mileage-log-heading">
      <header><div><span className="eyebrow">SEU CAMINHO REGISTRADO</span><h3 id="mileage-log-heading">Histórico de quilometragem</h3></div>{state.mileageReadings.length > 0 && <button type="button" className="text-button" title="Baixar arquivo CSV para abrir em uma planilha" onClick={() => downloadText(mileageCsv(state.mileageReadings), 'quilometragem-bros.csv', 'text/csv;charset=utf-8')}><Icon name="download" size={14} />Baixar planilha</button>}</header>
      {entries.length === 0 ? <p className="mileage-log-empty">Sua primeira quilometragem salva aparecerá aqui. Esse histórico é separado dos serviços de manutenção.</p> : <ol>{entries.map(item => {
        const delta = item.previousKm === null ? null : item.km - item.previousKm;
        return <li key={item.id} className={delta !== null && delta < 0 ? 'corrected' : ''}><div><time dateTime={item.createdAt || undefined}>{mileageTimestamp(item.createdAt)}</time><strong>{formatKm(item.km)} <small>km</small></strong></div><div><span>{delta !== null && delta < 0 ? 'Quilometragem corrigida' : MILEAGE_SOURCES[item.source]}</span><small>{delta === null ? 'Primeiro valor informado' : delta < 0 ? `Anterior: ${formatKm(item.previousKm!)} km` : delta === 0 ? 'Mesma quilometragem' : `+${formatKm(delta)} km entre registros`}</small></div>{item.note && <p>{item.note}</p>}</li>;
      })}</ol>}
      {state.mileageReadings.length > 6 && <button type="button" className="text-button mileage-log-more" onClick={() => setShowAll(!showAll)}>{showAll ? 'Mostrar apenas os 6 últimos' : `Ver os ${state.mileageReadings.length} registros`}<Icon name={showAll ? 'chevron-down' : 'plus'} size={14} /></button>}
      <p className="mileage-log-note">Os últimos {MAX_MILEAGE_READINGS} registros ficam salvos neste navegador, na ordem em que foram feitos. Uma correção não conta como quilômetros rodados. Baixe a planilha para guardar uma cópia.</p>
    </section>
    <button type="button" className="mileage-profile-link" onClick={onProfile}><Icon name="settings" size={16} /><span>Ajustar ano, versão e datas da moto</span><Icon name="chevron" size={15} /></button>
  </div>;
}
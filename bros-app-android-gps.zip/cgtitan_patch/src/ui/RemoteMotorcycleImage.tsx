import { useEffect, useRef, useState } from 'react';

type Props = {
  source: string;
  alt: string;
  onReady: () => void;
  onError: () => void;
};

const CANVAS_W = 1536;
const CANVAS_H = 1024;
const TARGET_BIKE_H = 920;
const MAX_BIKE_W = 1420;

function colorDistance(a: [number, number, number], b: [number, number, number]) {
  return Math.hypot(a[0] - b[0], a[1] - b[1], a[2] - b[2]);
}

function isNearBackground(r: number, g: number, b: number, palette: Array<[number, number, number]>) {
  const luma = 0.2126 * r + 0.7152 * g + 0.0722 * b;
  const max = Math.max(r, g, b);
  const min = Math.min(r, g, b);
  const saturation = max - min;
  if (luma > 218 && saturation < 42) return true;
  const pixel: [number, number, number] = [r, g, b];
  return palette.some((bg) => colorDistance(pixel, bg) < 62);
}

function sampleBackgroundPalette(data: Uint8ClampedArray, width: number, height: number): Array<[number, number, number]> {
  // Cluster colors sampled only from a thin border band. This handles the
  // historical dealer/studio photos that use gray, green/white checkerboard,
  // tiled or warm walls instead of pure white, while still keeping the bike
  // itself out of the background model.
  const samples: Array<[number, number, number]> = [];
  const border = Math.max(2, Math.floor(Math.min(width, height) * 0.025));
  const step = Math.max(3, Math.floor(Math.min(width, height) / 120));
  for (let y = 0; y < border; y += step) {
    for (let x = 0; x < width; x += step) {
      const i = (y * width + x) * 4; samples.push([data[i], data[i + 1], data[i + 2]]);
    }
  }
  for (let y = height - border; y < height; y += step) {
    for (let x = 0; x < width; x += step) {
      const i = (y * width + x) * 4; samples.push([data[i], data[i + 1], data[i + 2]]);
    }
  }
  for (let y = border; y < height - border; y += step) {
    for (const x of [0, width - 1]) {
      const i = (y * width + x) * 4; samples.push([data[i], data[i + 1], data[i + 2]]);
    }
  }

  // Quantize first so repeated wall/floor colors dominate over JPEG noise.
  const bins = new Map<string, { count: number; rgb: [number, number, number] }>();
  for (const rgb of samples) {
    const q: [number, number, number] = [Math.round(rgb[0] / 24) * 24, Math.round(rgb[1] / 24) * 24, Math.round(rgb[2] / 24) * 24];
    const key = q.join(',');
    const found = bins.get(key);
    if (found) found.count++;
    else bins.set(key, { count: 1, rgb: q });
  }
  const palette = [...bins.values()]
    .sort((a, b) => b.count - a.count)
    .slice(0, 8)
    .map(({ rgb }) => rgb);
  if (!palette.length) return [[255, 255, 255]];
  return palette;
}

function assertWhiteStudioBackground(ctx: CanvasRenderingContext2D, width: number, height: number) {
  const image = ctx.getImageData(0, 0, width, height);
  const { data } = image;
  const samples: Array<[number, number]> = [];
  const step = Math.max(8, Math.floor(Math.min(width, height) / 90));
  for (let x = 0; x < width; x += step) { samples.push([x, 2], [x, height - 3]); }
  for (let y = step; y < height - step; y += step) { samples.push([2, y], [width - 3, y]); }
  let white = 0;
  for (const [x, y] of samples) {
    const i = (y * width + x) * 4;
    const r = data[i], g = data[i + 1], b = data[i + 2], a = data[i + 3];
    const luma = 0.2126 * r + 0.7152 * g + 0.0722 * b;
    const sat = Math.max(r, g, b) - Math.min(r, g, b);
    if (a > 0 && luma >= 232 && sat <= 28) white++;
  }
  const n = Math.max(1, samples.length);
  const ratio = white / n;
  const transparentRatio = samples.reduce((count, [x, y]) => {
    const i = (y * width + x) * 4;
    return count + (data[i + 3] === 0 ? 1 : 0);
  }, 0) / n;
  // Clean product cutouts and historical photographs are both valid sources.
  // Background quality is decided by the adaptive edge segmentation below;
  // do not reject a usable photo merely because its source background is gray,
  // green, warm, tiled or otherwise non-white.
  if (transparentRatio >= 0.40 || ratio >= 0.40) return;
}

function removeEdgeBackground(ctx: CanvasRenderingContext2D, width: number, height: number): ImageData {
  const image = ctx.getImageData(0, 0, width, height);
  const { data } = image;
  const palette = sampleBackgroundPalette(data, width, height);
  const visited = new Uint8Array(width * height);
  const queue = new Int32Array(width * height);
  let head = 0;
  let tail = 0;

  const enqueueIfBackground = (x: number, y: number) => {
    if (x < 0 || y < 0 || x >= width || y >= height) return;
    const p = y * width + x;
    if (visited[p]) return;
    visited[p] = 1;
    const i = p * 4;
    if (data[i + 3] !== 0 && isNearBackground(data[i], data[i + 1], data[i + 2], palette)) queue[tail++] = p;
  };

  for (let x = 0; x < width; x++) { enqueueIfBackground(x, 0); enqueueIfBackground(x, height - 1); }
  for (let y = 1; y < height - 1; y++) { enqueueIfBackground(0, y); enqueueIfBackground(width - 1, y); }

  while (head < tail) {
    const p = queue[head++];
    const i = p * 4;
    data[i + 3] = 0;
    const x = p % width;
    const y = Math.floor(p / width);
    enqueueIfBackground(x - 1, y);
    enqueueIfBackground(x + 1, y);
    enqueueIfBackground(x, y - 1);
    enqueueIfBackground(x, y + 1);
  }

  const mask = new Uint8Array(width * height);
  for (let p = 0; p < width * height; p++) if (data[p * 4 + 3] > 18) mask[p] = 1;
  const seen = new Uint8Array(width * height);
  const compQueue = new Int32Array(width * height);
  const components: Array<{ area: number; minX: number; minY: number; maxX: number; maxY: number; pixels: number[] }> = [];
  const neighbors = [-1, 1, -width, width];
  for (let seed = 0; seed < mask.length; seed++) {
    if (!mask[seed] || seen[seed]) continue;
    let qh = 0, qt = 0;
    compQueue[qt++] = seed; seen[seed] = 1;
    const pixels: number[] = [];
    let minX = width, minY = height, maxX = -1, maxY = -1;
    while (qh < qt) {
      const p = compQueue[qh++]; pixels.push(p);
      const x = p % width, y = Math.floor(p / width);
      if (x < minX) minX = x; if (x > maxX) maxX = x; if (y < minY) minY = y; if (y > maxY) maxY = y;
      for (const d of neighbors) {
        const np = p + d;
        if (np < 0 || np >= mask.length) continue;
        if (d === -1 && x === 0) continue;
        if (d === 1 && x === width - 1) continue;
        if (mask[np] && !seen[np]) { seen[np] = 1; compQueue[qt++] = np; }
      }
    }
    components.push({ area: pixels.length, minX, minY, maxX, maxY, pixels });
  }
  components.sort((a, b) => b.area - a.area);
  const main = components[0];
  if (!main || main.area < 900) throw new Error('Objeto principal não detectado');
  const keep = new Uint8Array(width * height);
  for (const p of main.pixels) keep[p] = 1;
  for (const c of components.slice(1, 12)) {
    if (c.area < 45) continue;
    const gapX = Math.max(main.minX - c.maxX, c.minX - main.maxX, 0);
    const gapY = Math.max(main.minY - c.maxY, c.minY - main.maxY, 0);
    if (gapX <= 55 && gapY <= 55) for (const p of c.pixels) keep[p] = 1;
  }
  for (let p = 0; p < mask.length; p++) if (!keep[p]) data[p * 4 + 3] = 0;

  return image;
}

function cropUniformFraming(ctx: CanvasRenderingContext2D, width: number, height: number) {
  // Some press photos contain black pillar/letterbox strips around an otherwise
  // white product shot. Remove only those uniform dark strips before the studio
  // background gate, otherwise a perfectly usable product photo is rejected.
  const image = ctx.getImageData(0, 0, width, height);
  const { data } = image;
  const rowMean = (y: number) => {
    let sum = 0;
    for (let x = 0; x < width; x += Math.max(1, Math.floor(width / 120))) {
      const i = (y * width + x) * 4;
      sum += 0.2126 * data[i] + 0.7152 * data[i + 1] + 0.0722 * data[i + 2];
    }
    return sum / Math.ceil(width / Math.max(1, Math.floor(width / 120)));
  };
  const colMean = (x: number) => {
    let sum = 0;
    const step = Math.max(1, Math.floor(height / 120));
    let count = 0;
    for (let y = 0; y < height; y += step) {
      const i = (y * width + x) * 4;
      sum += 0.2126 * data[i] + 0.7152 * data[i + 1] + 0.0722 * data[i + 2];
      count++;
    }
    return sum / count;
  };

  let left = 0, right = width - 1, top = 0, bottom = height - 1;
  const darkLimit = 42;
  while (left < width * 0.12 && colMean(left) < darkLimit) left++;
  while (right > width * 0.88 && colMean(right) < darkLimit) right--;
  while (top < height * 0.10 && rowMean(top) < darkLimit) top++;
  while (bottom > height * 0.90 && rowMean(bottom) < darkLimit) bottom--;

  if (left === 0 && right === width - 1 && top === 0 && bottom === height - 1) return;
  const cw = right - left + 1;
  const ch = bottom - top + 1;
  if (cw < width * 0.75 || ch < height * 0.75) return;
  const cropped = document.createElement('canvas');
  cropped.width = cw; cropped.height = ch;
  const cctx = cropped.getContext('2d', { willReadFrequently: true });
  if (!cctx) return;
  cctx.drawImage(ctx.canvas, left, top, cw, ch, 0, 0, cw, ch);
  ctx.canvas.width = cw;
  ctx.canvas.height = ch;
  ctx.drawImage(cropped, 0, 0);
}

function neutralizeDarkColorCast(image: ImageData) {
  // Product photos sometimes have a warm cast that makes neutral black plastics
  // look brown/red after web compression. Only neutral-looking dark pixels are
  // corrected; saturated brand colors remain untouched.
  const { data } = image;
  for (let i = 0; i < data.length; i += 4) {
    const r = data[i], g = data[i + 1], b = data[i + 2];
    const max = Math.max(r, g, b), min = Math.min(r, g, b);
    const sat = max - min;
    const luma = 0.2126 * r + 0.7152 * g + 0.0722 * b;
    if (luma < 100 && sat < 95 && r > b + 12 && r > g + 7) {
      const neutral = Math.round(luma);
      data[i] = neutral; data[i + 1] = neutral; data[i + 2] = neutral;
    }
  }
}

function makeTransparentStandardImage(img: HTMLImageElement): string {
  const sourceW = img.naturalWidth || img.width;
  const sourceH = img.naturalHeight || img.height;
  if (!sourceW || !sourceH) throw new Error('Imagem sem dimensões');

  // Validate/cut the original image before adding the transparent 1536x1024
  // padding. Testing after padding was a real bug: the transparent margin was
  // counted as non-white and valid product photos fell into the SVG fallback.
  const maxSource = 2200;
  const sourceScale = Math.min(1, maxSource / Math.max(sourceW, sourceH));
  const workW = Math.max(1, Math.round(sourceW * sourceScale));
  const workH = Math.max(1, Math.round(sourceH * sourceScale));
  const work = document.createElement('canvas');
  work.width = workW;
  work.height = workH;
  const ctx = work.getContext('2d', { willReadFrequently: true });
  if (!ctx) throw new Error('Canvas indisponível');
  ctx.clearRect(0, 0, workW, workH);
  ctx.drawImage(img, 0, 0, workW, workH);
  cropUniformFraming(ctx, workW, workH);
  const croppedW = ctx.canvas.width;
  const croppedH = ctx.canvas.height;
  assertWhiteStudioBackground(ctx, croppedW, croppedH);

  const processed = removeEdgeBackground(ctx, croppedW, croppedH);
  neutralizeDarkColorCast(processed);
  ctx.putImageData(processed, 0, 0);

  const pixels = processed.data;
  // cropUniformFraming() may resize ctx.canvas, so all subsequent pixel
  // coordinates must use the cropped dimensions rather than the old workW/H.
  // Using the pre-crop stride here made valid historical photos fail silhouette
  // detection and could cascade into the "Foto indisponível" state.
  let minX = croppedW, minY = croppedH, maxX = -1, maxY = -1;
  for (let y = 0; y < croppedH; y++) {
    for (let x = 0; x < croppedW; x++) {
      const a = pixels[(y * croppedW + x) * 4 + 3];
      if (a > 10) {
        if (x < minX) minX = x;
        if (y < minY) minY = y;
        if (x > maxX) maxX = x;
        if (y > maxY) maxY = y;
      }
    }
  }
  if (maxX < 0) throw new Error('Nenhum objeto detectado');

  const bw = maxX - minX + 1;
  const bh = maxY - minY + 1;
  const finalScale = Math.min(TARGET_BIKE_H / bh, MAX_BIKE_W / bw);
  const fw = bw * finalScale;
  const fh = bh * finalScale;

  const finalCanvas = document.createElement('canvas');
  finalCanvas.width = CANVAS_W;
  finalCanvas.height = CANVAS_H;
  const finalCtx = finalCanvas.getContext('2d');
  if (!finalCtx) throw new Error('Canvas final indisponível');
  finalCtx.clearRect(0, 0, CANVAS_W, CANVAS_H);
  finalCtx.imageSmoothingEnabled = true;
  finalCtx.imageSmoothingQuality = 'high';
  // Keep a deliberate safety margin below the tires. Some source photos have
  // their lower silhouette extremely close to the crop edge.
  const x = (CANVAS_W - fw) / 2;
  const y = Math.max(22, (CANVAS_H - fh) / 2 - 24);
  finalCtx.drawImage(work, minX, minY, bw, bh, x, y, fw, fh);
  return finalCanvas.toDataURL('image/webp', .94);
}

export function RemoteMotorcycleImage({ source, alt, onReady, onError }: Props) {
  const [processed, setProcessed] = useState<string | null>(null);
  const [visibleSource, setVisibleSource] = useState(source);
  const candidatesRef = useRef<string[]>([source]);
  const visibleIndexRef = useRef(0);
  const readyRef = useRef(onReady);
  const errorRef = useRef(onError);
  const readyOnce = useRef(false);
  readyRef.current = onReady;
  errorRef.current = onError;

  useEffect(() => {
    let alive = true;
    readyOnce.current = false;
    setProcessed(null);

    const isWeserv = source.startsWith('https://images.weserv.nl/');
    const alternateSource = isWeserv
      ? source.replace('https://images.weserv.nl/', 'https://wsrv.nl/')
      : null;
    let originalSource: string | null = null;
    if (isWeserv) {
      try {
        const original = new URL(source).searchParams.get('url');
        if (original) originalSource = original;
      } catch {
        originalSource = null;
      }
    }

    const candidates = Array.from(new Set(
      [source, alternateSource, originalSource]
        .filter((value): value is string => Boolean(value))
    ));
    candidatesRef.current = candidates;
    visibleIndexRef.current = 0;
    setVisibleSource(candidates[0] ?? source);

    let attempt = 0;
    const processAttempt = () => {
      if (!alive) return;
      const candidate = candidates[attempt];
      if (!candidate) return;
      const img = new Image();
      // Canvas processing needs CORS. The direct-source fallback deliberately
      // does not request CORS because many legitimate image hosts serve an
      // ordinary <img> but omit ACAO headers.
      if (candidate !== originalSource) img.crossOrigin = 'anonymous';
      img.referrerPolicy = 'no-referrer';
      img.decoding = 'async';
      img.onload = () => {
        if (!alive) return;
        try {
          const result = makeTransparentStandardImage(img);
          if (alive) setProcessed(result);
        } catch {
          if (attempt + 1 < candidates.length) {
            attempt += 1;
            processAttempt();
          }
        }
      };
      img.onerror = () => {
        if (attempt + 1 < candidates.length) {
          attempt += 1;
          processAttempt();
        }
      };
      img.src = candidate;
    };

    processAttempt();
    return () => { alive = false; };
  }, [source]);

  const displaySource = processed ?? visibleSource;
  return <img
    key={displaySource}
    className="remote-motorcycle transparent-motorcycle processed-motorcycle loaded"
    src={displaySource}
    alt={alt}
    referrerPolicy="no-referrer"
    onLoad={() => {
      if (!readyOnce.current) {
        readyOnce.current = true;
        readyRef.current();
      }
    }}
    onError={() => {
      if (processed) {
        setProcessed(null);
        return;
      }
      const candidates = candidatesRef.current;
      const next = visibleIndexRef.current + 1;
      if (next < candidates.length) {
        visibleIndexRef.current = next;
        setVisibleSource(candidates[next]);
        return;
      }
      errorRef.current();
    }}
    fetchPriority="high"
  />;
}

import { useEffect, useState } from 'react';
import type { StoredState, MileageUpdate } from '../maintenance/types';
import { formatKm } from '../maintenance/planner';
import { parseMileage } from '../maintenance/odometer';
import { formatKmDecimal } from '../tracker/apply';
import type { TripController } from '../trip/useTrip';
import { Notice } from './Common';
import { Icon } from './Icon';

const clock = (ms: number) => { const s = Math.max(0, Math.floor(ms / 1000)); const h = Math.floor(s / 3600); const m = Math.floor((s % 3600) / 60); return h ? `${h} h ${String(m).padStart(2, '0')} min` : `${m} min ${String(s % 60).padStart(2, '0')} s`; };

export function TripPanel({ state, trip, onSave, onMileage, onClose }: { state: StoredState; trip: TripController; onSave: (update: MileageUpdate) => string | null; onMileage: () => void; onClose: () => void }) {
  const [now, setNow] = useState(Date.now());
  const [text, setText] = useState('');
  const [error, setError] = useState('');
  const { track, finished } = trip;
  useEffect(() => { if (!track) return; const id = setInterval(() => setNow(Date.now()), 1000); return () => clearInterval(id); }, [track]);
  useEffect(() => { if (finished) setText(String(Math.round(finished.meters / 1000))); }, [finished]);

  if (!state.profile.configured) return <div className="tracker-panel"><Notice tone="warning" title="Primeiro informe a quilometragem da moto.">A viagem é somada ao total que já está salvo.</Notice><button className="button primary full-width" onClick={onMileage}>Informar km<Icon name="arrow" size={16} /></button></div>;
  if (!trip.supported) return <div className="tracker-panel"><Notice tone="warning" title="Este navegador não oferece localização.">Abra o app no Chrome (Android) ou Safari (iPhone) e tente de novo.</Notice></div>;

  if (finished) {
    const measured = finished.meters / 1000;
    const parsed = parseMileage(text);
    const save = () => {
      if (parsed === null || parsed < 1) { setError('Informe quantos km foram rodados, em número inteiro (mínimo 1).'); return; }
      const note = `+${formatKmDecimal(measured)} km medidos pelo GPS do celular${parsed !== Math.round(measured) ? `; ajustado por você para ${parsed} km` : ''}. Viagem de ${new Date(finished.startedAt).toLocaleString('pt-BR', { day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit' })}.`;
      const result = onSave({ km: state.profile.km + parsed, mode: 'trip', note, correctionConfirmed: false });
      if (result) setError(result); else trip.clearFinished();
    };
    return <div className="tracker-panel">
      <p className="tracker-lead">Viagem terminada: o GPS mediu <strong>{formatKmDecimal(measured)} km</strong>.</p>
      {finished.gaps > 0 && <Notice tone="warning" title="O GPS ficou sem sinal em alguns momentos.">Nesses trechos o app mede em linha reta, então o valor pode estar abaixo do real. Confira e ajuste abaixo se precisar.</Notice>}
      {measured < 0.5 && <Notice title="Quase nada foi medido.">Se você rodou mais que isso, o GPS pode ter parado. Digite o valor certo abaixo.</Notice>}
      <label className="form-label">Km a somar<input inputMode="numeric" value={text} onChange={event => { setText(event.target.value); setError(''); }} /></label>
      {parsed !== null && parsed > 0 && <dl className="tracker-facts"><div><dt>Quilometragem depois</dt><dd className="tracker-km">{formatKm(state.profile.km + parsed)} <small>km</small></dd></div></dl>}
      {error && <Notice tone="danger">{error}</Notice>}
      <div className="tracker-actions"><button className="text-button" onClick={() => { trip.clearFinished(); onClose(); }}>Descartar viagem</button><button className="button primary" onClick={save}><Icon name="check" size={16} />Somar à quilometragem</button></div>
    </div>;
  }

  if (track) return <div className="tracker-panel">
    <span className={`tracker-state ${trip.weakSignal ? 'failed' : ''}`}><i className={`tracker-dot ${trip.weakSignal ? 'bad' : 'busy'}`} />{trip.weakSignal ? 'Procurando sinal de GPS...' : 'Rastreando a viagem'}</span>
    <p className="trip-distance">{formatKmDecimal(track.meters / 1000)} <small>km</small></p>
    <p className="tracker-note">Há {clock(now - track.startedAt)}. {trip.native ? 'Pode bloquear a tela ou usar outros apps: o rastreio continua, com uma notificação fixa. Só não feche o app deslizando-o para fora da lista de recentes.' : 'A tela fica ligada enquanto o app está aberto. Não feche o app nem troque de aplicativo: o GPS do navegador para quando o app sai da frente.'}</p>
    {track.gaps > 0 && <Notice tone="warning" title="O GPS já ficou sem sinal.">O total pode estar abaixo do real; você poderá ajustar no fim.</Notice>}
    <div className="tracker-actions"><button className="text-button danger" onClick={() => { trip.cancel(); onClose(); }}>Cancelar</button><button className="button primary" onClick={trip.stop}><Icon name="flag" size={16} />Terminar viagem</button></div>
  </div>;

  return <div className="tracker-panel">
    <p className="tracker-lead">Vai sair de moto? Toque em iniciar. Ao voltar, o app já sabe quantos km você rodou.</p>
    <ul className="tracker-points"><li>Usa só o GPS do celular. Não precisa de rastreador, conta nem servidor, e é grátis.</li><li>No fim você confere o valor e soma à quilometragem com um toque.</li><li>Nada sai do aparelho: o trajeto não é guardado, só o total de km.</li></ul>
    {trip.native
      ? <Notice title="Pode guardar o celular no bolso.">O rastreio continua com a tela bloqueada. Na primeira vez, permita a localização e as notificações. Não deslize o app para fora da lista de recentes durante a viagem.</Notice>
      : <Notice tone="warning" title="Deixe o app aberto, com o celular preso no suporte.">Navegadores não rastreiam com o app em segundo plano ou a tela bloqueada. Instalar o aplicativo do Bros. no Android resolve isso.</Notice>}
    {trip.error && <Notice tone="danger">{trip.error}</Notice>}
    <button className="button primary full-width" onClick={trip.start}><Icon name="route" size={17} />Iniciar viagem</button>
  </div>;
}

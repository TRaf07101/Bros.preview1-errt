import { Component } from 'react';
import type { ErrorInfo, ReactNode } from 'react';
import { BrandMark, Icon } from './Icon';
import { downloadText, STORAGE_KEY } from '../maintenance/planner';

export class AppBoundary extends Component<{ children: ReactNode }, { failed: boolean; details: string }> {
  state = { failed: false, details: '' };
  static getDerivedStateFromError() { return { failed: true }; }
  componentDidCatch(error: Error, _info: ErrorInfo) { this.setState({ details: error.message }); }

  private saveBackup = () => {
    try {
      const content = localStorage.getItem(STORAGE_KEY);
      if (content) downloadText(content, 'copia-seguranca-bros.json', 'application/json');
      else this.setState({ details: 'Não foi encontrado um cadastro salvo neste navegador.' });
    } catch { this.setState({ details: 'O navegador não permitiu ler os dados locais. Evite limpar o armazenamento antes de buscar ajuda.' }); }
  };

  render() {
    if (!this.state.failed) return this.props.children;
    return <main className="app-recovery"><BrandMark /><span className="eyebrow">VAMOS RETOMAR COM CALMA</span><h1>O app encontrou<br />um imprevisto.</h1><p>Você pode guardar uma cópia dos dados locais antes de tentar novamente. Esta tela não apaga seus registros nem confirma a entrega de notificações.</p><div><button className="button primary" onClick={() => window.location.reload()}><Icon name="refresh" size={16} />Abrir novamente</button><button className="button secondary" onClick={this.saveBackup}><Icon name="download" size={16} />Guardar meus dados</button></div><details><summary>Informação para suporte</summary><pre>{this.state.details}</pre></details></main>;
  }
}
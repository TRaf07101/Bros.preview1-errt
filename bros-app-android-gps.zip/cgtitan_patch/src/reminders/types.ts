export type ReminderCategory = 'checklist' | 'mileage' | 'maintenance';
export type ReminderTarget = 'checklist' | 'mileage' | 'maintenance' | 'profile' | 'history' | 'reminders';
export type NoticePermission = 'prompt' | 'granted' | 'denied' | 'unsupported';

export interface ReminderSettings {
  enabled: boolean;
  activatedAt: string | null;
  pausedUntil: string | null;
  checklist: { enabled: boolean; time: string; days: number[] };
  mileage: { enabled: boolean; time: string; everyDays: 1 | 3 | 7 };
  maintenance: { enabled: boolean; time: string; advanceDays: 0 | 1 | 7; repeatDays: 3 | 7 };
  quiet: { enabled: boolean; from: string; until: string };
  snoozed: Partial<Record<ReminderCategory, string>>;
}

export interface NoticeJob {
  key: string;
  category: ReminderCategory;
  nativeId: number;
  title: string;
  body: string;
  at: string;
  target: ReminderTarget;
}

export interface NoticeEvent {
  id: string;
  at: string;
  title: string;
  status: 'requested' | 'opened' | 'error' | 'test';
  message: string;
}

export interface DeliveryJournal {
  delivered: Record<string, string>;
  events: NoticeEvent[];
}

export interface NotificationCapability {
  native: boolean;
  permission: NoticePermission;
  secure: boolean;
  embedded: boolean;
  worker: boolean;
  supported: boolean;
}

export interface NativeScheduleStatus {
  state: 'idle' | 'syncing' | 'scheduled' | 'error';
  count: number;
  until: string | null;
  message: string;
}

export interface InstallPrompt extends Event {
  prompt(): Promise<void>;
  userChoice: Promise<{ outcome: 'accepted' | 'dismissed' }>;
}
import type { ReminderCategory, ReminderSettings } from './types';

export const WEEKDAYS = [
  { day: 1, short: 'S', label: 'Segunda-feira' },
  { day: 2, short: 'T', label: 'Terça-feira' },
  { day: 3, short: 'Q', label: 'Quarta-feira' },
  { day: 4, short: 'Q', label: 'Quinta-feira' },
  { day: 5, short: 'S', label: 'Sexta-feira' },
  { day: 6, short: 'S', label: 'Sábado' },
  { day: 0, short: 'D', label: 'Domingo' },
];

export function defaultReminderSettings(): ReminderSettings {
  return {
    enabled: false,
    activatedAt: null,
    pausedUntil: null,
    checklist: { enabled: true, time: '07:30', days: [0, 1, 2, 3, 4, 5, 6] },
    mileage: { enabled: true, time: '18:30', everyDays: 3 },
    maintenance: { enabled: true, time: '09:00', advanceDays: 7, repeatDays: 7 },
    quiet: { enabled: true, from: '21:00', until: '07:00' },
    snoozed: {},
  };
}

export const validTime = (value: unknown): value is string => typeof value === 'string' && /^(?:[01]\d|2[0-3]):[0-5]\d$/.test(value);
export const validInstant = (value: unknown): value is string => typeof value === 'string' && /^\d{4}-\d{2}-\d{2}T/.test(value) && Number.isFinite(Date.parse(value));
const object = (value: unknown): Record<string, unknown> => value && typeof value === 'object' && !Array.isArray(value) ? value as Record<string, unknown> : {};
const boolean = (value: unknown, fallback: boolean) => typeof value === 'boolean' ? value : fallback;

export function normalizeReminderSettings(value: unknown): ReminderSettings {
  const defaults = defaultReminderSettings();
  const raw = object(value), checklist = object(raw.checklist), mileage = object(raw.mileage), maintenance = object(raw.maintenance), quiet = object(raw.quiet), rawSnoozed = object(raw.snoozed);
  const days = Array.isArray(checklist.days) ? [...new Set(checklist.days.filter((day): day is number => typeof day === 'number' && Number.isInteger(day) && day >= 0 && day <= 6))] : defaults.checklist.days;
  const snoozed: ReminderSettings['snoozed'] = {};
  for (const category of ['checklist', 'mileage', 'maintenance'] as ReminderCategory[]) {
    if (validInstant(rawSnoozed[category])) snoozed[category] = rawSnoozed[category];
  }
  return {
    enabled: boolean(raw.enabled, false),
    activatedAt: validInstant(raw.activatedAt) ? raw.activatedAt : null,
    pausedUntil: validInstant(raw.pausedUntil) ? raw.pausedUntil : null,
    checklist: { enabled: boolean(checklist.enabled, true), time: validTime(checklist.time) ? checklist.time : defaults.checklist.time, days: days.length ? days : defaults.checklist.days },
    mileage: { enabled: boolean(mileage.enabled, true), time: validTime(mileage.time) ? mileage.time : defaults.mileage.time, everyDays: [1, 3, 7].includes(Number(mileage.everyDays)) ? Number(mileage.everyDays) as 1 | 3 | 7 : defaults.mileage.everyDays },
    maintenance: { enabled: boolean(maintenance.enabled, true), time: validTime(maintenance.time) ? maintenance.time : defaults.maintenance.time, advanceDays: [0, 1, 7].includes(Number(maintenance.advanceDays)) ? Number(maintenance.advanceDays) as 0 | 1 | 7 : 7, repeatDays: maintenance.repeatDays === 3 ? 3 : 7 },
    quiet: { enabled: boolean(quiet.enabled, true), from: validTime(quiet.from) ? quiet.from : defaults.quiet.from, until: validTime(quiet.until) ? quiet.until : defaults.quiet.until },
    snoozed,
  };
}
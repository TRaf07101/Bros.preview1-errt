import { DAILY_CHECKLIST, OFFROAD_CHECKLIST } from '../maintenance/data';
import { latestMileageReading } from '../maintenance/odometer';
import { reminderList } from '../maintenance/planner';
import type { StoredState } from '../maintenance/types';
import type { NoticeJob, ReminderCategory, ReminderSettings, ReminderTarget } from './types';

export const PLAN_DAYS = 28;
export const MAX_NATIVE_JOBS = 60;
export const NATIVE_ID_MIN = 100000;
export const NATIVE_ID_MAX = 2000000000;
export const TEST_NOTICE_ID = 2147000001;
export const REFRESH_NOTICE_ID = 2147000002;
export const localDay = (date: Date) => `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}-${String(date.getDate()).padStart(2, '0')}`;
export const timeLabel = (iso: string) => new Date(iso).toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' });

export function daysBetween(a: Date, b: Date): number {
  return Math.round((Date.UTC(a.getFullYear(), a.getMonth(), a.getDate()) - Date.UTC(b.getFullYear(), b.getMonth(), b.getDate())) / 86400000);
}

export function withTime(date: Date, time: string): Date {
  const copy = new Date(date);
  const [hours, minutes] = time.split(':').map(Number);
  copy.setHours(hours, minutes, 0, 0);
  return copy;
}

export function shiftDays(date: Date, days: number): Date {
  const copy = new Date(date);
  copy.setDate(copy.getDate() + days);
  return copy;
}

export function outsideQuietHours(date: Date, quiet: ReminderSettings['quiet']): Date {
  if (!quiet.enabled || quiet.from === quiet.until) return date;
  const toMinutes = (time: string) => { const [h, m] = time.split(':').map(Number); return h * 60 + m; };
  const from = toMinutes(quiet.from), until = toMinutes(quiet.until), current = date.getHours() * 60 + date.getMinutes();
  const isQuiet = from > until ? current >= from || current < until : current >= from && current < until;
  if (!isQuiet) return date;
  const next = withTime(date, quiet.until);
  if (from > until && current >= from) next.setDate(next.getDate() + 1);
  return next;
}

export function checklistDone(state: StoredState, day: string): boolean {
  const items = [...DAILY_CHECKLIST, ...(state.checklist.offroad ? OFFROAD_CHECKLIST : [])];
  return state.checklist.date === day && items.every(item => state.checklist.checked.includes(item.id));
}

export function mileageAge(state: StoredState, now = new Date()): number | null {
  const date = latestMileageReading(state)?.createdAt;
  return date ? Math.max(0, daysBetween(now, new Date(date))) : null;
}

function identifier(value: string): number {
  let hash = 2166136261;
  for (const char of value) { hash ^= char.charCodeAt(0); hash = Math.imul(hash, 16777619); }
  return NATIVE_ID_MIN + (hash >>> 0) % (NATIVE_ID_MAX - NATIVE_ID_MIN);
}

export function notificationPlan(state: StoredState, now = new Date()): NoticeJob[] {
  const settings = state.reminders;
  const start = withTime(now, '00:00');
  const end = shiftDays(start, PLAN_DAYS);
  const activated = settings.activatedAt ? new Date(settings.activatedAt) : now;
  const mileageDate = latestMileageReading(state)?.createdAt;
  const mileageBase = mileageDate ? new Date(mileageDate) : activated;
  const reminders = reminderList(state);
  const result = new Map<string, NoticeJob>();
  const usedIds = new Set<number>();
  const add = (category: ReminderCategory, date: Date, title: string, body: string, target: ReminderTarget) => {
    let at = outsideQuietHours(date, settings.quiet);
    if (settings.pausedUntil && at < new Date(settings.pausedUntil)) return;
    const snoozed = settings.snoozed[category];
    if (snoozed && at < new Date(snoozed)) at = outsideQuietHours(new Date(snoozed), settings.quiet);
    if (at < activated || at < start || at >= end) return;
    if (category === 'checklist' && checklistDone(state, localDay(at))) return;
    const key = `${category}:${localDay(at)}`;
    const existing = result.get(key);
    if (existing) {
      if (category === 'maintenance' && existing.body !== body) existing.body += ` ${body}`;
      return;
    }
    let nativeId = identifier(key);
    while (usedIds.has(nativeId)) nativeId = nativeId >= NATIVE_ID_MAX ? NATIVE_ID_MIN : nativeId + 1;
    usedIds.add(nativeId);
    result.set(key, { key, nativeId, category, at: at.toISOString(), title, body, target });
  };
  // Yesterday's late notice may legitimately move into this morning's quiet-hour boundary.
  for (let index = -1; index < PLAN_DAYS; index++) {
    const day = shiftDays(start, index);
    const dayString = localDay(day);
    if (settings.checklist.enabled && settings.checklist.days.includes(day.getDay())) {
      add('checklist', withTime(day, settings.checklist.time), 'Vai sair com a Bros?', 'Confira óleo, pneus, freios e os outros itens antes de pilotar. Toque para abrir sua lista.', 'checklist');
    }
    if (settings.mileage.enabled) {
      const since = daysBetween(day, mileageBase);
      const first = mileageDate ? settings.mileage.everyDays : 1;
      if (since >= first && (since - first) % settings.mileage.everyDays === 0) {
        add('mileage', withTime(day, settings.mileage.time), 'Quanto sua Bros já rodou?', 'Com a moto estacionada, confira o painel e atualize os quilômetros. É isso que mantém seus próximos cuidados em dia.', 'mileage');
      }
    }
    if (settings.maintenance.enabled && state.profile.configured) {
      const topics: string[] = [];
      for (const reminder of reminders) {
        if (reminder.unknown) continue;
        const mileageDue = reminder.km !== null && state.profile.km >= reminder.km;
        const dueDate = reminder.date ? new Date(`${reminder.date}T12:00:00`) : null;
        const remaining = dueDate ? daysBetween(dueDate, day) : null;
        const detection = mileageDue && mileageDate && new Date(mileageDate) > activated ? new Date(mileageDate) : activated;
        let firstAllowed = outsideQuietHours(withTime(detection, settings.maintenance.time), settings.quiet);
        if (firstAllowed < detection) firstAllowed = outsideQuietHours(withTime(shiftDays(detection, 1), settings.maintenance.time), settings.quiet);
        const firstDue = mileageDue || !dueDate ? firstAllowed : new Date(Math.max(firstAllowed.getTime(), outsideQuietHours(withTime(dueDate, settings.maintenance.time), settings.quiet).getTime()));
        const sinceDue = daysBetween(day, firstDue);
        if (remaining === settings.maintenance.advanceDays && remaining > 0 && !mileageDue) {
          topics.push(`${reminder.title}: o prazo por data se aproxima`);
        } else if ((mileageDue || remaining !== null && remaining <= 0) && sinceDue >= 0 && sinceDue % settings.maintenance.repeatDays === 0) {
          topics.push(`${reminder.title}: confira o prazo e os serviços anteriores`);
        }
      }
      if (topics.length) add('maintenance', withTime(day, settings.maintenance.time), topics.length > 1 ? 'Seus próximos cuidados, em um só aviso' : 'Um cuidado da Bros pede atenção', `${topics.join('. ')}. Atualizar a quilometragem não marca serviços como feitos.`, 'maintenance');
    }
    // A completed checklist suppresses today's notice only, never future pre-ride checks.
    if (checklistDone(state, dayString)) result.delete(`checklist:${dayString}`);
  }
  const snoozeCopy: Record<ReminderCategory, { title: string; body: string; target: ReminderTarget }> = {
    checklist: { title: 'Seu lembrete antes de sair', body: 'Você pediu este aviso. Se for usar a moto, confira todos os itens antes de pilotar.', target: 'checklist' },
    mileage: { title: 'Vamos atualizar os quilômetros?', body: 'Você pediu para lembrar. Com a moto estacionada, confira o total no painel e registre no app.', target: 'mileage' },
    maintenance: { title: 'Confira os cuidados da sua Bros', body: 'Você pediu este aviso. Abra os prazos e o histórico para verificar o que precisa de atenção. Adiar o aviso não altera o prazo da moto.', target: 'maintenance' },
  };
  for (const category of ['checklist', 'mileage', 'maintenance'] as ReminderCategory[]) {
    const at = settings.snoozed[category];
    if (settings[category].enabled && at && Date.parse(at) >= start.getTime()) {
      const copy = snoozeCopy[category];
      add(category, new Date(at), copy.title, copy.body, copy.target);
    }
  }
  return [...result.values()].sort((a, b) => a.at.localeCompare(b.at));
}

export function snoozeDate(settings: ReminderSettings, category: ReminderCategory, now = new Date()): string {
  const tomorrow = withTime(shiftDays(now, 1), settings[category].time);
  const available = settings.pausedUntil ? new Date(Math.max(tomorrow.getTime(), Date.parse(settings.pausedUntil))) : tomorrow;
  return outsideQuietHours(available, settings.quiet).toISOString();
}

export function calendarReminders(state: StoredState, baseUrl: string, now = new Date()): string {
  const settings = state.reminders;
  const lines = ['BEGIN:VCALENDAR', 'VERSION:2.0', 'PRODID:-//Bros Caderno//Lembretes pessoais//PT-BR', 'CALSCALE:GREGORIAN', 'METHOD:PUBLISH', 'X-WR-CALNAME:Cuidados com a Bros'];
  const utc = (date: Date) => date.toISOString().replace(/[-:]/g, '').replace(/\.\d{3}/, '');
  const local = (date: Date) => `${localDay(date).replace(/-/g, '')}T${String(date.getHours()).padStart(2, '0')}${String(date.getMinutes()).padStart(2, '0')}00`;
  const escape = (value: string) => value.replace(/\\/g, '\\\\').replace(/\n/g, '\\n').replace(/,/g, '\\,').replace(/;/g, '\\;');
  const link = (target: ReminderTarget) => /^https?:/.test(baseUrl) ? `${baseUrl}#${target === 'mileage' ? 'reminders/mileage' : target === 'maintenance' ? 'reminders/care' : target}` : '';
  const event = (id: string, at: Date, title: string, body: string, target: ReminderTarget, rule?: string, advanceDays = 0) => {
    lines.push('BEGIN:VEVENT', `UID:bros-${id}@caderno.local`, `DTSTAMP:${utc(now)}`, `DTSTART:${local(at)}`, 'DURATION:PT10M', `SUMMARY:${escape(title)}`, `DESCRIPTION:${escape(`${body} Lembrete pessoal, não mudança do intervalo do manual. A agenda não sincroniza serviços ou cancelamentos com o app. ${link(target)}`)}`);
    if (rule) lines.push(`RRULE:${rule}`);
    lines.push('BEGIN:VALARM', 'ACTION:DISPLAY', 'TRIGGER:PT0M', `DESCRIPTION:${escape(title)}`, 'END:VALARM');
    if (advanceDays > 0 && shiftDays(at, -advanceDays) > now) lines.push('BEGIN:VALARM', 'ACTION:DISPLAY', `TRIGGER:-P${advanceDays}D`, `DESCRIPTION:${escape(title)}`, 'END:VALARM');
    lines.push('END:VEVENT');
  };
  const firstTime = (time: string, days?: number[]) => {
    for (let offset = 0; offset < 9; offset++) {
      const source = withTime(shiftDays(now, offset), time);
      const adjusted = outsideQuietHours(source, settings.quiet);
      if (adjusted > now && (!days || days.includes(source.getDay()))) return adjusted;
    }
    return outsideQuietHours(withTime(shiftDays(now, 1), time), settings.quiet);
  };
  if (settings.checklist.enabled) {
    const at = firstTime(settings.checklist.time, settings.checklist.days);
    const names = ['SU', 'MO', 'TU', 'WE', 'TH', 'FR', 'SA'];
    const sample = withTime(now, settings.checklist.time);
    const dayShift = daysBetween(outsideQuietHours(sample, settings.quiet), sample);
    event('checklist-routine', at, 'Bros: verificar antes de sair', 'Óleo, freios, pneus e todos os itens da lista. Faça a verificação antes de cada saída, mesmo fora do horário do lembrete.', 'checklist', `FREQ=WEEKLY;BYDAY=${settings.checklist.days.map(day => names[(day + dayShift) % 7]).join(',')}`);
  }
  if (settings.mileage.enabled) {
    const next = notificationPlan(state, now).find(job => job.category === 'mileage' && Date.parse(job.at) > now.getTime());
    event('mileage-routine', next ? new Date(next.at) : firstTime(settings.mileage.time), 'Bros: atualizar quilometragem', 'Confira a quilometragem com a moto estacionada. A agenda não lê o painel e não detecta viagens.', 'mileage', `FREQ=DAILY;INTERVAL=${settings.mileage.everyDays}`);
  }
  if (settings.maintenance.enabled) {
    for (const reminder of reminderList(state).filter(item => item.date && !item.unknown)) {
      const at = outsideQuietHours(withTime(new Date(`${reminder.date}T12:00:00`), settings.maintenance.time), settings.quiet);
      if (at <= now) continue;
      event(`${reminder.id}-${reminder.date}`, at, `Bros: ${reminder.title}`, reminder.description, 'maintenance', undefined, settings.maintenance.advanceDays);
    }
  }
  lines.push('END:VCALENDAR');
  return lines.map(line => {
    const chunks: string[] = []; let part = '', bytes = 0;
    for (const char of line) {
      const size = new TextEncoder().encode(char).length;
      if (bytes + size > 70) { chunks.push(part); part = ' '; bytes = 1; }
      part += char; bytes += size;
    }
    chunks.push(part); return chunks.join('\r\n');
  }).join('\r\n');
}
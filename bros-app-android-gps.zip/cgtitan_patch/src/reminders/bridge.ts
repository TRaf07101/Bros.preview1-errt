import { Capacitor } from '@capacitor/core';
import { LocalNotifications } from '@capacitor/local-notifications';
import type { LocalNotificationSchema } from '@capacitor/local-notifications';
import { appBase, isEmbedded, registerAppWorker } from './pwa';
import { MAX_NATIVE_JOBS, NATIVE_ID_MIN, NATIVE_ID_MAX, PLAN_DAYS, REFRESH_NOTICE_ID, TEST_NOTICE_ID } from './plan';
import type { NativeScheduleStatus, NoticeJob, NoticePermission, NotificationCapability, ReminderTarget } from './types';

export const isNativeApp = () => Capacitor.isNativePlatform();
const normalizePermission = (value: string): NoticePermission => value === 'granted' || value === 'denied' ? value : 'prompt';
const isOwnedId = (id: number) => id >= NATIVE_ID_MIN && id <= NATIVE_ID_MAX || id === REFRESH_NOTICE_ID || id === TEST_NOTICE_ID;
export const safeTarget = (value: unknown): ReminderTarget => typeof value === 'string' && ['checklist', 'mileage', 'maintenance', 'profile', 'history', 'reminders'].includes(value) ? value as ReminderTarget : 'reminders';

export async function notificationCapability(): Promise<NotificationCapability> {
  if (isNativeApp()) {
    if (!Capacitor.isPluginAvailable('LocalNotifications')) return { native: true, permission: 'unsupported', secure: true, embedded: false, worker: false, supported: false };
    try {
      const permission = await LocalNotifications.checkPermissions();
      return { native: true, permission: normalizePermission(permission.display), secure: true, embedded: false, worker: false, supported: true };
    } catch { return { native: true, permission: 'unsupported', secure: true, embedded: false, worker: false, supported: false }; }
  }
  const supported = 'Notification' in window && 'serviceWorker' in navigator && window.isSecureContext;
  const embedded = isEmbedded();
  const registration = supported ? await registerAppWorker() : null;
  return { native: false, permission: supported ? normalizePermission(Notification.permission) : 'unsupported', secure: window.isSecureContext, embedded, worker: !!registration?.active, supported: supported && !embedded };
}

export async function requestNoticePermission(): Promise<NoticePermission> {
  if (isNativeApp()) {
    const result = await LocalNotifications.requestPermissions();
    return normalizePermission(result.display);
  }
  if (!window.isSecureContext || !('Notification' in window) || isEmbedded()) return 'unsupported';
  if (Notification.permission === 'denied') return 'denied';
  // Keep the browser request inside the click gesture, before waiting for service workers.
  const permission = Notification.permission === 'granted' ? 'granted' : await Notification.requestPermission();
  return normalizePermission(permission);
}

async function prepareNativeChannel() {
  if (Capacitor.getPlatform() !== 'android') return;
  await LocalNotifications.createChannel({ id: 'bros-care-v1', name: 'Cuidados com a Bros', description: 'Verificações, quilometragem e manutenção. Horários escolhidos por você.', importance: 3, visibility: 0, vibration: true, lights: false });
}

export async function showWebNotice(title: string, body: string, target: ReminderTarget, tag: string): Promise<void> {
  if (!('Notification' in window) || Notification.permission !== 'granted') throw new Error('A permissão de notificações não está ativa.');
  const registration = await registerAppWorker();
  if (!registration?.active) throw new Error('Não foi possível preparar as notificações neste endereço. Abra o app em uma aba própria com HTTPS.');
  await registration.showNotification(title, { body, icon: new URL('icons/bros-192.svg', appBase()).href, badge: new URL('icons/notification-badge.svg', appBase()).href, tag: `bros:${tag}`, data: { target }, lang: 'pt-BR' });
}

export async function testRealNotification(): Promise<string> {
  if (isNativeApp()) {
    const permission = await LocalNotifications.checkPermissions();
    if (permission.display !== 'granted') throw new Error('Ative a permissão antes de testar.');
    await prepareNativeChannel();
    await LocalNotifications.schedule({ notifications: [{ id: TEST_NOTICE_ID, title: 'Bros. Seu teste de lembrete', body: 'Este é um aviso do sistema, não apenas uma mensagem dentro do app. Toque para voltar aos lembretes.', schedule: { at: new Date(Date.now() + 4000) }, isExactNotification: false, channelId: 'bros-care-v1', extra: { target: 'reminders', key: 'test' }, autoCancel: true }] });
    return 'Teste agendado no sistema. Confira a área de notificações; o Android pode ajustar o horário.';
  }
  await showWebNotice('Bros. Seu teste de lembrete', 'Este é um aviso real do navegador. Os avisos agendados na web dependem de a página continuar funcionando.', 'reminders', 'test');
  return 'O navegador aceitou o teste. Confira as notificações do aparelho. O modo Não Perturbe pode ocultar o aviso.';
}

let nativeQueue: Promise<unknown> = Promise.resolve();
let requestedVersion = 0;

export function synchronizeNative(jobs: NoticeJob[], enabled: boolean): Promise<NativeScheduleStatus> {
  const version = ++requestedVersion;
  const run = async (): Promise<NativeScheduleStatus> => {
    if (!isNativeApp()) return { state: 'idle', count: 0, until: null, message: 'Agendamento local disponível somente no pacote nativo.' };
    if (version !== requestedVersion) return { state: 'idle', count: 0, until: null, message: 'Preferências atualizadas novamente.' };
    const pending = await LocalNotifications.getPending();
    const own = pending.notifications.filter(item => isOwnedId(item.id) && item.id !== TEST_NOTICE_ID).map(item => ({ id: item.id }));
    if (own.length) await LocalNotifications.cancel({ notifications: own });
    if (!enabled) return { state: 'idle', count: 0, until: null, message: 'Programação do sistema cancelada.' };
    const permission = await LocalNotifications.checkPermissions();
    if (permission.display !== 'granted') return { state: 'error', count: 0, until: null, message: 'A permissão de notificações não está ativa no sistema.' };
    await prepareNativeChannel();
    const future = jobs.filter(job => Date.parse(job.at) > Date.now() + 5000).slice(0, MAX_NATIVE_JOBS - 1);
    if (!future.length) return { state: 'idle', count: 0, until: null, message: 'Nenhum aviso futuro neste período. Reveja os dias, pausas e horários.' };
    const notifications: LocalNotificationSchema[] = future.map(job => ({ id: job.nativeId, title: job.title, body: job.body, schedule: { at: new Date(job.at), allowWhileIdle: false }, isExactNotification: false, channelId: 'bros-care-v1', autoCancel: true, group: 'bros-care', extra: { target: job.target, key: job.key, category: job.category } }));
    const until = future[future.length - 1].at;
    const renewAt = Math.max(Date.now() + 60000, Date.parse(until) - 3600000);
    notifications.push({ id: REFRESH_NOTICE_ID, title: 'Vamos renovar os próximos lembretes?', body: 'Abra a Bros para atualizar os dados e programar as próximas semanas. Os avisos já agendados têm uma data final.', schedule: { at: new Date(renewAt) }, isExactNotification: false, channelId: 'bros-care-v1', autoCancel: true, extra: { target: 'reminders', key: 'renew' } });
    if (version !== requestedVersion) return { state: 'idle', count: 0, until: null, message: 'Atualização de horários em andamento.' };
    await LocalNotifications.schedule({ notifications });
    const verified = await LocalNotifications.getPending();
    const acceptedIds = new Set(verified.notifications.map(item => item.id));
    const count = future.filter(job => acceptedIds.has(job.nativeId)).length;
    if (count !== future.length) throw new Error('Nem todos os lembretes apareceram na programação do sistema. Tente sincronizar novamente.');
    return { state: 'scheduled', count, until, message: `${count} avisos confirmados na programação do sistema, em uma janela de até ${PLAN_DAYS} dias. Ao abrir o app, ela é renovada.` };
  };
  const promise = nativeQueue.then(run, run);
  nativeQueue = promise.catch(() => undefined);
  return promise;
}

export async function clearSystemNotices() {
  if (isNativeApp()) {
    await synchronizeNative([], false);
    const pending = await LocalNotifications.getPending();
    const own = pending.notifications.filter(item => isOwnedId(item.id)).map(item => ({ id: item.id }));
    if (own.length) await LocalNotifications.cancel({ notifications: own });
    const delivered = await LocalNotifications.getDeliveredNotifications();
    const ours = delivered.notifications.filter(item => isOwnedId(item.id));
    if (ours.length) await LocalNotifications.removeDeliveredNotifications({ notifications: ours });
  } else {
    const registration = await registerAppWorker();
    const notices = await registration?.getNotifications();
    notices?.filter(notice => notice.tag.startsWith('bros:')).forEach(notice => notice.close());
  }
}
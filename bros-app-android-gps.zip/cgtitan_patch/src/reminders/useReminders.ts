import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { App as NativeApp } from '@capacitor/app';
import { LocalNotifications } from '@capacitor/local-notifications';
import type { PluginListenerHandle } from '@capacitor/core';
import type { StoredState } from '../maintenance/types';
import { clearSystemNotices, isNativeApp, notificationCapability, requestNoticePermission, safeTarget, showWebNotice, synchronizeNative, testRealNotification } from './bridge';
import { clearNotificationJournal, logNotice, readJournal, withNotificationLock } from './journal';
import { localDay, notificationPlan, outsideQuietHours } from './plan';
import { registerAppWorker } from './pwa';
import type { NativeScheduleStatus, NotificationCapability, ReminderTarget } from './types';

const initialCapability: NotificationCapability = { native: isNativeApp(), permission: 'prompt', secure: window.isSecureContext, embedded: false, worker: false, supported: false };

export function useReminders(state: StoredState, onOpen: (target: ReminderTarget) => void) {
  const [capability, setCapability] = useState(initialCapability);
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState('');
  const [journal, setJournal] = useState(readJournal);
  const [now, setNow] = useState(() => new Date());
  const [syncNonce, setSyncNonce] = useState(0);
  const [schedule, setSchedule] = useState<NativeScheduleStatus>({ state: 'idle', count: 0, until: null, message: '' });
  const latest = useRef(state); latest.current = state;
  const handler = useRef(onOpen); handler.current = onOpen;
  const deliveryBusy = useRef(false);
  const retryAfter = useRef(0);
  const jobs = useMemo(() => notificationPlan(state, now), [state.profile, state.records, state.mileageReadings, state.reminders, state.checklist, now]);
  const fingerprint = JSON.stringify({ jobs, enabled: state.reminders.enabled });
  const currentJobs = useRef(jobs); currentJobs.current = jobs;

  const refreshCapability = useCallback(async () => {
    const value = await notificationCapability(); setCapability(value); return value;
  }, []);

  useEffect(() => {
    void refreshCapability();
    const updateLog = () => setJournal(readJournal());
    const refresh = () => { setNow(new Date()); void refreshCapability(); setSyncNonce(value => value + 1); };
    const visibility = () => { if (!document.hidden) refresh(); };
    window.addEventListener('bros-notification-journal', updateLog);
    window.addEventListener('storage', updateLog);
    window.addEventListener('focus', refresh);
    document.addEventListener('visibilitychange', visibility);
    const clock = window.setInterval(() => setNow(new Date()), 30000);
    return () => { window.removeEventListener('bros-notification-journal', updateLog); window.removeEventListener('storage', updateLog); window.removeEventListener('focus', refresh); document.removeEventListener('visibilitychange', visibility); clearInterval(clock); };
  }, [refreshCapability]);

  useEffect(() => {
    let active = true;
    const handles: PluginListenerHandle[] = [];
    const keep = (handle: PluginListenerHandle) => { if (active) handles.push(handle); else void handle.remove(); };
    const open = (target: unknown, title: string) => { logNotice('opened', title, 'Você tocou no aviso. Nenhum cuidado foi marcado como feito.'); handler.current(safeTarget(target)); };
    const workerMessage = (event: MessageEvent) => {
      if (event.data?.type === 'BROS_NOTICE_OPEN') open(event.data.target, 'Aviso aberto');
    };
    if ('serviceWorker' in navigator) navigator.serviceWorker.addEventListener('message', workerMessage);
    if (isNativeApp()) {
      void LocalNotifications.addListener('localNotificationActionPerformed', event => open(event.notification.extra?.target, event.notification.title || 'Lembrete aberto')).then(keep).catch(() => {});
      void LocalNotifications.addListener('localNotificationReceived', event => {
        logNotice('requested', event.title, 'O aplicativo recebeu o evento de notificação do sistema.', event.extra?.key ? [event.extra.key] : []);
      }).then(keep).catch(() => {});
      void NativeApp.addListener('appStateChange', event => { if (event.isActive) { setNow(new Date()); void refreshCapability(); setSyncNonce(value => value + 1); } }).then(keep).catch(() => {});
    }
    return () => { active = false; handles.forEach(handle => void handle.remove()); if ('serviceWorker' in navigator) navigator.serviceWorker.removeEventListener('message', workerMessage); };
  }, [refreshCapability]);

  useEffect(() => {
    if (!isNativeApp()) return;
    let alive = true;
    const enabled = state.reminders.enabled && capability.permission === 'granted';
    const timer = window.setTimeout(() => {
      setSchedule(previous => ({ ...previous, state: 'syncing' }));
      void synchronizeNative(currentJobs.current, enabled).then(result => { if (alive) setSchedule(result); }).catch(error => {
        const text = error instanceof Error ? error.message : 'Não foi possível confirmar a programação no sistema.';
        if (alive) setSchedule({ state: 'error', count: 0, until: null, message: text });
        logNotice('error', 'Programação não confirmada', text);
      });
    }, 650);
    return () => { alive = false; clearTimeout(timer); };
  }, [fingerprint, capability.permission, syncNonce, state.reminders.enabled]);

  useEffect(() => {
    if (isNativeApp() || !state.reminders.enabled || capability.permission !== 'granted' || !capability.worker) return;
    const deliver = async () => {
      if (deliveryBusy.current || Date.now() < retryAfter.current) return;
      const actual = new Date(), settings = latest.current.reminders;
      if (!settings.enabled || settings.pausedUntil && Date.parse(settings.pausedUntil) > actual.getTime() || outsideQuietHours(actual, settings.quiet).getTime() !== actual.getTime()) return;
      deliveryBusy.current = true;
      try {
        await withNotificationLock(async () => {
          const log = readJournal();
          const pending = notificationPlan(latest.current, actual).filter(job => Date.parse(job.at) <= actual.getTime() && localDay(new Date(job.at)) === localDay(actual) && !log.delivered[job.key]);
          if (!pending.length) return;
          const title = pending.length === 1 ? pending[0].title : 'Bros. Seus cuidados de hoje';
          const body = pending.length === 1 ? pending[0].body : pending.map(job => job.title).join(' · ') + '. Toque para conferir sem marcar nada como feito.';
          await showWebNotice(title, body, pending.length === 1 ? pending[0].target : 'reminders', pending.map(job => job.key).join('|'));
          logNotice('requested', title, 'Solicitação aceita pelo navegador. A exibição final depende das configurações do aparelho.', pending.map(job => job.key));
        });
      } catch (error) {
        const text = error instanceof Error ? error.message : 'Falha ao solicitar o aviso.';
        logNotice('error', 'Aviso não enviado', text); setMessage(text); retryAfter.current = Date.now() + 300000;
      } finally { deliveryBusy.current = false; }
    };
    void deliver();
  }, [now, fingerprint, capability.permission, capability.worker, state.reminders.enabled]);

  const enable = async (): Promise<boolean> => {
    setBusy(true); setMessage('');
    try {
      const permission = await requestNoticePermission();
      if (permission !== 'granted') {
        const text = permission === 'denied' ? 'As notificações estão bloqueadas. Abra as permissões deste site ou do app nas configurações do aparelho. Não vamos insistir com novos pedidos.' : permission === 'unsupported' ? 'Este ambiente não permite notificações. Abra o endereço em uma aba própria com HTTPS ou use a agenda do celular.' : 'Nenhuma permissão foi concedida. Você pode decidir depois.';
        setMessage(text); await refreshCapability(); return false;
      }
      if (!isNativeApp() && !await registerAppWorker()) throw new Error('A permissão foi aceita, mas as notificações não puderam ser preparadas neste endereço. Abra em uma aba própria.');
      await refreshCapability();
      setMessage(isNativeApp() ? 'Permissão recebida. Aguarde a confirmação da programação no sistema.' : 'Notificações permitidas. Nesta versão web, os horários dependem de a página continuar funcionando; com ela fechada, use a agenda.');
      return true;
    } catch (error) { setMessage(error instanceof Error ? error.message : 'Não foi possível ativar as notificações.'); return false; }
    finally { setBusy(false); }
  };
  const test = async () => {
    setBusy(true); setMessage('');
    try { const text = await testRealNotification(); setMessage(text); logNotice('test', 'Teste de notificação', text); }
    catch (error) { const text = error instanceof Error ? error.message : 'O teste não pôde ser enviado.'; setMessage(text); logNotice('error', 'Teste não enviado', text); }
    finally { setBusy(false); }
  };
  const cancel = async (): Promise<boolean> => {
    setBusy(true);
    try { await clearSystemNotices(); setSchedule({ state: 'idle', count: 0, until: null, message: 'Avisos do app cancelados.' }); return true; }
    catch { setMessage('Não foi possível confirmar o cancelamento no sistema. Desative as notificações nas configurações do aparelho e tente novamente.'); return false; }
    finally { setBusy(false); }
  };
  const reset = async () => { const success = await cancel(); clearNotificationJournal(); return success; };
  return { capability, busy, message, journal, now, jobs, schedule, enable, test, cancel, reset, refreshCapability, sync: () => { setSyncNonce(value => value + 1); void refreshCapability(); }, clearMessage: () => setMessage('') };
}

export type ReminderController = ReturnType<typeof useReminders>;
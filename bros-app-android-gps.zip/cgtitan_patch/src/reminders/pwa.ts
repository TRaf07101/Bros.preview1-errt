import { Capacitor } from '@capacitor/core';
import { useEffect, useState } from 'react';
import type { InstallPrompt } from './types';

let workerPromise: Promise<ServiceWorkerRegistration | null> | null = null;
let deferredInstall: InstallPrompt | null = null;

export function appBase(): URL { return new URL('./', window.location.href); }
export function isEmbedded(): boolean { try { return window.top !== window.self; } catch { return true; } }

export function registerAppWorker(): Promise<ServiceWorkerRegistration | null> {
  if (Capacitor.isNativePlatform() || !('serviceWorker' in navigator) || !window.isSecureContext) return Promise.resolve(null);
  if (!workerPromise) {
    workerPromise = (async () => {
      try {
        const registration = await navigator.serviceWorker.register(new URL('bros-sw.js', appBase()), { scope: appBase().pathname, updateViaCache: 'none' });
        if (registration.active) return registration;
        return await new Promise<ServiceWorkerRegistration | null>(resolve => {
          const timer = window.setTimeout(() => resolve(null), 10000);
          const worker = registration.installing || registration.waiting;
          if (!worker) { clearTimeout(timer); resolve(null); return; }
          const change = () => {
            if (worker.state === 'activated') { clearTimeout(timer); worker.removeEventListener('statechange', change); resolve(registration); }
            if (worker.state === 'redundant') { clearTimeout(timer); worker.removeEventListener('statechange', change); resolve(null); }
          };
          worker.addEventListener('statechange', change); change();
        });
      } catch { return null; }
    })().then(value => { if (!value) workerPromise = null; return value; });
  }
  return workerPromise;
}

export function initializePwa() {
  if (Capacitor.isNativePlatform()) return;
  window.addEventListener('beforeinstallprompt', event => {
    event.preventDefault(); deferredInstall = event as InstallPrompt;
    window.dispatchEvent(new Event('bros-install-state'));
  });
  window.addEventListener('appinstalled', () => { deferredInstall = null; window.dispatchEvent(new Event('bros-install-state')); });
  void registerAppWorker();
}

export function useInstallState() {
  const detectInstalled = () => Capacitor.isNativePlatform() || window.matchMedia('(display-mode: standalone)').matches || Boolean((navigator as Navigator & { standalone?: boolean }).standalone);
  const [installed, setInstalled] = useState(detectInstalled);
  const [available, setAvailable] = useState(!!deferredInstall);
  const [offline, setOffline] = useState(!navigator.onLine);
  const [updateReady, setUpdateReady] = useState(false);
  useEffect(() => {
    let alive = true;
    const refresh = () => { setInstalled(detectInstalled()); setAvailable(!!deferredInstall); setOffline(!navigator.onLine); };
    window.addEventListener('bros-install-state', refresh);
    window.addEventListener('online', refresh); window.addEventListener('offline', refresh);
    const mode = window.matchMedia('(display-mode: standalone)');
    mode.addEventListener('change', refresh);
    void registerAppWorker().then(reg => {
      if (!reg || !alive) return;
      setUpdateReady(!!reg.waiting);
      reg.addEventListener('updatefound', () => {
        const worker = reg.installing;
        worker?.addEventListener('statechange', () => { if (alive && worker.state === 'installed' && navigator.serviceWorker.controller) setUpdateReady(true); });
      });
    });
    return () => { alive = false; window.removeEventListener('bros-install-state', refresh); window.removeEventListener('online', refresh); window.removeEventListener('offline', refresh); mode.removeEventListener('change', refresh); };
  }, []);
  const install = async (): Promise<string> => {
    if (detectInstalled()) return 'O app já está aberto como aplicativo neste aparelho.';
    if (deferredInstall) {
      const event = deferredInstall; deferredInstall = null; setAvailable(false);
      try { await event.prompt(); const result = await event.userChoice; return result.outcome === 'accepted' ? 'Instalação solicitada ao navegador.' : 'Tudo bem. Você pode instalar quando quiser.'; }
      catch { return 'Não foi possível abrir a instalação. Use o menu do navegador.'; }
    }
    if (isEmbedded()) return 'Abra o endereço do app em uma aba própria. Depois, use o menu do navegador e escolha Instalar app ou Adicionar à tela inicial.';
    return 'No Android, abra o menu do navegador e procure Instalar app ou Adicionar à tela inicial. No iPhone, use Compartilhar e Adicionar à Tela de Início. A opção depende do navegador.';
  };
  const update = async () => {
    const registration = await registerAppWorker();
    if (registration?.waiting) {
      navigator.serviceWorker.addEventListener('controllerchange', () => window.location.reload(), { once: true });
      registration.waiting.postMessage({ type: 'BROS_SKIP_WAITING' });
    }
  };
  return { installed, available, offline, updateReady, install, update };
}
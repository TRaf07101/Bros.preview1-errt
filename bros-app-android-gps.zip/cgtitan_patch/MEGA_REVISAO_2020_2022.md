# Mega revisão NXR 160 Bros 2020–2022

## Correção principal
As entradas `NXR-2020`, `NXR-2021` e `NXR-2022` existiam no catálogo e tinham cores/CBS definidos, mas `motorcycleImagePath()` não possuía aliases de imagem para elas. O fallback então montava nomes como `bros-NXR-2020-cbs-azul.webp`, arquivos que não existem. Isso fazia a imagem cair no erro de carregamento.

## Estado após a correção
Cada cor disponível foi ligada a um asset local padronizado:
- NXR-2020 → `bros-2020-2021-cbs-*`
- NXR-2021 → `bros-2021-2022-cbs-*`
- NXR-2022 → `bros-2022-2023-cbs-*`

Os três anos continuam com uma única configuração CBS e não oferecem ABS.

## Verificação dos assets
- 2020 azul: 1536×1024, alpha nos cantos, bbox [64, 47, 1470, 976]
- 2020 preta: 1536×1024, alpha nos cantos, bbox [59, 47, 1476, 975]
- 2020 vermelha: 1536×1024, alpha nos cantos, bbox [56, 47, 1478, 975]
- 2021 azul: 1536×1024, alpha nos cantos, bbox [124, 54, 1377, 952]
- 2021 preta: 1536×1024, alpha nos cantos, bbox [76, 56, 1422, 950]
- 2021 vermelha: 1536×1024, alpha nos cantos, bbox [124, 54, 1377, 952]
- 2022 branca: 1536×1024, alpha nos cantos, bbox [173, 52, 1362, 971]
- 2022 preta: 1536×1024, alpha nos cantos, bbox [148, 52, 1386, 971]
- 2022 vermelha: 1536×1024, alpha nos cantos, bbox [148, 52, 1386, 971]

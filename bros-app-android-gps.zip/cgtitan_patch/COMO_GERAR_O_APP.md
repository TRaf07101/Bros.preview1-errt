# Como gerar o aplicativo Android (grátis)

Precisa de uma conta gratuita no GitHub e, de preferência, um computador só para enviar os arquivos (5 minutos).

1. Em github.com, crie uma conta e um repositório novo (botão **New**). Pode ser privado.
2. Descompacte este projeto. No repositório, clique em **uploading an existing file** e arraste TODO o conteúdo da pasta (inclusive `.github`, `server`, `src`, `scripts`). Clique em **Commit changes**.
3. Abra a aba **Actions** › **Gerar aplicativo Android (APK)** › **Run workflow**. Leva uns 10 a 15 minutos.
4. Quando ficar verde, vá em **Releases** (coluna da direita da página inicial do repositório) e baixe `bros-rastreador.apk` no celular Android.
5. Abra o arquivo. O Android vai pedir para permitir a instalação de apps desta fonte: permita.

## Antes da primeira viagem
- Abra o app, toque em **Vou andar de moto** e permita a **localização** e as **notificações**.
- Em Configurações do Android › Apps › Bros. › Bateria, escolha **Sem restrições** (Samsung, Xiaomi e Motorola costumam matar apps em segundo plano).
- Durante a viagem pode bloquear a tela e usar outros apps. **Não deslize o app para fora da lista de recentes.**

## Se der erro no passo 3
Abra a execução com X vermelho, copie as últimas linhas do log e me envie.

// Ajusta o projeto Android gerado por `npx cap add android`: permissões de GPS em segundo plano
// e texto do canal de notificação. Pode rodar mais de uma vez sem duplicar nada.
import fs from 'node:fs';

const manifestPath = 'android/app/src/main/AndroidManifest.xml';
const stringsPath = 'android/app/src/main/res/values/strings.xml';

let manifest = fs.readFileSync(manifestPath, 'utf8');
const permissions = [
  'android.permission.ACCESS_FINE_LOCATION',
  'android.permission.ACCESS_COARSE_LOCATION',
  'android.permission.FOREGROUND_SERVICE',
  'android.permission.FOREGROUND_SERVICE_LOCATION',
  'android.permission.POST_NOTIFICATIONS',
  'android.permission.WAKE_LOCK',
];
const missing = permissions.filter(name => !manifest.includes(`"${name}"`));
if (missing.length) {
  const lines = missing.map(name => `    <uses-permission android:name="${name}" />`).join('\n');
  manifest = manifest.replace(/(\s*<\/manifest>)/, `\n${lines}\n$1`);
  fs.writeFileSync(manifestPath, manifest);
}
if (!manifest.includes('android.hardware.location.gps')) {
  fs.writeFileSync(manifestPath, manifest.replace(/(\s*<\/manifest>)/, '\n    <uses-feature android:name="android.hardware.location.gps" android:required="false" />\n$1'));
}

let strings = fs.readFileSync(stringsPath, 'utf8');
if (!strings.includes('capacitor_background_geolocation_notification_channel_name')) {
  strings = strings.replace('</resources>', '    <string name="capacitor_background_geolocation_notification_channel_name">Viagem em andamento</string>\n</resources>');
  fs.writeFileSync(stringsPath, strings);
}
console.log('Projeto Android ajustado. Permissões adicionadas:', missing.length ? missing.join(', ') : 'nenhuma (já existiam)');

# Mega auditoria — fotos e variantes — etapa CG 160 Fan 2022

Data: 2026-09-12

## Escopo
- NXR/Bros permanece restrito a 2013+.
- Nesta etapa foi adicionada a **CG 160 Fan 2022**.
- Fan 2022: CBS; cores cadastradas: Azul Perolizado, Vermelho e Preto.

## Fontes conferidas
- Manual oficial Honda CG 160 Fan/Titan 2022 — D2203-MAN-1260.
- Honda/press material e referências históricas para a composição de cores de 2022.
- Fotos reais de 2022 encontradas na web para azul, preto e vermelho; são fontes fotográficas remotas e passam pelo mesmo processamento de fundo/canvas do app.

## Revisão automática
- 18 testes estáticos de catálogo/fotos: **18 passaram, 0 falharam**.
- Nenhum placeholder `Foto indisponível` foi encontrado no catálogo de modelos.
- Nenhum alias `REMOTE:FAN-*` ficou para a Fan.
- Nenhum ano 2011/2012 foi introduzido.
- A Fan 2022 foi ligada às regras de manutenção da família FAN, não às regras históricas da NXR.

## Observação
A disponibilidade HTTP de todas as imagens remotas não pode ser garantida somente por um teste estático; no runtime, imagens remotas continuam sujeitas a falha de rede/origem. O componente do app não exibe a foto remota bruta como fallback.

## Atualização 2013–2016
A disponibilidade da imagem não depende mais do sucesso do canvas. A fonte remota é mostrada diretamente e o recorte transparente substitui a imagem somente quando consegue ser produzido. Também foi corrigido o stride pós-crop.

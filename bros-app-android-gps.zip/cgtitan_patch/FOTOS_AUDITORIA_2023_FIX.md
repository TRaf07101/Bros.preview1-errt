# Correção de fotos 2023/2024

O problema era real: o app armazenava alguns aliases de assets locais no formato `ano-ano/cbs-cor`, mas o gerador de URL concatenava esse alias literalmente, produzindo um caminho com uma barra extra (ex.: `.../images/motorcycles/bros-2023-2024/cbs-preta.webp`). Isso podia gerar 404 e acionar o fallback “Foto indisponível”.

A correção normaliza `/` para `-` no nome do asset e também cria referências explícitas para os três arquivos 2023/2024. O caminho agora usa `import.meta.env.BASE_URL`, funcionando também quando publicado em subpasta.

Testes de foto/matriz: 9/9 passaram.

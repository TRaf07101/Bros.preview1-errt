# Servidor do rastreador (bros-tracker-server)

Backend que liga o rastreador GPS da moto ao bros. Ele guarda as credenciais cifradas, consulta o rastreador mesmo com o app fechado, detecta viagens e entrega ao app só a distância nova. Nenhum token vai para o navegador.

```
Rastreador → plataforma/API do rastreador → este servidor → SQLite → app bros.
```

Sem dependências de produção: usa só o Node 22.18 ou mais novo (`node:sqlite`, `fetch`).

## Ativar a conexão real

1. Tenha um servidor **Traccar** (próprio ou de um provedor) com o rastreador cadastrado. Em Traccar › Conta, gere um **token de acesso**.
2. Neste servidor, copie `.env.example` para `.env` e preencha:
   - `BROS_SECRET_KEY`: 32 bytes em base64 (o comando está no arquivo).
   - `BROS_ALLOWED_ORIGINS`: endereço do app, por exemplo `https://seu-usuario.github.io`.
   - `BROS_PUBLIC_URL`: endereço público deste servidor (HTTPS).
3. `npm start` (carregue o `.env` com `node --env-file=.env`). Publique atrás de HTTPS.
4. No app, gere o build com `VITE_BROS_API_URL=https://endereço-deste-servidor`.
5. No app: Configurações e dados › Rastreador da moto › Conectar.

**Cookie entre sites:** o app usa um cookie de sessão `HttpOnly; Secure; SameSite=None`. Safari e outros navegadores bloqueiam cookies de terceiros. Para funcionar em todos, hospede o servidor num subdomínio do mesmo site do app (`app.exemplo.com` e `api.exemplo.com`).

## Como a quilometragem é calculada

- **Odômetro do rastreador** (`attributes.odometer`, ou `totalDistance` como alternativa): preferido. A distância é a diferença entre o valor atual e o último considerado.
- **Só viagens:** soma a distância de cada viagem. Se a viagem vier sem distância, calcula pelos pontos GPS (`sync/gps.ts`), descartando pontos inválidos, repetidos, ruído parado, saltos acima de 200 km/h e trechos sem sinal. Se sobrar pouco material confiável, vira pendente.
- **Sem duplicar:** cada viagem é única pelo `(conexão, id)`; trechos sobrepostos não somam duas vezes; cada atualização entregue ao app tem um número de sequência que o app só aplica uma vez.
- **Pendente (nada muda):** odômetro que diminuiu, dados insuficientes, distância impossível para o tempo. O app mostra o motivo; o usuário descarta ou, quando há distância medida, confirma.
- **Viagem em andamento:** enquanto a moto se move, e por 2 minutos depois de parar, o servidor espera para não contar uma viagem pela metade.
- Mudanças menores que 100 m acumulam até valerem uma atualização.

O rastreador não sabe a quilometragem da moto, só o que mediu desde que foi ligado. Por isso a conexão parte da quilometragem que já está no bros. e soma só o que vier depois. Viagens anteriores à conexão não entram.

## Auditoria

Cada sincronização fica em `sync_events` (viagens, início, fim, distância, odômetro antes e depois, quilometragem antes e depois, origem, status, data) e cada viagem em `trips`. No app, cada soma também entra no histórico de quilometragem com a origem "Atualizada pelo rastreador" e o detalhe na observação.

## Segurança

- Credenciais cifradas com AES-256-GCM (`BROS_SECRET_KEY`) e nunca devolvidas pela API.
- Sessão por cookie `HttpOnly`; escritas exigem origem autorizada e o cabeçalho `X-Bros-Client` (proteção contra CSRF).
- O endereço do rastreador informado pelo usuário só é aceito em HTTPS e fora de redes internas (proteção contra SSRF). Redirecionamentos são recusados.
- Webhook por conexão com segredo próprio: `POST {BROS_PUBLIC_URL}/api/webhooks/<id>/<segredo>` (mostrado em `GET /api/tracker/status`). Ele só dispara uma sincronização. Aponte o encaminhamento de eventos do Traccar para ele para reduzir a espera.
- Tokens do Traccar não expiram sozinhos: se forem revogados, o app mostra "Reconecte o rastreador". Adaptadores com OAuth implementam `refreshCredentials`.

## Adicionar outra marca

Implemente `TrackerProvider` (`src/providers/types.ts`): `connect`, `disconnect`, `getDevice`, `getCurrentPosition`, `getOdometer`, `getTrips` e, se houver, `getTripPoints`, `refreshCredentials` e `subscribeToUpdates` (WebSocket). Registre em `src/providers/registry.ts`. O motor de sincronização e o app não mudam.

## Testes

`npm test` (Node 22.18+). Cobrem odômetro, viagens, duplicidade, GPS, conexão perdida, token vencido e renovado, dados inválidos, ausência de dados, CSRF, SSRF, webhook e o adaptador Traccar por HTTP (contra um servidor de teste que imita a API REST do Traccar).

## Limites desta versão

- Uma moto por conexão; a identidade é o cookie do navegador (sem login). Trocar de navegador exige conectar de novo.
- Tempo real: só consulta periódica (`BROS_POLL_INTERVAL_MS`) e webhook. O Traccar também oferece WebSocket, ainda não usado.
- Não foi testado contra um servidor Traccar real, só contra o servidor de teste.

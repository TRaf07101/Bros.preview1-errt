/**
 * Contrato que todo provedor de rastreamento precisa cumprir. O motor de
 * sincronização (sync/engine.ts) só conhece esta interface: nenhuma marca é
 * citada fora de src/providers/<marca>.ts.
 */

export type ProviderCredentials = Record<string, string>;

export interface ProviderSession {
  credentials: ProviderCredentials;
  deviceId: string;
}

export interface TrackerDevice {
  id: string;
  name: string;
  uniqueId?: string;
  /** Estado informado pela plataforma, apenas para exibição. */
  status?: string;
  lastUpdate?: string | null;
}

export interface TrackerPosition {
  at: string;
  latitude: number;
  longitude: number;
  /** km/h */
  speedKmh: number | null;
  /** O provedor afirma que o veículo está em movimento agora. */
  moving: boolean | null;
}

/**
 * hardware: contador do próprio veículo/rastreador (ex.: CAN, odômetro do módulo).
 * accumulated: soma de distância calculada pela plataforma a partir dos pontos GPS.
 */
export interface OdometerReading {
  meters: number;
  kind: 'hardware' | 'accumulated';
  at: string;
}

export interface TrackerTrip {
  /** Identificador estável da viagem no provedor. */
  id: string;
  startTime: string;
  endTime: string;
  distanceMeters: number | null;
  startOdometerMeters: number | null;
  endOdometerMeters: number | null;
  averageSpeedKmh: number | null;
}

export interface TrackerPoint { at: string; latitude: number; longitude: number; speedKmh: number | null; valid: boolean }

export interface ConnectInput { fields: Record<string, string> }
export interface ConnectResult {
  credentials: ProviderCredentials;
  devices: TrackerDevice[];
}

export interface ProviderField { key: string; label: string; type: 'url' | 'secret' | 'text'; placeholder?: string; help?: string }
export interface ProviderInfo { id: string; label: string; fields: ProviderField[]; help: string }

export type Unsubscribe = () => void;

export interface TrackerProvider {
  readonly info: ProviderInfo;
  /** Valida as credenciais informadas e lista os rastreadores da conta. */
  connect(input: ConnectInput): Promise<ConnectResult>;
  /** Revoga o que for possível no provedor. Falhas aqui não impedem a desconexão local. */
  disconnect(session: ProviderSession): Promise<void>;
  getDevice(session: ProviderSession): Promise<TrackerDevice>;
  getCurrentPosition(session: ProviderSession): Promise<TrackerPosition | null>;
  getOdometer(session: ProviderSession): Promise<OdometerReading | null>;
  getTrips(session: ProviderSession, from: Date, to: Date): Promise<TrackerTrip[]>;
  /** Opcional: pontos GPS de um período, usados só quando a viagem vem sem distância. */
  getTripPoints?(session: ProviderSession, from: Date, to: Date): Promise<TrackerPoint[]>;
  /** Opcional: provedores com OAuth renovam aqui. Retorne null se não for possível. */
  refreshCredentials?(session: ProviderSession): Promise<ProviderCredentials | null>;
  /**
   * Opcional: assina eventos em tempo real (WebSocket etc.). Retorne null quando o
   * provedor só oferece consulta periódica; o servidor então usa polling e o
   * endpoint de webhook.
   */
  subscribeToUpdates?(session: ProviderSession, onChange: () => void): Promise<Unsubscribe | null>;
}

/** Credencial recusada ou vencida: o usuário precisa reconectar. */
export class ProviderAuthError extends Error {
  constructor(message = 'Credencial recusada pelo provedor.') { super(message); this.name = 'ProviderAuthError'; }
}
/** Falha temporária (rede, 5xx, limite de requisições). Tentar de novo mais tarde. */
export class ProviderUnavailableError extends Error {
  constructor(message = 'O provedor não respondeu.') { super(message); this.name = 'ProviderUnavailableError'; }
}
/** O provedor respondeu, mas os dados não fazem sentido. */
export class ProviderDataError extends Error {
  constructor(message = 'O provedor enviou dados inválidos.') { super(message); this.name = 'ProviderDataError'; }
}
/** Entrada do usuário inválida (endereço, token vazio...). */
export class ProviderInputError extends Error {
  constructor(message: string) { super(message); this.name = 'ProviderInputError'; }
}

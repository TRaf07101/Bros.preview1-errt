import type { Config } from '../config.ts';
import { createTraccarProvider } from './traccar.ts';
import type { TrackerProvider } from './types.ts';

export type ProviderRegistry = Map<string, TrackerProvider>;

/** Para ativar outra marca, implemente TrackerProvider e registre aqui. */
export function buildRegistry(config: Pick<Config, 'allowPrivateProviderHosts'>): ProviderRegistry {
  const registry: ProviderRegistry = new Map();
  const traccar = createTraccarProvider({ allowPrivateHosts: config.allowPrivateProviderHosts });
  registry.set(traccar.info.id, traccar);
  return registry;
}

import { assertSafeProviderUrl } from './net.ts';
import {
  ProviderAuthError, ProviderDataError, ProviderInputError, ProviderUnavailableError,
  type ConnectInput, type ConnectResult, type OdometerReading, type ProviderSession, type TrackerDevice,
  type TrackerPoint, type TrackerPosition, type TrackerProvider, type TrackerTrip,
} from './types.ts';

/**
 * Adaptador do Traccar (https://www.traccar.org), plataforma aberta de rastreamento usada
 * com centenas de modelos de rastreador. Endpoints usados, todos da API REST documentada:
 *   GET /api/devices, GET /api/positions, GET /api/reports/trips
 * Autenticação: token de acesso gerado pelo usuário em Traccar > Conta > Token.
 * Unidades do Traccar: distâncias em metros, velocidade em nós.
 */
const KNOTS_TO_KMH = 1.852;
const TIMEOUT_MS = 15000;

interface TraccarDevice { id: number; name: string; uniqueId?: string; status?: string; lastUpdate?: string | null }
interface TraccarPosition { id: number; deviceId: number; fixTime: string; deviceTime?: string; latitude: number; longitude: number; speed?: number; valid?: boolean; attributes?: Record<string, unknown> }
interface TraccarTrip { deviceId: number; startTime: string; endTime: string; distance?: number; averageSpeed?: number; startOdometer?: number; endOdometer?: number }

const num = (value: unknown): number | null => typeof value === 'number' && Number.isFinite(value) ? value : null;

export interface TraccarOptions { allowPrivateHosts: boolean; fetchImpl?: typeof fetch }

export function createTraccarProvider(options: TraccarOptions): TrackerProvider {
  const doFetch = options.fetchImpl || fetch;

  async function request<T>(serverUrl: string, token: string, path: string, query: Record<string, string> = {}): Promise<T> {
    const base = await assertSafeProviderUrl(serverUrl, options.allowPrivateHosts);
    const url = new URL(base.href.replace(/\/$/, '') + path);
    for (const [key, value] of Object.entries(query)) url.searchParams.set(key, value);
    let response: Response;
    try {
      response = await doFetch(url, { headers: { Authorization: `Bearer ${token}`, Accept: 'application/json' }, signal: AbortSignal.timeout(TIMEOUT_MS), redirect: 'error' });
    } catch (error) {
      throw new ProviderUnavailableError(error instanceof Error && error.name === 'TimeoutError' ? 'O rastreador demorou demais para responder.' : 'Não foi possível falar com o servidor do rastreador.');
    }
    if (response.status === 401 || response.status === 403) throw new ProviderAuthError('O servidor do rastreador recusou o acesso. O token pode ter vencido ou sido removido.');
    if (response.status === 429 || response.status >= 500) throw new ProviderUnavailableError(`O servidor do rastreador está indisponível (${response.status}).`);
    if (!response.ok) throw new ProviderDataError(`Resposta inesperada do servidor do rastreador (${response.status}).`);
    try { return await response.json() as T; } catch { throw new ProviderDataError('O servidor do rastreador não enviou JSON.'); }
  }

  const creds = (session: ProviderSession) => {
    const { serverUrl, token } = session.credentials;
    if (!serverUrl || !token) throw new ProviderAuthError('Credenciais do rastreador ausentes.');
    return { serverUrl, token };
  };
  const toDevice = (item: TraccarDevice): TrackerDevice => ({ id: String(item.id), name: item.name, uniqueId: item.uniqueId, status: item.status, lastUpdate: item.lastUpdate ?? null });

  const provider: TrackerProvider = {
    info: {
      id: 'traccar',
      label: 'Traccar',
      help: 'Funciona com rastreadores cadastrados em um servidor Traccar (próprio ou de um provedor). No Traccar, abra Conta e gere um token de acesso.',
      fields: [
        { key: 'serverUrl', label: 'Endereço do servidor', type: 'url', placeholder: 'https://rastreador.exemplo.com' },
        { key: 'token', label: 'Token de acesso', type: 'secret', help: 'O token fica guardado só no servidor do bros., cifrado. O app não o guarda.' },
      ],
    },

    async connect(input: ConnectInput): Promise<ConnectResult> {
      const serverUrl = (input.fields.serverUrl || '').trim();
      const token = (input.fields.token || '').trim();
      if (!serverUrl) throw new ProviderInputError('Informe o endereço do servidor do rastreador.');
      if (token.length < 8) throw new ProviderInputError('Informe o token de acesso do Traccar.');
      const safe = await assertSafeProviderUrl(serverUrl, options.allowPrivateHosts);
      const normalized = safe.href.replace(/\/$/, '');
      const devices = await request<TraccarDevice[]>(normalized, token, '/api/devices');
      if (!Array.isArray(devices)) throw new ProviderDataError('Lista de rastreadores inválida.');
      if (!devices.length) throw new ProviderInputError('Essa conta não tem nenhum rastreador cadastrado.');
      return { credentials: { serverUrl: normalized, token }, devices: devices.map(toDevice) };
    },

    async disconnect() { /* Tokens do Traccar são revogados pelo usuário no próprio Traccar. */ },

    async getDevice(session) {
      const { serverUrl, token } = creds(session);
      const list = await request<TraccarDevice[]>(serverUrl, token, '/api/devices', { id: session.deviceId });
      const found = Array.isArray(list) ? list.find(item => String(item.id) === session.deviceId) : undefined;
      if (!found) throw new ProviderDataError('O rastreador escolhido não existe mais nessa conta.');
      return toDevice(found);
    },

    async getCurrentPosition(session): Promise<TrackerPosition | null> {
      const position = await latestPosition(session);
      if (!position) return null;
      const speed = num(position.speed);
      const motion = typeof position.attributes?.motion === 'boolean' ? position.attributes.motion : null;
      return { at: position.fixTime, latitude: position.latitude, longitude: position.longitude, speedKmh: speed === null ? null : speed * KNOTS_TO_KMH, moving: motion ?? (speed === null ? null : speed * KNOTS_TO_KMH > 3) };
    },

    async getOdometer(session): Promise<OdometerReading | null> {
      const position = await latestPosition(session);
      if (!position) return null;
      const attributes = position.attributes || {};
      const hardware = num(attributes.odometer);
      if (hardware !== null && hardware >= 0) return { meters: hardware, kind: 'hardware', at: position.fixTime };
      const total = num(attributes.totalDistance);
      if (total !== null && total >= 0) return { meters: total, kind: 'accumulated', at: position.fixTime };
      return null;
    },

    async getTrips(session, from, to): Promise<TrackerTrip[]> {
      const { serverUrl, token } = creds(session);
      const trips = await request<TraccarTrip[]>(serverUrl, token, '/api/reports/trips', { deviceId: session.deviceId, from: from.toISOString(), to: to.toISOString() });
      if (!Array.isArray(trips)) throw new ProviderDataError('Lista de viagens inválida.');
      return trips.filter(trip => trip && typeof trip.startTime === 'string' && typeof trip.endTime === 'string').map(trip => ({
        // O Traccar não numera viagens: o início identifica a viagem de forma estável.
        id: `${trip.deviceId ?? session.deviceId}:${new Date(trip.startTime).toISOString()}`,
        startTime: new Date(trip.startTime).toISOString(),
        endTime: new Date(trip.endTime).toISOString(),
        distanceMeters: num(trip.distance),
        startOdometerMeters: num(trip.startOdometer),
        endOdometerMeters: num(trip.endOdometer),
        averageSpeedKmh: num(trip.averageSpeed) === null ? null : num(trip.averageSpeed)! * KNOTS_TO_KMH,
      }));
    },

    async getTripPoints(session, from, to): Promise<TrackerPoint[]> {
      const { serverUrl, token } = creds(session);
      const positions = await request<TraccarPosition[]>(serverUrl, token, '/api/positions', { deviceId: session.deviceId, from: from.toISOString(), to: to.toISOString() });
      if (!Array.isArray(positions)) throw new ProviderDataError('Lista de posições inválida.');
      return positions.map(item => ({ at: item.fixTime, latitude: item.latitude, longitude: item.longitude, speedKmh: num(item.speed) === null ? null : num(item.speed)! * KNOTS_TO_KMH, valid: item.valid !== false }));
    },

    // O Traccar não renova tokens: quando vence, o usuário gera outro. Sem refreshCredentials.
    // Tempo real: o Traccar oferece WebSocket e encaminhamento de eventos, mas esta versão usa
    // consulta periódica + o endpoint de webhook do servidor.
    async subscribeToUpdates() { return null; },
  };

  async function latestPosition(session: ProviderSession): Promise<TraccarPosition | null> {
    const { serverUrl, token } = creds(session);
    const positions = await request<TraccarPosition[]>(serverUrl, token, '/api/positions', { deviceId: session.deviceId });
    if (!Array.isArray(positions)) throw new ProviderDataError('Lista de posições inválida.');
    return positions.find(item => String(item.deviceId) === session.deviceId) || null;
  }

  return provider;
}

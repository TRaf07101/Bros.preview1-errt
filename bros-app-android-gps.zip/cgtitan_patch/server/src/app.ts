import { createServer, type Server } from 'node:http';
import type { Config } from './config.ts';
import { randomToken, safeEqual, sha256 } from './crypto.ts';
import type { Db } from './db.ts';
import { HttpError, Router, cookieHeader, parseCookies, rateLimiter, readJson, send, type Ctx } from './http.ts';
import type { ProviderRegistry } from './providers/registry.ts';
import { ProviderAuthError, ProviderDataError, ProviderInputError, ProviderUnavailableError } from './providers/types.ts';
import { open, seal } from './crypto.ts';
import type { ConnectionRow, SyncEngine } from './sync/engine.ts';
import { linkTracker } from './sync/link.ts';

const COOKIE = 'bros_sid';
const YEAR = 365 * 24 * 3600;
const DRAFT_TTL_MS = 10 * 60 * 1000;

const PENDING_COPY: Record<string, string> = {
  odometer_decreased: 'O contador do rastreador diminuiu. Pode ter sido trocado ou zerado. Nenhum quilômetro foi somado.',
  insufficient_data: 'Os dados da viagem não bastam para calcular a distância com segurança. Nenhum quilômetro foi somado.',
  implausible_distance: 'A distância informada parece alta demais para o tempo decorrido. Nenhum quilômetro foi somado até você conferir.',
};

export interface AppDeps { config: Config; db: Db; registry: ProviderRegistry; engine: SyncEngine; now?: () => Date }

export function createApp({ config, db, registry, engine, now = () => new Date() }: AppDeps): Server {
  const router = new Router();
  const limitAuth = rateLimiter(12, 60_000);

  const userFrom = (ctx: Ctx, create: boolean): { id: number; setCookie?: string } | null => {
    const sid = parseCookies(ctx.req.headers.cookie)[COOKIE];
    if (sid) {
      const found = db.prepare('SELECT id FROM users WHERE sid_hash = ?').get(sha256(sid)) as unknown as { id: number } | undefined;
      if (found) return { id: found.id };
    }
    if (!create) return null;
    const fresh = randomToken(32);
    const result = db.prepare('INSERT INTO users (sid_hash, created_at) VALUES (?, ?)').run(sha256(fresh), now().toISOString());
    return { id: Number(result.lastInsertRowid), setCookie: cookieHeader(COOKIE, fresh, config, YEAR) };
  };
  const need = (ctx: Ctx) => { const user = userFrom(ctx, false); if (!user) throw new HttpError(401, 'Nenhum rastreador conectado neste navegador.'); return user; };
  const connectionOf = (userId: number) => db.prepare('SELECT * FROM connections WHERE user_id = ?').get(userId) as unknown as ConnectionRow | undefined;
  const obj = (value: unknown): Record<string, unknown> => { if (!value || typeof value !== 'object' || Array.isArray(value)) throw new HttpError(400, 'Corpo inválido.'); return value as Record<string, unknown>; };
  const clientIp = (ctx: Ctx) => String(ctx.req.socket.remoteAddress || 'unknown');

  function statusPayload(row: ConnectionRow | undefined) {
    if (!row) return { connection: null, events: [], pending: [] };
    const providerLabel = registry.get(row.provider)?.info.label || row.provider;
    const events = db.prepare("SELECT * FROM sync_events WHERE connection_id = ? AND status = 'ready' ORDER BY deliver_seq").all(row.id) as unknown as Array<Record<string, number | string | null>>;
    const pending = db.prepare("SELECT * FROM sync_events WHERE connection_id = ? AND status = 'pending' ORDER BY id").all(row.id) as unknown as Array<Record<string, number | string | null>>;
    return {
      connection: {
        provider: row.provider, providerLabel, deviceName: row.device_name, bikeLabel: row.bike_label,
        status: row.status, statusMessage: row.status_detail, odometerKind: row.odometer_kind,
        syncedKm: Math.round(row.bike_km_synced * 1000) / 1000, linkedAt: row.linked_at, lastSyncAt: row.last_sync_at,
        webhookUrl: config.publicUrl ? `${config.publicUrl}/api/webhooks/${row.id}/${row.webhook_secret}` : null,
      },
      events: events.map(event => ({
        seq: event.deliver_seq, id: event.id, distanceMeters: Math.round(Number(event.distance_m)), kmBefore: event.km_before, kmAfter: event.km_after,
        tripStart: event.trip_start, tripEnd: event.trip_end, tripIds: JSON.parse(String(event.trip_ids_json)), source: event.data_source, syncedAt: event.synced_at,
      })),
      pending: pending.map(event => ({
        id: event.id, reason: event.reason, message: PENDING_COPY[String(event.reason)] || 'Os dados precisam de conferência.',
        distanceKm: Math.round(Number(event.distance_m)) / 1000, syncedAt: event.synced_at,
        canApply: event.reason === 'implausible_distance' && Number(event.distance_m) > 0,
      })),
    };
  }

  router.add('GET', '/api/health', () => ({ ok: true }));
  router.add('GET', '/api/tracker/providers', () => ({ providers: [...registry.values()].map(provider => provider.info) }));

  router.add('POST', '/api/tracker/discover', async ctx => {
    if (!limitAuth(clientIp(ctx))) throw new HttpError(429, 'Muitas tentativas. Aguarde um minuto.');
    const body = obj(ctx.body);
    const provider = registry.get(String(body.provider));
    if (!provider) throw new HttpError(400, 'Esse tipo de rastreador ainda não é compatível.');
    const fields = Object.fromEntries(Object.entries(obj(body.fields)).map(([k, v]) => [k, String(v)]));
    const result = await provider.connect({ fields });
    const user = userFrom(ctx, true)!;
    db.prepare('DELETE FROM drafts WHERE user_id = ? OR expires_at < ?').run(user.id, now().toISOString());
    const draftId = randomToken(18);
    db.prepare('INSERT INTO drafts (id, user_id, provider, creds_sealed, devices_json, expires_at) VALUES (?,?,?,?,?,?)')
      .run(draftId, user.id, provider.info.id, seal(JSON.stringify(result.credentials), config.secretKey), JSON.stringify(result.devices), new Date(now().getTime() + DRAFT_TTL_MS).toISOString());
    return { value: { draftId, devices: result.devices }, headers: user.setCookie ? { 'Set-Cookie': user.setCookie } : {} };
  });

  router.add('POST', '/api/tracker/connect', async ctx => {
    const user = need(ctx);
    const body = obj(ctx.body);
    const draft = db.prepare('SELECT * FROM drafts WHERE id = ? AND user_id = ?').get(String(body.draftId), user.id) as unknown as { provider: string; creds_sealed: string; devices_json: string; expires_at: string } | undefined;
    if (!draft || draft.expires_at < now().toISOString()) throw new HttpError(410, 'A conexão expirou. Comece de novo.');
    const devices = JSON.parse(draft.devices_json) as Array<{ id: string }>;
    const deviceId = String(body.deviceId);
    if (!devices.some(item => item.id === deviceId)) throw new HttpError(400, 'Escolha um dos rastreadores da lista.');
    const bikeKm = Number(body.bikeKm);
    if (!Number.isFinite(bikeKm) || bikeKm < 0 || bikeKm > 999999) throw new HttpError(400, 'Informe a quilometragem atual da moto antes de conectar.');
    const bikeLabel = String(body.bikeLabel || 'Minha moto').slice(0, 80);
    const provider = registry.get(draft.provider)!;
    const id = await linkTracker(db, config, { userId: user.id, provider, credentials: JSON.parse(open(draft.creds_sealed, config.secretKey)), deviceId, bikeKm, bikeLabel }, now());
    db.prepare('DELETE FROM drafts WHERE user_id = ?').run(user.id);
    await engine.sync(id);
    return statusPayload(connectionOf(user.id));
  });

  router.add('GET', '/api/tracker/status', ctx => {
    const user = userFrom(ctx, false);
    return statusPayload(user ? connectionOf(user.id) : undefined);
  });

  router.add('POST', '/api/tracker/sync', async ctx => {
    const user = need(ctx);
    const row = connectionOf(user.id);
    if (!row) throw new HttpError(404, 'Nenhum rastreador conectado.');
    if (row.status !== 'reauth_required') await engine.sync(row.id);
    return statusPayload(connectionOf(user.id));
  });

  router.add('POST', '/api/tracker/ack', ctx => {
    const user = need(ctx);
    const row = connectionOf(user.id);
    if (!row) throw new HttpError(404, 'Nenhum rastreador conectado.');
    const upTo = Number(obj(ctx.body).upToSeq);
    if (!Number.isInteger(upTo) || upTo < 0) throw new HttpError(400, 'Sequência inválida.');
    db.prepare("UPDATE sync_events SET status = 'applied' WHERE connection_id = ? AND status = 'ready' AND deliver_seq <= ?").run(row.id, upTo);
    return statusPayload(connectionOf(user.id));
  });

  router.add('POST', '/api/tracker/events/:id/resolve', ctx => {
    const user = need(ctx);
    const row = connectionOf(user.id);
    if (!row) throw new HttpError(404, 'Nenhum rastreador conectado.');
    const action = obj(ctx.body).action;
    if (action !== 'apply' && action !== 'discard') throw new HttpError(400, 'Ação inválida.');
    const result = engine.resolvePending(row.id, Number(ctx.params.id), action);
    if (!result.ok) throw new HttpError(409, result.message);
    return statusPayload(connectionOf(user.id));
  });

  router.add('DELETE', '/api/tracker/connection', async ctx => {
    const user = need(ctx);
    const row = connectionOf(user.id);
    if (row) {
      const provider = registry.get(row.provider);
      await provider?.disconnect(engine.sessionOf(row)).catch(() => {});
      db.prepare('DELETE FROM connections WHERE id = ?').run(row.id);
    }
    db.prepare('DELETE FROM drafts WHERE user_id = ?').run(user.id);
    return statusPayload(undefined);
  });

  // Eventos enviados pelo provedor (ex.: encaminhamento de eventos do Traccar). Só dispara uma sincronização.
  const lastHook = new Map<string, number>();
  router.add('POST', '/api/webhooks/:id/:secret', ctx => {
    const row = db.prepare('SELECT * FROM connections WHERE id = ?').get(ctx.params.id) as unknown as ConnectionRow | undefined;
    if (!row || !safeEqual(row.webhook_secret, ctx.params.secret)) throw new HttpError(404, 'Não encontrado.');
    const last = lastHook.get(row.id) || 0;
    if (Date.now() - last > 5000) { lastHook.set(row.id, Date.now()); void engine.sync(row.id); }
    return { value: { accepted: true }, status: 202 };
  }, true);

  return createServer(async (req, res) => {
    const url = new URL(req.url || '/', 'http://localhost');
    const origin = req.headers.origin ? String(req.headers.origin).replace(/\/$/, '') : '';
    const found = router.match(req.method || 'GET', url.pathname);
    const isRaw = found?.route.raw ?? false;
    const allowedOrigin = origin && config.allowedOrigins.includes(origin) ? origin : '';
    const cors: Record<string, string> = allowedOrigin ? { 'Access-Control-Allow-Origin': allowedOrigin, 'Access-Control-Allow-Credentials': 'true', Vary: 'Origin' } : { Vary: 'Origin' };
    try {
      if (req.method === 'OPTIONS') {
        if (!allowedOrigin) return send(res, 403, { error: 'Origem não autorizada.' });
        return send(res, 204, undefined, { ...cors, 'Access-Control-Allow-Methods': 'GET, POST, DELETE', 'Access-Control-Allow-Headers': 'Content-Type, X-Bros-Client', 'Access-Control-Max-Age': '600' });
      }
      if (!found) return send(res, 404, { error: 'Não encontrado.' }, cors);
      if (!isRaw && req.method !== 'GET') {
        // Proteção contra CSRF: o cookie é enviado entre sites, então exigimos origem autorizada e cabeçalho próprio.
        if (!allowedOrigin || req.headers['x-bros-client'] !== '1') throw new HttpError(403, 'Origem não autorizada.');
      }
      const body = req.method === 'GET' || req.method === 'DELETE' ? {} : await readJson(req);
      const out = await found.route.handler({ req, res, url, params: found.params, body, config });
      const wrapped = out && typeof out === 'object' && 'value' in (out as object) ? out as { value: unknown; headers?: Record<string, string>; status?: number } : { value: out };
      send(res, wrapped.status || 200, wrapped.value, { ...(isRaw ? {} : cors), ...(wrapped.headers || {}) });
    } catch (error) {
      const status = error instanceof HttpError ? error.status
        : error instanceof ProviderInputError ? 400
        : error instanceof ProviderAuthError ? 401
        : error instanceof ProviderUnavailableError ? 502
        : error instanceof ProviderDataError ? 502 : 500;
      const message = error instanceof Error && status !== 500 ? error.message : 'Erro interno.';
      if (status === 500) console.error(error);
      send(res, status, { error: message, code: error instanceof ProviderAuthError ? 'provider_auth' : undefined }, isRaw ? {} : cors);
    }
  });
}

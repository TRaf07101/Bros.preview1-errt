import type { Config } from './config.ts';
import type { Db } from './db.ts';
import type { SyncEngine } from './sync/engine.ts';

/** Sincronização em segundo plano: roda no servidor, com o app fechado. */
export function startScheduler(db: Db, engine: SyncEngine, config: Config, log: (message: string) => void = () => {}) {
  const tickMs = Math.min(15000, config.pollIntervalMs);
  let busy = false;
  const tick = async () => {
    if (busy) return; busy = true;
    try {
      const due = db.prepare("SELECT id FROM connections WHERE status != 'reauth_required' AND (next_attempt_at IS NULL OR next_attempt_at <= ?) ORDER BY next_attempt_at LIMIT 20").all(new Date().toISOString()) as unknown as Array<{ id: string }>;
      for (let i = 0; i < due.length; i += 4) {
        await Promise.all(due.slice(i, i + 4).map(item => engine.sync(item.id).catch(error => log(`sync ${item.id}: ${error instanceof Error ? error.message : String(error)}`))));
      }
    } finally { busy = false; }
  };
  const timer = setInterval(() => void tick(), tickMs);
  timer.unref();
  return { tick, stop: () => clearInterval(timer) };
}

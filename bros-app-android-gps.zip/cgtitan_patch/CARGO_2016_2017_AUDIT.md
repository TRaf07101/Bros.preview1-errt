# Auditoria Cargo ESDi 2016 e 2017

**Fonte usada:** Manual do Proprietário Honda CG 160 Cargo ESDi (2016), D2203-MAN-1026, lido por completo.
Tabela de manutenção nas páginas impressas 34 a 37.

- **2016:** manual do próprio ano.
- **2017:** não foi localizado manual específico (existem manuais 2017 da Fan/Titan e da Start, mas não da Cargo).
  O de 2016 é a edição mais próxima; os prazos de 2017 podem diferir em algum item.
- **Versão no app:** ESD (disco dianteiro). A Cargo ESDi não tem CBS nem ABS: freio dianteiro a disco e traseiro a tambor.
- **Cor branca (única):** é o padrão da Cargo em todos os anos; não foi achada fonte específica de cor para 2016/2017.
- **Foto:** reaproveita a foto oficial da Cargo branca atual (não foi achada foto de 2016/2017).
- **Pressão e profundidade mínima dos pneus:** ficam na tabela de especificações (p. 102), que não foi lida; o app manda
  conferir no manual em vez de repetir valores de outro modelo.

## A tabela de manutenção é igual à da Cargo 2018/2019. O que muda no manual de 2016
| Item | Cargo 2018/2019 (CBS) | Cargo ESDi 2016/2017 |
|---|---|---|
| Freios | CBS | sem CBS, sem ABS |
| Nível do fluido | dianteiro (LWR) e CBS (LOWER/UPPER) | só dianteiro (LWR) |
| Fluido de freio | Mobil Super Moto DOT 4 | Honda DOT 3 ou DOT 4 |
| Corrente de reposição | DID 428HX ou RK 428HSB | DID 428HX |
| Óleo do motor | SAE 10W-30 **SL** | SAE 10W-30 **SJ** |

## Correção também aplicada às Cargo 2018, 2019 e 2020
O texto do óleo citava "Pro Honda", termo do manual da Fan. Agora segue o manual da Cargo:
"óleo genuíno Honda, SAE 10W-30 SL, JASO MA", troca de 1,0 litro.

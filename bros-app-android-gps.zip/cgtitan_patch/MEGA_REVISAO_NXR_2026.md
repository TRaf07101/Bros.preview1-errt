# NXR 160 Bros 2026 — revisão de integração

## Identificação oficial
- Modelo: Honda NXR 160 Bros 2026.
- Versões: CBS e ABS.
- CBS 2026: Azul e Vermelho.
- ABS 2026: Cinza e Vermelho.
- Fonte oficial: Honda Sala de Imprensa, release de 04/08/2025 sobre o modelo 2026.

## Manutenção
A comunicação oficial de 2026 informa que a atualização do ano-modelo está centrada na nova proposta de cor para a CBS. A integração do app mantém a base técnica do Manual do Proprietário NXR 160 Bros 2025 para manutenção, sem inventar um manual 2026 específico.

## Fotos
As quatro combinações 2026 utilizam arquivos locais existentes do conjunto 2025/2026:
- CBS Azul -> bros-2025-2026-cbs-azul.webp
- CBS Vermelho -> bros-2025-2026-cbs-vermelha.webp
- ABS Cinza -> bros-2025-2026-abs-cinza.webp
- ABS Vermelho -> bros-2025-2026-abs-vermelha.webp

Todos os quatro arquivos têm 1536x1024, canal alfa e cantos transparentes. Não dependem de URL remota para carregar no catálogo 2026.

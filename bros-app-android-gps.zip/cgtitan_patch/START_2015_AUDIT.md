# CG 150 Start 2015 — auditoria

Geração anterior à CG 160 Start (2026). Id novo: `START-2015`, variante única `ES`, cores Preta e Vermelha, freios a tambor.

## Fonte
- Manual do Proprietário "CG150 Start" (2015), lido pelo **texto** (não como imagem):
  https://www.honda.com.br/pos-venda/sites/customer_service_motos/files/manuais/CG%20150%20Start%202015.pdf
- Certificado de garantia, Tabela de Manutenção (páginas impressas 34 a 37) e procedimentos até a página 81.

## Ciclo
1.000 km / 6 meses → 4.000 km / 12 meses → a cada 4.000 km (como a Cargo 150). Reaproveita `usesCycle4000` em `planner.ts`.

## Intervalos (do texto da tabela)
Idênticos aos da Cargo 150 2015: linha de combustível, acelerador, respiro, válvulas, óleo (4.000 km), vela (verificar 4.000 / trocar 8.000), filtro de combustível 12.000, filtro de ar 16.000, tela e filtro centrífugo 12.000, fluido da suspensão e eixo do garfo traseiro 16.000, corrente e pneus a cada 1.000 km, fixações 8.000, coluna de direção 4.000 (lubrificar 12.000).

## Diferenças em relação à Cargo 150 2015
| Item | Start 2015 | Cargo 2015 |
|---|---|---|
| Freios | tambor nas duas rodas; alavanca dianteira 10–20 mm, pedal 20–30 mm | disco na frente |
| Fluido de freio | não há (serviços `brake-level` e `brake-fluid` ficam de fora) | DOT 4, 2 anos |
| Sapatas | verificar desgaste a cada 4.000 km | pastilhas + sapatas |
| Acelerador | folga 2–5 mm | 2–6 mm |
| Corrente de reposição | DID 428MX ou RK 428SB | DID 428MX-118LE ou RK 428SB-118LE |
| Carga | piloto e passageiro, máximo 161 kg | só piloto, 150 kg |
| Cavalete | só lateral | lateral e central |

Conferidos no texto e iguais à Cargo: óleo SAE 10W-30 SJ, 1,0 L na troca, 30 N·m no parafuso de drenagem, corrente 15–25 mm (limite 50 mm), 88 N·m no eixo traseiro, fluido do garfo 139,0 ± 2,5 cm³, folga da vela 0,80–0,90 mm, embreagem 10–20 mm.

## Pendências
- **Marcações por coluna** (1.000/4.000/8.000…): o texto do PDF não traz os quadrados. A etapa de 1.000 km usa a lista genérica (`first-review`, `chain`, `tires`, `oil-level`) e o aviso diz isso. Falta ler a tabela como imagem (páginas impressas 34 a 36).
- **Especificações Técnicas** (páginas 106 a 108): pressão e profundidade mínima dos pneus e modelo da vela não foram lidos; o plano remete ao manual em vez de copiar valores da Cargo ou da CG 160.
- **Cores**: Preto (NH-1) e Vermelho Guarau (R-239) vêm de um trecho do catálogo Honda ("CG150 Start ES, Modelo 2015") encontrado em site de terceiros; não foram confirmados no PDF do manual.
- **Foto**: não há imagem específica da Start 150; usa-se a foto da Start 160 de mesma cor como substituta.
- Se o PDF for enviado, as marcações e as especificações entram em `START_150_OVERRIDES` (`data.ts`).

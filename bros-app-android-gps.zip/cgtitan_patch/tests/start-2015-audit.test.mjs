import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';

const root = path.resolve(new URL('..', import.meta.url).pathname);
const read = f => fs.readFileSync(path.join(root, f), 'utf8');
const [types, models, data, planner, dialogs, shell, print] = ['src/maintenance/types.ts','src/maintenance/models.ts','src/maintenance/data.ts','src/maintenance/planner.ts','src/ui/Dialogs.tsx','src/ui/Shell.tsx','src/ui/PrintPlan.tsx'].map(read);

test('CG 150 Start 2015 é um modelo próprio (variante ES, duas cores, manual e telas)', () => {
  assert.match(types, /'START-2026' \| 'START-2022' \| 'START-2015'/);
  assert.match(models, /'START-2015': \['ES'\]/);
  assert.match(models, /'START-2015': \{\s*ES: options/);
  assert.match(models, /'START-2015': \{\s*ES: \{\s*preta:/);
  assert.match(planner, /CG 150 Start 2015/);
  assert.match(planner, /CG%20150%20Start%202015\.pdf/);
  assert.match(planner, /modelYear !== 'START-2022' && modelYear !== 'START-2015'/);
  assert.match(dialogs, /<option value="START-2015">2015<\/option>/);
  assert.match(dialogs, /selectedYear === 'START-2015'/);
  assert.match(shell, /'START-2015'/);
  assert.match(data, /START_2015_REFERENCE/);
  assert.match(data, /START_2015_SOURCE_SCOPE/);
});

test('Start 2015 usa o ciclo 1.000 / 4.000 km e a Start 2026 continua no ciclo de 6.000 km', () => {
  assert.match(planner, /usesCycle4000 = \(year: ModelYear\): boolean => \[[^\]]*'START-2015'\]/);
  assert.match(print, /profile\.year === 'START-2015'/);
  assert.doesNotMatch(planner, /usesCycle4000 = [^\n]*'START-2026'/);
});

test('Start 2015: sem fluido de freio (tambor), com intervalos da tabela e valores do manual', () => {
  const block = data.slice(data.indexOf('const START_150_IDS_2015'), data.indexOf('// Remove chaves undefined'));
  assert.match(block, /filter\(id => id !== 'brake-level' && id !== 'brake-fluid'\)/);
  assert.match(block, /folga da alavanca do freio dianteiro é de 10–20 mm e a do pedal do freio traseiro, de 20–30 mm/);
  assert.match(block, /folga no flange da manopla deve ser de 2–5 mm/);
  assert.match(block, /DID 428MX ou RK 428SB\./);
  assert.doesNotMatch(block, /118LE/);
  assert.match(block, /capacidade máxima de carga é de 161 kg/);
  assert.match(block, /Folga do eletrodo: 0,80–0,90 mm/);
});

test('Start 2015: pressão dos pneus e modelo da vela não foram copiados de outro modelo', () => {
  const block = data.slice(data.indexOf('const START_150_OVERRIDES'), data.indexOf('const START_150_2015:'));
  assert.doesNotMatch(block, /175 kPa|200 kPa|CPR8EA/);
  assert.match(block, /página 108/);
  assert.match(block, /página 107/);
  assert.match(planner, /As marcações da coluna de 1\.000 km da tabela não foram conferidas na imagem do manual/);
});

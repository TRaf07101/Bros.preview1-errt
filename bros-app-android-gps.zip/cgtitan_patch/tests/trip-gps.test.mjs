import assert from 'node:assert/strict';
import { after, test } from 'node:test';
import { createServer } from 'vite';

const server = await createServer({ server: { middlewareMode: true }, appType: 'custom' });
const { addFix, newTrack, haversine, normalizeTrack } = await server.ssrLoadModule('/src/trip/gps.ts');
after(async () => { await server.close(); });

const fix = (lat, lon, sec, acc = 5) => ({ lat, lon, t: sec * 1000, acc });
const run = (fixes) => fixes.reduce((track, f) => addFix(track, f), newTrack(0));

test('1 grau de latitude tem cerca de 111 km', () => { assert.ok(Math.abs(haversine({ lat: 0, lon: 0 }, { lat: 1, lon: 0 }) - 111195) < 200); });
test('soma o deslocamento real', () => { const t = run([fix(0, 0, 0), fix(0.001, 0, 10), fix(0.002, 0, 20)]); assert.ok(Math.abs(t.meters - 222.4) < 2); assert.equal(t.gaps, 0); });
test('ignora GPS parado (ruído)', () => { assert.equal(run([fix(0, 0, 0), fix(0.00002, 0, 5), fix(0, 0.00002, 10)]).meters, 0); });
test('ignora pontos imprecisos e inválidos', () => { assert.equal(run([fix(0, 0, 0), fix(0.01, 0, 10, 120), fix(NaN, 0, 20), fix(95, 0, 30)]).meters, 0); });
test('descarta salto impossível', () => { assert.equal(run([fix(0, 0, 0), fix(1, 0, 10)]).meters, 0); });
test('ignora ponto com horário repetido ou anterior', () => { assert.equal(run([fix(0, 0, 10), fix(0.001, 0, 10), fix(0.001, 0, 5)]).meters, 0); });
test('sinal perdido conta em linha reta e é sinalizado', () => { const t = run([fix(0, 0, 0), fix(0.01, 0, 200)]); assert.equal(t.gaps, 1); assert.ok(t.meters > 1000); });
test('normalizeTrack rejeita lixo e aceita viagem salva', () => { assert.equal(normalizeTrack({ meters: -1 }), null); assert.ok(normalizeTrack(JSON.parse(JSON.stringify(run([fix(0, 0, 0), fix(0.001, 0, 10)]))))); });

test('parar por muito tempo e voltar a andar não é sinal perdido', () => { const t = run([fix(0, 0, 0), fix(0.0002, 0, 600)]); assert.equal(t.gaps, 0); assert.ok(t.meters > 20); });

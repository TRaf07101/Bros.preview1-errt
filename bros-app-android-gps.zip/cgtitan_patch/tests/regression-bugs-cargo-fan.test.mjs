// Testes de comportamento (não só de texto) para os bugs 1-4 encontrados na auditoria.
// Rodam com: node --experimental-strip-types --test tests/regression-bugs-cargo-fan.test.mjs
import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
const read = p => readFileSync(new URL(`../${p}`, import.meta.url), 'utf8');
const data = read('src/maintenance/data.ts');
const planner = read('src/maintenance/planner.ts');

test('Fan 2013/2014: o spread dos overrides não apaga frequency/kmInterval (undefined)', () => {
  assert.match(data, /const definedOnly = /);
  assert.equal((data.match(/legacyOverrides: Partial<Service> = definedOnly\(\{/g) || []).length, 2);
});
test('Primeira revisão não entra nas revisões periódicas de 6.000 km em diante', () => {
  assert.match(planner, /item\.id !== 'first-review' && item\.kmInterval/);
});
test('cargoText filtra "nota N" sem diferenciar maiúsculas', () => {
  assert.match(data, /!\/\\bnotas\?\\s\+\\d\+\/i\.test\(part\)/);
});
test('manualUrl cobre CARGO-2025 (não cai no link genérico inexistente)', () => {
  assert.match(planner, /year === 'CARGO-2026' \|\| year === 'CARGO-2025'/);
});

import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';

const models = fs.readFileSync(new URL('../src/maintenance/models.ts', import.meta.url), 'utf8');
const image = fs.readFileSync(new URL('../src/ui/RemoteMotorcycleImage.tsx', import.meta.url), 'utf8');

const localAssets = ['bros-2023-2024-cbs-preta.webp','bros-2023-2024-cbs-vermelha.webp','bros-2023-2024-cbs-branca.webp'];
for (const asset of localAssets) assert(fs.existsSync(path.join(process.cwd(),'public/images/motorcycles', asset)), `missing ${asset}`);

const years = ['2013','2014','2015','2015/2016','2016','2016/2017','2017/2018','2018/2019','2019/2020','2020/2021','2021/2022','2022','2022/2023','2023/2024','2024/2025','2025/2026'];

test('escopo permanece NXR 2013+', () => {
  assert.ok(models.includes("'2013'"));
  assert.ok(!models.includes("'2011'"));
  assert.ok(!models.includes("'2012'"));
  for (const y of years) assert.ok(models.includes(`'${y}'`), `ano ausente: ${y}`);
});

test('foto remota permanece visível quando o processamento transparente falha', () => {
  assert.match(image, /const displaySource = processed \?\? visibleSource/);
  assert.match(image, /Clean product cutouts and historical photographs are both valid sources/);
  assert.match(image, /adaptive edge segmentation/);
});

test('processamento aceita recorte transparente e fotos históricas', () => {
  assert.match(image, /transparentRatio >= 0\.40 \|\| ratio >= 0\.40/);
  assert.match(image, /sampleBackgroundPalette/);
  assert.match(image, /canvas/i);
});

test('2014 mantém somente as cores históricas confirmadas', () => {
  const block = models.match(/'2014': \{(.*?)\n  '2015':/s)?.[1] ?? '';
  assert.match(block, /\['vermelha', 'Vermelha'/);
  assert.match(block, /\['branca', 'Branca'/);
  assert.match(block, /\['preta', 'Preta'/);
  assert.match(block, /\['azul'/);
});

test('2015 não confunde branco com vermelho', () => {
  assert.match(models, /\['branca', 'Branca\/Preta', '2015/);
  assert.match(models, /REMOTE:2015-BRANCA/);
  assert.match(models, /REMOTE:2015-PRETA/);
});

test('aliases de assets locais apontam para arquivos reais', () => {
  const aliasPaths = Array.from(models.matchAll(/'([0-9]{4}-[0-9]{4}\/[^']+)'/g)).map(m => m[1]);
  const unique = [...new Set(aliasPaths)];
  for (const alias of unique) {
    const normalized = alias.replaceAll('/', '-');
    const file = path.join(process.cwd(), 'public/images/motorcycles', `bros-${normalized}.webp`);
    assert.ok(fs.existsSync(file), `asset ausente para alias ${alias}`);
  }
});

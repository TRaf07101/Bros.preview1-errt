import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';

const read = (file) => fs.readFileSync(file, 'utf8');
const types = read('src/maintenance/types.ts');
const models = read('src/maintenance/models.ts');
const data = read('src/maintenance/data.ts');
const planner = read('src/maintenance/planner.ts');
const dialogs = read('src/ui/Dialogs.tsx');
const shell = read('src/ui/Shell.tsx');

test('Titan 2026 family is typed and selectable', () => {
  assert.match(types, /export type BikeFamily =[^;]*'TITAN'/);
  assert.match(types, /'TITAN-2026'/);
  assert.match(models, /'TITAN-2026': \{\s*ABS: options\(\[/s);
  assert.match(models, /TITAN-2026.*?\['ABS'\]|'TITAN-2026': \['ABS'\]/s);
  assert.match(dialogs, /\['TITAN','CG Titan 160'\]/);
});

test('Titan 2026 official colors and clean image sources are wired', () => {
  for (const color of ['preta', 'vermelha', 'cinza']) {
    assert.match(models, new RegExp(`TITAN-2026[\\s\\S]{0,1200}${color}`));
  }
  assert.match(models, /Imagem-Home-Honda-CG-160-Titan-Preto-Met%C3%A1lico\.webp/);
  assert.match(models, /Imagem-Home-Honda-CG-160-Titan-Vermelho-Met%C3%A1lico\.webp/);
  assert.match(models, /Imagem-Home-Honda-CG-160-Titan-Cinza-Met%C3%A1lico\.webp/);
});

test('Titan 2026 normalizes to ABS and uses its own model label and source references', () => {
  assert.match(planner, /rawFamily = p\.family === 'TITAN'/);
  assert.match(planner, /rawFamily === 'TITAN' && modelYear !== 'TITAN-2026'/);
  assert.match(planner, /year === 'TITAN-2026' \? 'CG 160 Titan 2026'/);
  assert.match(data, /TITAN_2026_REFERENCE/);
  assert.match(data, /TITAN_2026_MAINTENANCE_REFERENCE/);
  assert.match(data, /year === 'TITAN-2026'/);
});

test('Titan 2026 has explicit braking/source notes and hero identity', () => {
  assert.match(data, /A CG 160 Titan 2026 usa freios a disco nas duas rodas e ABS na roda dianteira/);
  assert.match(dialogs, /selectedYear === 'TITAN-2026'/);
  assert.match(shell, /state\.profile\.year === 'TITAN-2026'/);
  assert.match(shell, /CG 160 <span>Titan\.<\/span>/);
});

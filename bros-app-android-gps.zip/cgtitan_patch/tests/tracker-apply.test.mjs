import assert from 'node:assert/strict';
import { after, test } from 'node:test';
import { createServer } from 'vite';

const server = await createServer({ server: { middlewareMode: true }, appType: 'custom' });
const { defaultState } = await server.ssrLoadModule('/src/maintenance/planner.ts');
const { applyTrackerEvents, normalizeTracker } = await server.ssrLoadModule('/src/tracker/apply.ts');
const { reminderList } = await server.ssrLoadModule('/src/maintenance/planner.ts');
after(async () => { await server.close(); });

const LINK = '2026-10-04T10:00:00.000Z';
const bike = km => { const s = defaultState(); s.profile = { ...s.profile, km, configured: true }; return s; };
const event = (seq, meters, extra = {}) => ({ seq, id: seq, distanceMeters: meters, kmBefore: 10420, kmAfter: 10420 + meters / 1000, tripStart: '2026-10-04T10:10:00Z', tripEnd: '2026-10-04T10:40:00Z', tripIds: ['7:a'], source: 'hardware', syncedAt: '2026-10-04T11:30:00Z', ...extra });

test('soma a viagem na mesma fonte de quilometragem e registra a origem no histórico', () => {
  const result = applyTrackerEvents(bike(10420), LINK, [event(1, 18_700)]);
  assert.equal(result.state.profile.km, 10438);
  assert.ok(Math.abs(result.state.tracker.fraction - 0.7) < 1e-9);
  assert.ok(Math.abs(result.addedKm - 18.7) < 1e-9);
  const reading = result.state.mileageReadings.at(-1);
  assert.equal(reading.source, 'tracker'); assert.equal(reading.previousKm, 10420); assert.equal(reading.km, 10438);
  assert.match(reading.note, /18,7 km/);
});

test('a mesma atualização recebida de novo não soma duas vezes', () => {
  const once = applyTrackerEvents(bike(10420), LINK, [event(1, 18_700)]);
  const twice = applyTrackerEvents(once.state, LINK, [event(1, 18_700)]);
  assert.equal(twice.state.profile.km, 10438); assert.equal(twice.addedKm, 0);
  assert.equal(twice.state.mileageReadings.length, once.state.mileageReadings.length);
  assert.equal(twice.ackSeq, 1);
});

test('frações acumulam até completar um quilômetro, sem perder nem inventar', () => {
  let state = bike(1000);
  for (let seq = 1; seq <= 4; seq++) state = applyTrackerEvents(state, LINK, [event(seq, 400)]).state;
  assert.equal(state.profile.km, 1001); assert.ok(Math.abs(state.tracker.fraction - 0.6) < 1e-9);
});

test('ajuste manual do usuário continua valendo: soma a distância, não o total do servidor', () => {
  const adjusted = bike(10500);
  assert.equal(applyTrackerEvents(adjusted, LINK, [event(1, 10_000)]).state.profile.km, 10510);
});

test('reconectar (novo linkedAt) recomeça a sequência sem tocar na quilometragem', () => {
  const first = applyTrackerEvents(bike(100), LINK, [event(1, 5_000), event(2, 5_000)]).state;
  assert.equal(first.profile.km, 110);
  const second = applyTrackerEvents(first, '2026-11-01T00:00:00.000Z', [event(1, 3_000)]);
  assert.equal(second.state.profile.km, 113); assert.equal(second.state.tracker.appliedSeq, 1);
});

test('sem quilometragem cadastrada, nada é inventado', () => {
  const state = defaultState();
  const result = applyTrackerEvents(state, LINK, [event(1, 18_700)]);
  assert.equal(result.state.profile.km, 0); assert.equal(result.state.profile.configured, false); assert.equal(result.addedKm, 0);
});

test('limite de 999.999 km é respeitado', () => {
  const result = applyTrackerEvents(bike(999_999), LINK, [event(1, 5_000)]);
  assert.equal(result.state.profile.km, 999_999); assert.equal(result.skipped, 1);
});

test('lembretes e plano usam a quilometragem atualizada pelo rastreador', () => {
  const before = bike(900); before.profile.purchaseDate = '2026-09-01';
  const after = applyTrackerEvents(before, LINK, [event(1, 150_000)]).state;
  assert.equal(after.profile.km, 1050);
  const dueBefore = reminderList(before).find(item => item.kind === 'review');
  const dueAfter = reminderList(after).find(item => item.kind === 'review');
  assert.equal(dueBefore.km, 1000);
  assert.equal(dueAfter.due, true);   // passou de 1.000 km depois da sincronização
  assert.equal(dueBefore.due, false);
});

test('dados salvos antigos (sem tracker) carregam com valores seguros', () => {
  assert.deepEqual(normalizeTracker(undefined), { linkedAt: null, appliedSeq: 0, fraction: 0 });
  assert.deepEqual(normalizeTracker({ appliedSeq: -3, fraction: 7, linkedAt: 5 }), { linkedAt: null, appliedSeq: 0, fraction: 0 });
  assert.deepEqual(defaultState().tracker, { linkedAt: null, appliedSeq: 0, fraction: 0 });
});

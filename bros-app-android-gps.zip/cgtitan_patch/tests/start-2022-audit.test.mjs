import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';

const root = path.resolve(new URL('..', import.meta.url).pathname);
const read = f => fs.readFileSync(path.join(root, f), 'utf8');
const [types, models, data, planner, dialogs, shell] = ['src/maintenance/types.ts','src/maintenance/models.ts','src/maintenance/data.ts','src/maintenance/planner.ts','src/ui/Dialogs.tsx','src/ui/Shell.tsx'].map(read);

test('CG 160 Start 2022 é um modelo próprio (CBS, três cores, manual e telas)', () => {
  assert.match(types, /'START-2026' \| 'START-2022' \| 'START-2015'/);
  assert.match(models, /'START-2022': \['CBS'\]/);
  assert.match(models, /'START-2022': \{\s*CBS: options\(\[/s);
  assert.match(models, /Prata Metálico/);
  assert.match(models, /'START-2022': \{\s*CBS: \{\s*preta:/s);
  assert.match(planner, /CG 160 Start 2022/);
  assert.match(planner, /year === 'START-2026' \|\| year === 'START-2022'\s*\? 'https:\/\/www\.honda\.com\.br[^']*MAN-1261/);
  assert.match(planner, /modelYear !== 'START-2022'/);
  assert.match(dialogs, /<option value="START-2022">2022<\/option>/);
  assert.match(dialogs, /selectedYear === 'START-2022'/);
  assert.match(shell, /'START-2022'/);
  assert.match(data, /START_2022_REFERENCE/);
  assert.match(data, /START_2022_SOURCE_SCOPE/);
});

test('Start 2022 usa o ciclo de 6.000 km (não o de 4.000 km) e não é "moderna" (sem passo de 500 km)', () => {
  assert.doesNotMatch(planner, /usesCycle4000 = [^\n]*'START-2022'/);
  assert.doesNotMatch(planner, /year !== 'START-2022'/);
});

test('Start 2022: sem fluido de freio e com os intervalos/valores do manual D2203-MAN-1261', () => {
  const block = data.slice(data.indexOf('const START_160_IDS_2022'), data.indexOf('// Remove chaves undefined'));
  const ids = block.slice(0, block.indexOf('];'));
  assert.doesNotMatch(ids, /brake-level|brake-fluid/);
  assert.match(block, /DID 428DH ou RK 428HSB/);
  assert.match(block, /15–25 mm/);
  assert.match(block, /10–20 mm; folga na ponta do pedal: 20–30 mm/);
  assert.match(block, /2–5 mm/);
  assert.match(block, /SAE 10W-30 SL ou superior/);
  assert.match(block, /1,0 litro/);
  assert.match(block, /30 N·m/);
  assert.match(block, /0,80–0,90 mm/);
  assert.match(block, /18\.000 km/); // filtro de ar e lubrificação da direção
  assert.match(block, /24\.000 km/); // fluido do garfo e suspensão traseira
  assert.match(block, /161 kg/);
  assert.match(block, /steering: { frequency: 'A cada 6\.000 km'/);
});

test('Start 2022: pressão dos pneus e modelo da vela não foram copiados de outro modelo', () => {
  const block = data.slice(data.indexOf('const START_160_2022:'), data.indexOf('// Remove chaves undefined'));
  assert.doesNotMatch(block, /175 kPa|200 kPa|CPR8EA/);
  assert.match(block, /página 104/);
  assert.match(block, /página 103/);
  assert.match(planner, /As marcações por coluna da tabela[^']*não aparecem no texto do PDF/);
});

test('Start 2022: títulos das revisões seguem a tabela (vela/filtros 12.000, ar 18.000, suspensão 24.000)', () => {
  assert.match(planner, /const start2022Title/);
  assert.match(planner, /km % 24000 === 0 \? 'fluido da suspensão'/);
  assert.match(planner, /year === 'START-2022' \? start2022Title\(km\)/);
});

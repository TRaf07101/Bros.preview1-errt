import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';

const source = fs.readFileSync(new URL('../src/maintenance/planner.ts', import.meta.url), 'utf8');
const start = source.indexOf('export function milestoneAt(');
const end = source.indexOf('\n}\n\nexport function milestones(', start);
assert.ok(start >= 0 && end > start);
const milestone = source.slice(start, end + 2);

test('milestoneAt does not reference out-of-scope profile', () => {
  assert.doesNotMatch(milestone, /\bprofile\./, 'milestoneAt must use its year/variant parameters, not an undefined profile variable');
  assert.match(milestone, /year === '2021'/, '2021 branch must use the milestoneAt year parameter');
});

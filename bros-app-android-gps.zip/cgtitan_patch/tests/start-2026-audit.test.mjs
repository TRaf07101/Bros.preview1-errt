import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';

const types = fs.readFileSync('src/maintenance/types.ts', 'utf8');
const models = fs.readFileSync('src/maintenance/models.ts', 'utf8');
const data = fs.readFileSync('src/maintenance/data.ts', 'utf8');
const planner = fs.readFileSync('src/maintenance/planner.ts', 'utf8');
const dialogs = fs.readFileSync('src/ui/Dialogs.tsx', 'utf8');
const shell = fs.readFileSync('src/ui/Shell.tsx', 'utf8');

test('CG 160 Start 2026 is a distinct family/model with CBS', () => {
  assert.match(types, /BikeFamily = .*'START'/);
  assert.match(types, /'START-2026'/);
  assert.match(models, /'START-2026': \['CBS'\]/);
  assert.match(models, /'START-2026': \{\s*CBS: options\(\[/s);
  assert.match(models, /Azul Perolizado/);
  assert.match(models, /Vermelho Perolizado/);
  assert.match(models, /Preta/);
  assert.match(dialogs, /\['START','CG 150\/160 Start'\]/);
  assert.match(dialogs, /<option value="START-2026">2026<\/option>/);
  assert.match(shell, /START-2026/);
});

test('CG 160 Start 2026 uses concrete Honda image sources and maintenance references', () => {
  assert.match(models, /Imagem-home-visao-da-lateral-direita-da-honda-cg-160-start\.webp/);
  assert.match(models, /Imagem-Home-Honda-CG-160-Start-Preto\.webp/);
  assert.match(models, /Imagem-Home-Honda-CG-160-Start-Vermelho-Perolizado_0\.webp/);
  assert.match(data, /START_2026_REFERENCE/);
  assert.match(data, /START_MAINTENANCE_REFERENCE/);
  assert.match(planner, /START-2026/);
});

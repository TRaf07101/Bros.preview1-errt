import assert from 'node:assert/strict';
import { after, test } from 'node:test';
import { createServer } from 'vite';

const server = await createServer({ server: { middlewareMode: true }, appType: 'custom' });
const { defaultState } = await server.ssrLoadModule('/src/maintenance/planner.ts');
const { DAILY_CHECKLIST } = await server.ssrLoadModule('/src/maintenance/data.ts');
const { defaultReminderSettings, normalizeReminderSettings } = await server.ssrLoadModule('/src/reminders/preferences.ts');
const { notificationPlan, outsideQuietHours, localDay, shiftDays, calendarReminders, daysBetween } = await server.ssrLoadModule('/src/reminders/plan.ts');

after(async () => { await server.close(); });

const date = value => new Date(value);
const now = date('2026-03-02T08:00:00');
function example() {
  const state = defaultState();
  state.reminders.enabled = true;
  state.reminders.activatedAt = date('2026-03-01T08:00:00').toISOString();
  state.checklist.date = localDay(now);
  return state;
}

test('notifications require an explicit opt-in', () => {
  assert.equal(defaultReminderSettings().enabled, false);
  assert.equal(defaultState().reminders.enabled, false);
});

test('malformed preferences cannot introduce invalid times or empty weekday schedules', () => {
  const settings = normalizeReminderSettings({ checklist: { time: '29:77', days: [-1, 9] }, mileage: { everyDays: 0 } });
  assert.equal(settings.checklist.time, '07:30');
  assert.equal(settings.checklist.days.length, 7);
  assert.equal(settings.mileage.everyDays, 3);
});

test('ready-to-use mileage defaults do not overwrite a saved weekly preference', () => {
  assert.equal(defaultReminderSettings().mileage.everyDays, 3);
  assert.equal(defaultReminderSettings().mileage.time, '18:30');
  const previous = normalizeReminderSettings({ mileage: { everyDays: 7, time: '19:15' } });
  assert.equal(previous.mileage.everyDays, 7);
  assert.equal(previous.mileage.time, '19:15');
});

test('quiet hours move an evening notification into the next morning', () => {
  const adjusted = outsideQuietHours(date('2026-03-01T23:45:00'), defaultReminderSettings().quiet);
  assert.equal(localDay(adjusted), '2026-03-02');
  assert.equal(adjusted.getHours(), 7);
  assert.equal(adjusted.getMinutes(), 0);
});

test('a previous evening notification is preserved when recalculating before morning', () => {
  const state = example();
  state.reminders.activatedAt = date('2026-02-28T08:00:00').toISOString();
  state.reminders.checklist.time = '23:00';
  state.reminders.checklist.days = [0];
  const jobs = notificationPlan(state, date('2026-03-02T06:00:00'));
  const today = jobs.find(job => job.category === 'checklist' && localDay(new Date(job.at)) === '2026-03-02');
  assert.ok(today);
  assert.equal(new Date(today.at).getHours(), 7);
});

test('a completed checklist suppresses today, not tomorrow', () => {
  const state = example();
  state.checklist.checked = DAILY_CHECKLIST.map(item => item.id);
  const jobs = notificationPlan(state, now);
  assert.equal(jobs.some(job => job.key === `checklist:${localDay(now)}`), false);
  assert.equal(jobs.some(job => job.key === `checklist:${localDay(shiftDays(now, 1))}`), true);
});

test('a new mileage entry restarts only the personal mileage reminder', () => {
  const state = example();
  state.profile.configured = true;
  state.profile.km = 5200;
  state.profile.oilDate = '2026-02-01';
  state.mileageReadings = [{ id: 'reading', km: 5200, previousKm: 5100, createdAt: now.toISOString(), source: 'manual', note: '' }];
  const jobs = notificationPlan(state, now).filter(job => job.category === 'mileage');
  assert.ok(jobs.length);
  assert.equal(daysBetween(new Date(jobs[0].at), now), 3);
  assert.equal(state.profile.oilDate, '2026-02-01');
  assert.equal(state.records.length, 0);
});

test('snooze creates a next-day notice even when the ordinary recurrence is a week away', () => {
  const state = example();
  state.reminders.mileage.everyDays = 7;
  state.mileageReadings = [{ id: 'reading', km: 0, previousKm: null, createdAt: now.toISOString(), source: 'manual', note: '' }];
  const tomorrow = shiftDays(now, 1); tomorrow.setHours(18, 30, 0, 0);
  state.reminders.snoozed.mileage = tomorrow.toISOString();
  const jobs = notificationPlan(state, now);
  assert.equal(jobs.filter(job => job.key === `mileage:${localDay(tomorrow)}`).length, 1);
});

test('overdue reminder recurrence does not restart whenever the app opens', () => {
  const state = example();
  state.profile.configured = true;
  state.profile.km = 1000;
  const jobs = notificationPlan(state, now).filter(job => job.category === 'maintenance');
  assert.ok(jobs.length);
  assert.equal(localDay(new Date(jobs[0].at)), '2026-03-08');
  assert.equal(jobs.some(job => localDay(new Date(job.at)) === localDay(now)), false);
});

test('pausing only affects notice delivery, never original maintenance data', () => {
  const state = example();
  state.profile.oilDate = '2026-02-01';
  state.reminders.pausedUntil = shiftDays(now, 2).toISOString();
  const jobs = notificationPlan(state, now);
  assert.ok(jobs.every(job => Date.parse(job.at) >= Date.parse(state.reminders.pausedUntil)));
  assert.equal(state.profile.oilDate, '2026-02-01');
});

test('planned notification IDs are unique signed 32-bit integers', () => {
  const state = example();
  state.reminders.mileage.everyDays = 1;
  const jobs = notificationPlan(state, now);
  assert.equal(new Set(jobs.map(job => job.nativeId)).size, jobs.length);
  assert.ok(jobs.every(job => Number.isInteger(job.nativeId) && job.nativeId > 0 && job.nativeId <= 2147483647));
});

test('calendar export contains real display alarms and recurring events', () => {
  const calendar = calendarReminders(example(), 'https://example.com/', now).replace(/\r\n /g, '');
  assert.match(calendar, /BEGIN:VALARM/);
  assert.match(calendar, /ACTION:DISPLAY/);
  assert.match(calendar, /TRIGGER:PT0M/);
  assert.match(calendar, /RRULE:FREQ=DAILY;INTERVAL=3/);
  assert.match(calendar, /reminders\/mileage/);
});

test('calendar weekdays also move when quiet hours cross midnight', () => {
  const state = example();
  state.reminders.checklist.days = [1];
  state.reminders.checklist.time = '23:00';
  const calendar = calendarReminders(state, 'https://example.com/', now).replace(/\r\n /g, '');
  assert.match(calendar, /RRULE:FREQ=WEEKLY;BYDAY=TU/);
});
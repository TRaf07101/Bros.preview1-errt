# Auditoria de cores NXR Bros — 2026-09-12

## Correção aplicada
- NXR 150 Bros 2014: incluído **Azul (Edição Especial)** para ES e ESD.
- NXR 160 Bros 2025 ABS: a opção preta passou a ser exibida como **Preta/Vermelha**, refletindo a moto preta com detalhes vermelhos (e detalhes brancos no grafismo), sem criar uma nova versão CBS.

## Verificações das cores
- 2013: vermelha, preta, verde.
- 2014: vermelha, branca, azul (Edição Especial), preta.
- 2015: vermelha/branca, branca/preta, preta/cinza.
- 2016: combinações separadas para ES e ESDD, preservadas.
- 2017: ESDD vermelha/branca e azul/branca; ES preta e branca.
- 2018: ESDD/CBS laranja/branca, vermelha/preta, azul/preta; ES preta e branca.
- 2019: branca/vermelha, vermelha/preta, azul/preta, laranja/cinza.
- 2020: azul, preta, vermelha.
- 2021: preta, vermelha, azul.
- 2022: branca/preta, preta/dourada, vermelha/branca.
- 2023: preta/cinza, vermelha/cinza, branca/preta.
- 2024: preta, vermelha/preta, branca/azul.
- 2025: CBS cinza/vermelha; ABS preta/vermelha e vermelha.
- 2026: CBS azul/vermelha; ABS cinza/vermelha.

## Fontes principais
- Honda — NXR 160 Bros 2024: as cores predominantes continuam Preto, Branco e Vermelho; CBS com discos nas duas rodas.
- Honda — NXR 160 Bros 2025: CBS nas cores Cinza e Vermelho; ABS nas cores Preto e Vermelho; material oficial também mostra a moto preta com detalhes vermelhos/brancos.
- Honda — NXR 160 Bros 2026: CBS Azul/Verde e Vermelho; ABS Cinza e Vermelho.
- Catálogos históricos de peças confirmam o Azul de 2014 como combinação própria da NXR 150 Bros 2014.

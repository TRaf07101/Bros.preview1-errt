Correção de cor NXR 160 Bros 2025

- Adicionada a opção visual "Preta/Vermelha" à versão CBS 2025.
- Fonte visual: galeria oficial Honda que identifica a imagem como "Nova Honda NXR Bros 160 CBS 2025 Preta com detalhes vermelho e branco".
- A lista comercial de cores do release Honda de lançamento 2025 informa CBS Cinza/Vermelho e ABS Preto/Vermelho; por isso a opção CBS preta/vermelha fica marcada internamente como cor da galeria oficial, não como alteração silenciosa da lista comercial.
- O mapeamento usa a URL oficial Honda diretamente e permanece sujeito ao fallback de imagem já corrigido no componente.
